Code and output for:
  Lee, H. (2026). What Counts as Error? A Structured Review and Meta-Analysis of Agreement in Korean Constitutional Diagnosis, by Who Classifies and When. SSRN Working Paper (paper 4).
  Lee, H. (2026). At What Level Is Constitution Fixed? Separating Lasting Change, Passing State and Rater Error in a Nested Categorical Diagnosis. SSRN Working Paper (paper 5).

Requirements: Python 3 with NumPy; SciPy and pandas for paper4/meta and paper4/search; matplotlib only for the figures. Run each script from its own folder
(ratio_check.py and sim_extra.py import simulation.py; scripts in latent/ import paper5_sim.py from the folder above). All scripts use fixed seeds. Set OMP_NUM_THREADS=1.

paper4/search/  logged and supplementary searches and screening (paper 4, sections 2.1-2.3 and 3.1, Figure 1)
  protocol.md     the protocol written before the logged search (not registered; note at the top)
  search_log.csv  every search run on 8-9 November 2026 with its date and number of records,
                  including searches that returned nothing, failed, or were not parsed
  records_kci_pubmed_koreascience.csv   the records logged during screening, with bibliographic details
  screening_log.csv   one row per unique record screened in the logged search and from other methods, with stage,
                  decision, reason and the included report it became; three decisions corrected on re-screening
                  (R001, R002, O09) say so in their reason
  search_log_supplementary.csv   every search of the supplementary search of 14 November 2026 (KCI, KoreaScience,
                  ScienceON, RISS theses, PubMed), with its number of records, including searches that
                  returned nothing or a server error
  screening_log_supplementary.csv   one row per record saved in the supplementary search after automatic
                  de-duplication, with stage, decision and reason; for reports not retrieved, the reason gives
                  what the abstract reports
  supplementary/  provenance of the supplementary search: result_pages.csv (one row per saved result page),
                  records_saved_pages.csv (every record parsed from those pages), and the parser and
                  de-duplication scripts (parse_pages.py, dedupe.py); the saved HTML pages are not included
  prisma.py       counts every box of the PRISMA 2020 diagram from the four logs and draws it:
                    python3 prisma.py      (writes figure1_prisma.png and prisma_counts.txt)
paper4/meta/   meta-analysis (paper 4, sections 2.4-2.7 and 3.1-3.4, Table 1, Figure 2)
  extraction.csv  every included estimate (49 rows from 32 studies; rows 35-49 from the supplementary search),
                  with source, design class and flags
  excluded.csv    reports excluded at full text or not retrieved, and estimates excluded within included reports
  analysis.py     REML pooling by design and by type of pair, meta-regression, sensitivity analyses,
                  percentage agreement against interval (section 3.3), KS-15 change bounds at one and five years (3.4),
                  specialist contrast (3.2):
                    python3 analysis.py extraction.csv out      (writes out/units.csv and out/results.json)
  analysis_output.txt, units.csv, results.json   the output of that command, as reported in the paper
  forest.py       Figure 2:  python3 forest.py units.csv results.json figure2_forest.png
  sensitivity.py  -> sensitivity_output.txt   checks added after the logged search (section 3.2): leave-one-out,
                  Park SS 1999 as its main pair, type of pair as moderator, Egger and rank-correlation checks,
                  possible patient overlap among the five KCMB-based reports, the first-search evidence base alone,
                  without voice-only ratings, and with one abstract-only estimate added. Imports analysis.py;
                  reads units.csv and extraction.csv.
paper4/ecm/    the one study with different classifiers across occasions (paper 4, section 3.6 and Table 4; paper 5, section 6.1)
  park2006_calls.csv   every pulse call of two doctors for 52 women at four weekly visits, transcribed from the thesis (Table 1)
  park2006_ecm_pulse.py -> park2006_ecm_pulse_output.txt   kappa between and within doctors, on the same and different visits,
                  at eight types, four organ groups and two divisions, with bootstrap intervals; form agreement among
                  same-group calls
paper4/        reanalysis of published cross-tabulations (paper 4, sections 2.8 and 3.5, Tables 2-3) and earlier simulations
  reanalysis.py   -> reanalysis_output.txt   five tables from the first version (KS-15 retest, three specialists
                                             against a reference, SCAT, KS-15 in Japan, ECM questionnaire), the
                                             independence test, level-wise kappa, the reference-conditioned null.
  added_tables_levels.py -> added_tables_levels_output.txt   level-wise kappa and yin-yang crossing for the other
                                             fourteen Sasang tables in Table 3 (Lee JH 2007, the seven tables added
                                             by the logged search and the six added by the supplementary search);
                                             imports reanalysis.py.
  simulation.py, sim_extra.py, ratio_check.py and their outputs: simulations from the earlier version of paper 4,
                  kept for reproducibility of that version; the current paper does not report them.
                  sim_extra.py run on its own uses another seed.

paper5/
  paper5_sim.py   -> paper5_sim_output.txt   every number in sections 6.1 and 6.2 and Appendix A (seed 5052026).
                     Run one part at a time, e.g.
                       OMP_NUM_THREADS=1 python paper5_sim.py --part=B --facc=0.95 --n=1000
                       OMP_NUM_THREADS=1 python paper5_sim.py --part=P --cell=1
                     The script header lists every part. Parts P (full registered rule, all scenarios) and
                     Q (full rule near the margin) give Table 3 and section 6.2.
  figure1.py      -> figure1.png             Figure 1 of paper 5 (section 6.2), read from the output file.
  latent/lm.py                               single-level latent trait-state model (the "earlier model of one level
                                             at a time" in section 6.3); sim6.py -> sim6_output.txt gives its numbers.
  latent/lm_joint.py                         joint eight-type latent trait-state model of section 4.3 (EM with SQUAREM;
                                             type-dependent state kernel; optional panel misreading).
  latent/sim7.py  -> latent/sim7_output_CMP.txt   Table 4 (section 6.3):  python3 sim7.py --part=CMP --reps=40 --panel
                                             (seed 7072026; rows can be split across processes with --rows=0,1,2 ...)
  latent/selftest_joint.py -> latent/selftest_joint_output.txt   self-consistency check of section 4.3
                                             (prints true state probability, fitted change shares, fitted state probability).

Author: Hoon Lee, L.Ac. (caleeacu@gmail.com)

Version: November 2026 (final versions of papers 4 and 5).
