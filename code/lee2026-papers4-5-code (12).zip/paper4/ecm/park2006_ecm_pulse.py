"""Reanalysis of the raw ECM pulse calls in Park YS (2006), doctoral thesis, Dongguk University
(paper 4, section 3.6).

Two Korean medicine doctors each typed the same 52 women by pulse alone on four Sundays one week apart
(5, 12, 19 and 26 February 2006), with face and upper body covered, without questioning, in an order changed
every week, and without seeing each other's or their own earlier calls until the last visit.
park2006_calls.csv transcribes the thesis, Table 1 (pp. 9-10): subject, doctor 1 visits 1-4, doctor 2 visits 1-4.

Cohen's kappa at three levels: eight types; four organ groups (Wood, Earth, Metal, Water); two divisions
(Wood and Earth against Metal and Water, as in reanalysis.py). For each class of comparison the kappas of all
its pairs of columns are averaged. Intervals: 95% percentile bootstrap, resampling the 52 women
(seed 2006, 4000 draws).
Run: python3 park2006_ecm_pulse.py > park2006_ecm_pulse_output.txt
"""
import itertools
import numpy as np
import pandas as pd

CODE = {"목양": 0, "목음": 1, "토양": 2, "토음": 3, "금양": 4, "금음": 5, "수양": 6, "수음": 7}
GROUP = np.array([0, 0, 1, 1, 2, 2, 3, 3])
SIDE = np.array([0, 0, 0, 0, 1, 1, 1, 1])
CLASSES = ["different doctors, same visit", "same doctor, doctor 1", "same doctor, doctor 2",
           "different doctors, different visits"]


def kappa(a, b, k):
    po = np.mean(a == b)
    pe = (np.bincount(a, minlength=k) / len(a)) @ (np.bincount(b, minlength=k) / len(b))
    return (po - pe) / (1 - pe), po


def comparisons():
    """(class, lag in weeks, column of first call, column of second call)"""
    out = [("different doctors, same visit", 0, v, 4 + v) for v in range(4)]
    for name, off in (("doctor 1", 0), ("doctor 2", 4)):
        out += [(f"same doctor, {name}", j - i, off + i, off + j) for i, j in itertools.combinations(range(4), 2)]
    out += [("different doctors, different visits", abs(j - i), i, 4 + j) for i in range(4) for j in range(4) if i != j]
    return out


COMP = comparisons()


def summary(C, lev):
    X = C if lev == 8 else (GROUP[C] if lev == 4 else SIDE[C])
    res = {}
    for cls, lag, a, b in COMP:
        kp, po = kappa(X[:, a], X[:, b], lev)
        for key in (cls, (cls, lag)):
            res.setdefault(key, []).append(kp)
        res.setdefault(("po", cls), []).append(po)
    return {key: float(np.mean(v)) for key, v in res.items()}


def main(path="park2006_calls.csv"):
    C = pd.read_csv(path).iloc[:, 1:].apply(lambda s: s.map(CODE)).to_numpy()
    assert C.shape == (52, 8)
    D1, D2 = C[:, :4], C[:, 4:]
    print("Check against the thesis: same type at all four visits, doctor 1 %d (thesis 22), doctor 2 %d (thesis 13);"
          " all eight calls the same %d (thesis 4)"
          % ((D1 == D1[:, [0]]).all(1).sum(), (D2 == D2[:, [0]]).all(1).sum(), (C == C[:, [0]]).all(1).sum()))
    print("calls by type (Hep Cho Pan Gas Pul Col Ren Ves): doctor 1", np.bincount(D1.ravel(), minlength=8).tolist(),
          "doctor 2", np.bincount(D2.ravel(), minlength=8).tolist())
    rng = np.random.default_rng(2006)
    idx = [rng.integers(0, 52, 52) for _ in range(4000)]
    for lev in (8, 4, 2):
        point = summary(C, lev)
        boots = [summary(C[i], lev) for i in idx]
        ci = lambda key: np.percentile([b[key] for b in boots], [2.5, 97.5])
        print(f"\n=== {lev} categories: mean kappa [95% bootstrap interval]; mean agreement ===")
        for cls in CLASSES:
            lo, hi = ci(cls)
            print(f"{cls:38s} {point[cls]:.3f} [{lo:.3f}, {hi:.3f}]  agreement {point[('po', cls)]:.3f}")
            for lag in (1, 2, 3):
                if (cls, lag) in point:
                    lo, hi = ci((cls, lag))
                    print(f"    {lag} week(s) apart: {point[(cls, lag)]:.3f} [{lo:.3f}, {hi:.3f}]")
        for a, b in ((CLASSES[3], CLASSES[0]), (CLASSES[1], CLASSES[0]), (CLASSES[1], CLASSES[2])):
            d = [x[a] - x[b] for x in boots]
            print(f"  {a} minus {b}: {point[a] - point[b]:.3f} [{np.percentile(d, 2.5):.3f}, {np.percentile(d, 97.5):.3f}]")
    print("\nkappa between doctors at each visit, eight types:", [round(float(kappa(C[:, v], C[:, 4 + v], 8)[0]), 3) for v in range(4)])
    print("kappa between doctors at each visit, four groups:", [round(float(kappa(GROUP[C[:, v]], GROUP[C[:, 4 + v]], 4)[0]), 3) for v in range(4)])
    # form (yang or yin) agreement among women whose organ group both doctors called the same (paper 5, section 7.1)
    out = []
    for v in range(4):
        a, b = C[:, v], C[:, 4 + v]; m = GROUP[a] == GROUP[b]
        out.append((int(m.sum()), float(kappa(a[m] % 2, b[m] % 2, 2)[0])))
    print("form kappa between doctors among same-group calls, by visit (n, kappa):", [(n, round(k, 3)) for n, k in out],
          "mean %.3f" % np.mean([k for _, k in out]))


if __name__ == "__main__":
    main()
