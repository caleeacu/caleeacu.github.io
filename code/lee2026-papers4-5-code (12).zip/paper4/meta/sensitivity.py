"""Robustness checks for paper 4 (sections 3.2 and 4.4). Reads units.csv and extraction.csv written/used by analysis.py.
  python3 sensitivity.py > sensitivity_output.txt
1 leave-one-out for the between-classifier pool and for the design meta-regression
2 the questionnaire comparison of Park SS 1999 entered as its main pair only (row 23) instead of the mean of three pairs
3 type of pair as a moderator within the between-classifier class
4 small-study checks in the between-classifier class (Egger regression; Spearman correlation of kappa with SE)
5 possible patient overlap among reports drawing on the Korea Constitutional Multicenter Bank or its clinics
6 units added after the supplementary search removed (the first-search evidence base)
7 voice-only ratings (Yoo 2004) removed
8 one abstract-only estimate from an unretrieved report added"""
import numpy as np
import pandas as pd
from scipy import stats
from analysis import reml, kappa_se

U = pd.read_csv("units.csv"); E = pd.read_csv("extraction.csv")
DIFF, SAME = "different classifiers, same occasion", "same classifier, across occasions"
D = U[(U.design == DIFF) & (U.in_sample == 0)].reset_index(drop=True)
M = U[U.design.isin([DIFF, SAME]) & (U.in_sample == 0)].reset_index(drop=True)
M["same"] = (M.design == SAME).astype(int)

def pool(g):
    m = reml(g.kappa.values, g.se.values ** 2)
    return f"k={m['k']} kappa={m['beta'][0]:.3f} [{m['ci_low'][0]:.3f},{m['ci_high'][0]:.3f}] tau2={m['tau2']:.4f} I2={m['I2']:.2f}"
def metareg(g):
    m = reml(g.kappa.values, g.se.values ** 2, np.column_stack([np.ones(len(g)), g.same.values]))
    return m["beta"][1], m["ci_low"][1], m["ci_high"][1], m["k"]
def fmt(t): return f"k={t[3]} diff={t[0]:.3f} [{t[1]:.3f},{t[2]:.3f}]"

print("1. LEAVE-ONE-OUT\nbetween-classifier pool, all units:", pool(D))
lo = []
for i in range(len(D)):
    m = reml(D.drop(i).kappa.values, D.drop(i).se.values ** 2); lo.append((m["beta"][0], m["I2"]))
    print(f"  without {D.unit[i][:52]:52s} {pool(D.drop(i))}")
print(f"  range of pooled kappa {min(x[0] for x in lo):.3f} to {max(x[0] for x in lo):.3f}; range of I2 {min(x[1] for x in lo):.2f} to {max(x[1] for x in lo):.2f}")
print("design meta-regression, all units:", fmt(metareg(M)))
r = [metareg(M.drop(i)) for i in range(len(M))]
for i, t in enumerate(r): print(f"  without {M.unit[i][:52]:52s} {fmt(t)}")
print(f"  range of difference {min(t[0] for t in r):.3f} to {max(t[0] for t in r):.3f}; smallest lower limit {min(t[1] for t in r):.3f}")

print("\n2. PARK SS 1999 AS ITS MAIN PAIR ONLY")
row = E[E.id == 23].iloc[0]; se23, _ = kappa_se(row.kappa, row.po, row.n)
D2 = D.copy(); i = D2.index[D2.unit.str.startswith("Park 1999")][0]; D2.loc[i, ["kappa", "se"]] = [row.kappa, se23]
M2 = M.copy(); j = M2.index[M2.unit.str.startswith("Park 1999")][0]; M2.loc[j, ["kappa", "se"]] = [row.kappa, se23]
print("between-classifier pool:", pool(D2)); print("design meta-regression:", fmt(metareg(M2)))

print("\n3. TYPE OF PAIR AS MODERATOR (reference: instrument vs practitioner)")
X = np.column_stack([np.ones(len(D)), (D.pair == "two instruments").astype(int), (D.pair == "two practitioners").astype(int)])
print("pairs:", D.pair.value_counts().to_dict())
m0 = reml(D.kappa.values, D.se.values ** 2); m = reml(D.kappa.values, D.se.values ** 2, X)
for n, b, l, h in zip(["intercept", "two instruments", "two practitioners"], m["beta"], m["ci_low"], m["ci_high"]): print(f"  {n:18s} {b:.3f} [{l:.3f},{h:.3f}]")
print(f"  tau2 without moderator {m0['tau2']:.4f}; with moderator {m['tau2']:.4f}; share of tau2 accounted for {1 - m['tau2'] / m0['tau2']:.2f}")
m = reml(D2.kappa.values, D2.se.values ** 2, X)
print("  with Park SS 1999 as its main pair: two instruments", f"{m['beta'][1]:.3f} [{m['ci_low'][1]:.3f},{m['ci_high'][1]:.3f}]")

print("\n4. SMALL-STUDY CHECKS, BETWEEN-CLASSIFIER CLASS")
def egger(g):
    y, s = g.kappa.values, g.se.values; X = np.column_stack([np.ones(len(y)), 1 / s]); z = y / s
    b = np.linalg.lstsq(X, z, rcond=None)[0]; res = z - X @ b; df = len(y) - 2
    se = np.sqrt((np.linalg.inv(X.T @ X) * (res @ res / df))[0, 0]); t = b[0] / se
    rho, p = stats.spearmanr(y, s)
    return f"k={len(y)} Egger intercept={b[0]:.2f} t={t:.2f} p={2 * stats.t.sf(abs(t), df):.3f}; Spearman rho(kappa, SE)={rho:.2f} p={p:.2f}"
print("all units:                       ", egger(D)); print("Park SS 1999 as its main pair:   ", egger(D2)); print("without Park SS 1999:            ", egger(D.drop(i)))

KCMB = ("Jang 2012 (", "Baek 2014", "Jang 2013", "Nam 2017")
print("\n5. POSSIBLE OVERLAP AMONG KCMB-BASED REPORTS (Jang 2012, Jang 2012b, Baek 2014, Jang 2013, Nam 2017): keep Jang 2012b only")
drop = D.unit.str.startswith(KCMB)
print("between-classifier pool:", pool(D[~drop]))
dropm = M.unit.str.startswith(KCMB)
print("design meta-regression:", fmt(metareg(M[~dropm])))
for keep in ["Jang 2013", "Nam 2017"]:
    others = tuple(x for x in KCMB if x != keep) + ("Jang 2012b",)
    print(f"  keep {keep} only: pool", pool(D[~D.unit.str.startswith(others)]), "| metareg", fmt(metareg(M[~M.unit.str.startswith(others)])))

NEW = ("Jung HJ 2000", "Park HS 2002", "Oh 2013", "Yoo 2012", "Jeong 2024", "Yoo 2004", "Jang 2013", "Nam 2017", "Park YS 2006")
print("\n6. FIRST-SEARCH EVIDENCE BASE ONLY (units added after the supplementary search removed)")
print("between-classifier pool:", pool(D[~D.unit.str.startswith(NEW)]))
print("design meta-regression:", fmt(metareg(M[~M.unit.str.startswith(NEW)])))

print("\n6b. WITHOUT THE ECM PULSE THESIS (Park YS 2006) ONLY")
print("between-classifier pool:", pool(D[~D.unit.str.startswith("Park YS 2006")]))
print("design meta-regression:", fmt(metareg(M[~M.unit.str.startswith("Park YS 2006")])))

print("\n7. WITHOUT VOICE-ONLY RATINGS (Yoo 2004)")
print("between-classifier pool:", pool(D[~D.unit.str.startswith("Yoo 2004")]))
print("design meta-regression:", fmt(metareg(M[~M.unit.str.startswith("Yoo 2004")])))

print("\n8. ADDING ONE ABSTRACT-ONLY ESTIMATE FROM A REPORT NOT RETRIEVED (questionnaire vs specialist, kappa 0.320, n = 331; po not reported)")
se_a, _ = kappa_se(0.320, np.nan, 331)
Da = pd.concat([D, pd.DataFrame([dict(unit="abstract-only questionnaire vs specialist", kappa=0.320, se=se_a)])], ignore_index=True)
print("between-classifier pool:", pool(Da))
Ma = pd.concat([M, pd.DataFrame([dict(unit="abstract-only questionnaire vs specialist", kappa=0.320, se=se_a, same=0)])], ignore_index=True)
print("design meta-regression:", fmt(metareg(Ma)))
