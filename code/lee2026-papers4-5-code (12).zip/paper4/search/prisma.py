"""PRISMA 2020 flow diagram for paper 4 (logged search 8-9 November 2026 and supplementary search 14 November 2026).
Counts come from search_log.csv and search_log_supplementary.csv (hits per search) and from
screening_log.csv and screening_log_supplementary.csv (one row per record).
Run: python3 prisma.py  -> figure1_prisma.png and prisma_counts.txt"""
import re
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle

S = pd.read_csv("search_log.csv"); L = pd.read_csv("screening_log.csv")
S2 = pd.read_csv("search_log_supplementary.csv", dtype=str); L2 = pd.read_csv("screening_log_supplementary.csv", dtype=str)
num = lambda v: int(re.match(r"\d+", str(v)).group()) if re.match(r"\d+", str(v)) else 0
# ---- stage 1: logged search of 8-9 November 2026
S = S[~S.records.astype(str).str.contains("error|invalid")]   # searches that failed (error page or unparsed query) are not counted
hits = S.assign(n=S.records.map(num)).groupby("db").n.sum().to_dict()
nsearch = S.assign(n=S.records.map(num)).groupby("db").size().to_dict()
displayed = {"KCI": hits["KCI"], "PubMed": hits["PubMed"], "KoreaScience": 76, "RISS": 3}   # KoreaScience: first page (10) per search; RISS: integrated-search preview of the theses tab
db = L[~L.database.str.startswith("other")]
oth = L[L.database.str.startswith("other")]
ident1 = sum(hits.values()); notshown = sum(hits[k] - displayed[k] for k in hits)
screened1 = len(db); dups1 = sum(displayed.values()) - screened1
# ---- stage 2: supplementary search of 14 November 2026 (completes the protocol; also saves the results not displayed in stage 1)
hits2 = S2.assign(n=S2.records.map(num)).groupby("db").n.sum().to_dict()
nsearch2 = S2.groupby("db").size().to_dict(); nfail2 = (S2.records == "error").sum()
ident2 = sum(hits2.values()); in_log2 = len(L2)
screened2 = (L2.decision != "duplicate").sum(); dups2 = ident2 - in_log2 + (L2.decision == "duplicate").sum()
ident = ident1 + ident2; dups = dups1 + dups2; screened = screened1 + screened2
assert ident - dups - notshown == screened
# ---- screening and eligibility, both stages
A = pd.concat([db[["stage", "decision", "reason"]], L2[L2.decision != "duplicate"][["stage", "decision", "reason"]]])
ta = (A.stage == "title/abstract").sum(); sought = screened - ta
nr = (A.decision == "not retrieved").sum(); assessed = sought - nr
ftx = A[(A.stage == "full text") & (A.decision == "exclude")]; inc_db = (A.decision == "include").sum()
assert assessed == len(ftx) + inc_db
reasons = ftx.reason.str.split(":").str[0].value_counts()
o_inc = (oth.decision == "include").sum(); o_nr = (oth.decision == "not retrieved").sum(); o_ex = oth[oth.decision == "exclude"]
total_inc = inc_db + o_inc
lines = [f"stage 1 identified {ident1} ({hits}); searches {nsearch}", f"stage 2 identified {ident2} ({hits2}); searches {nsearch2}; failed {nfail2}",
         f"identified {ident}", f"duplicates {dups} (stage 1 {dups1}; stage 2 {dups2})", f"stage-1 results not displayed, later saved in stage 2 {notshown}",
         f"screened {screened} (stage 1 {screened1}; stage 2 {screened2})",
         f"excluded title/abstract {ta}", f"sought {sought}", f"not retrieved {nr}", f"assessed {assessed}", f"excluded full text {len(ftx)}",
         str(reasons.to_dict()), f"included from databases {inc_db}", f"other methods: identified {len(oth)}, not retrieved {o_nr}, assessed {len(oth)-o_nr}, excluded {len(o_ex)}, included {o_inc}",
         f"total included studies {total_inc}"]
open("prisma_counts.txt", "w").write("\n".join(lines) + "\n"); print("\n".join(lines))

T = dict(
 ident=(f"Records identified (n = {ident})\n"
        f"Logged search, 8-9 Nov 2026 (n = {ident1})\n  KCI {nsearch['KCI']} searches ({hits['KCI']}); KoreaScience {nsearch['KoreaScience']} ({hits['KoreaScience']});\n  PubMed 1 ({hits['PubMed']}); RISS theses 1 ({hits['RISS']})\n"
        f"Supplementary search, 14 Nov 2026 (n = {ident2})\n  KCI {nsearch2['KCI']} searches ({hits2['KCI']}); KoreaScience {nsearch2['KoreaScience']} ({hits2['KoreaScience']});\n  ScienceON {nsearch2['ScienceON']} ({hits2['ScienceON']}); RISS theses {nsearch2['RISS (theses)']} ({hits2['RISS (theses)']});\n  PubMed 1 ({hits2['PubMed']})"),
 removed=f"Records removed before screening\n  Duplicate records (n = {dups})\n  Logged-search results not displayed,\n  saved and screened in the supplementary\n  search (n = {notshown})",
 screened=f"Records screened (n = {screened})", excl_ta=f"Records excluded on title\nor abstract (n = {ta})",
 sought=f"Reports sought for retrieval (n = {sought})", notret=f"Reports not retrieved (n = {nr})\n  incl. 2 thesis versions of retrieved articles",
 assessed=f"Reports assessed for eligibility (n = {assessed})",
 excl_ft=f"Reports excluded (n = {len(ftx)})\n" + "\n".join(f"  {k[0].upper()+k[1:]}\n    (n = {v})" if len(k)>30 else f"  {k[0].upper()+k[1:]} (n = {v})" for k, v in reasons.items()),
 o_ident=f"Records identified from:\n  Preliminary search\n  Citation searching\n  (n = {len(oth)})",
 o_sought=f"Reports sought for retrieval (n = {len(oth)})", o_nr=f"Reports not retrieved (n = {o_nr})\n  Three unpublished master's theses;\n  one pulse-proficiency study",
 o_assessed=f"Reports assessed for eligibility (n = {len(oth)-o_nr})",
 o_excl=f"Reports excluded (n = {len(o_ex)})\n" + "\n".join(f"  {s.split(':')[0].split(';')[0].split(' (')[0][:1].upper()+s.split(':')[0].split(';')[0].split(' (')[0][1:]} (n = 1)" for s in o_ex.reason),
 included=f"Studies included in review (n = {total_inc})\n  From databases {inc_db}; from other methods {o_inc}\n  Kappa analyses: 28 studies\n  Percentage agreement only: 4 studies",
)
fig, ax = plt.subplots(figsize=(15, 12.6)); ax.set_xlim(0, 150); ax.set_ylim(0, 131); ax.axis("off")
def box(x, y, w, h, k, fc="white"):
    ax.add_patch(Rectangle((x, y), w, h, fc=fc, ec="#222", lw=0.9))
    ax.text(x + 1.2, y + h / 2, T[k], va="center", ha="left", fontsize=8.3, linespacing=1.35)
def arr(*pts):
    for (x1, y1), (x2, y2) in zip(pts[:-2], pts[1:-1]): ax.plot([x1, x2], [y1, y2], color="#222", lw=0.9)
    (x1, y1), (x2, y2) = pts[-2], pts[-1]
    ax.annotate("", xy=(x2, y2), xytext=(x1, y1), arrowprops=dict(arrowstyle="-|>", color="#222", lw=0.9, shrinkA=0, shrinkB=0))
def band(y, h, lab):
    ax.add_patch(Rectangle((0, y), 4, h, fc="#d9d9d9", ec="none"))
    ax.text(2, y + h / 2, lab, ha="center", va="center", rotation=90, fontsize=9, fontweight="bold")
ax.text(42, 128, "Identification of studies via databases", ha="center", fontsize=10, fontweight="bold")
ax.text(115, 128, "Identification of studies via other methods", ha="center", fontsize=10, fontweight="bold")
ax.plot([80, 80], [2, 126], color="#999", lw=0.6, ls=":")
band(91, 35, "Identification"); band(24, 66, "Screening"); band(2, 19, "Included")
box(6, 92, 36, 33, "ident"); box(46, 99, 32, 19, "removed"); arr((42, 108.5), (46, 108.5))
box(6, 80, 34, 7, "screened"); arr((23, 92), (23, 87))
box(44, 79, 34, 9, "excl_ta"); arr((40, 83.5), (44, 83.5))
box(6, 66, 34, 7, "sought"); arr((23, 80), (23, 73))
box(44, 66, 34, 7, "notret"); arr((40, 69.5), (44, 69.5))
box(6, 52, 34, 7, "assessed"); arr((23, 66), (23, 59))
box(44, 25, 34, 34, "excl_ft"); arr((40, 55.5), (44, 55.5))
box(83, 99, 30, 19, "o_ident")
box(83, 66, 30, 7, "o_sought"); arr((98, 99), (98, 73))
box(116, 65, 33, 9, "o_nr"); arr((113, 69.5), (116, 69.5))
box(83, 52, 30, 7, "o_assessed"); arr((98, 66), (98, 59))
box(116, 46, 33, 16, "o_excl"); arr((113, 55.5), (116, 55.5))
box(6, 3, 40, 16, "included", fc="#f2f2f2"); arr((23, 52), (23, 19)); arr((98, 52), (98, 11), (46, 11))
plt.savefig("figure1_prisma.png", dpi=220, bbox_inches="tight")
