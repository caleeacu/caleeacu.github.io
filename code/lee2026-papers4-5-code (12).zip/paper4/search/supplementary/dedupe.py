"""Deduplicate new records within the new search and against records screened in the first logged search."""
import re, json, sys, pandas as pd
new = pd.read_csv('parsed/records.csv')
n = lambda s: re.sub(r'\([^)]*\)|[^0-9a-z가-힣一-鿿]', '', str(s).lower()) if isinstance(s, str) else ''
def keys(ko, en):
    k = []
    for s in (ko, en):
        if not isinstance(s, str): continue
        s2 = re.sub(r'\([^)]*\)', '', s.lower())
        h = re.sub(r'[^가-힣一-鿿]', '', s2)
        if len(h) >= 8: k.append('H' + h[:30])
        e = re.sub(r'[^a-z]', '', s2)
        if len(h) < 8 and len(e) >= 15: k.append('E' + e[:50])
    return k
old = pd.read_csv('/home/claude/final/code/paper4/search/screening_log.csv')
oldrec = pd.read_csv('/home/claude/final/code/paper4/search/records_kci_pubmed_koreascience.csv')
ks = json.load(open(sys.argv[1]))
OLD = {}
for _, r in old.iterrows():
    for k in keys(r.title, ''): OLD.setdefault(k, r.record_id)
for _, r in oldrec.iterrows():
    for k in keys(r.title, ''): OLD.setdefault(k, r.record_id)
for x in ks:
    for k in keys(x.get('kt'), x.get('title')): OLD.setdefault(k, 'KS-first-search')
new['keys'] = [keys(a, b) for a, b in zip(new.title_ko, new.title_en)]
new['dup_of_old'] = [next((OLD[k] for k in ks_ if k in OLD), '') for ks_ in new['keys']]
groups = {}; gid = []
for ks_ in new['keys']:
    g = next((groups[k] for k in ks_ if k in groups), None)
    if g is None: g = len(set(groups.values())) + 1
    for k in ks_: groups[k] = g
    gid.append(g)
new['group'] = gid
first = ~new.duplicated('group')
new['dup_within_new'] = ~first
new.drop(columns='keys').to_csv('parsed/records_dedup.csv', index=False)
u = new[first]
print('records', len(new), 'unique', len(u), 'of which seen in first search', (u.dup_of_old != '').sum(), 'new unique', (u.dup_of_old == '').sum())
u[u.dup_of_old == ''].drop(columns='keys').to_csv('parsed/to_screen.csv', index=False)
