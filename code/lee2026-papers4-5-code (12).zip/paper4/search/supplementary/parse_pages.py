"""Parse saved result pages (KoreaScience, ScienceON, RISS theses) into records.csv and pages.csv.
usage: python3 -I parse_pages.py RAW_DIR OUT_DIR"""
import re, html, os, sys, csv
raw, out = sys.argv[1], sys.argv[2]
clean = lambda s: re.sub(r'\s+', ' ', html.unescape(re.sub(r'<[^>]+>', '', s or ''))).strip()
def ks(t):
    q = re.search(r'Title/Summary/Keyword:\s*([^<]+)', t); n = re.search(r'Search Result <span[^>]*>([\d,]+)</span>', t)
    recs = []
    for b in t.split('<article class="srched-box">')[1:]:
        g = lambda c: clean((re.search(r'class="[^"]*\b%s\b[^"]*"[^>]*>(.*?)</(?:span|li|p)>' % c, b, re.S) or [None, ''])[1])
        art = re.search(r'/article/(\w+)\.page', b)
        recs.append(dict(id=art.group(1) if art else '', title_ko=g('artileTitleKor'), title_en=g('artileTitleEng'), authors=g('authorNames'),
                         source=g('journalTitle'), vol=g('volissName'), pages=g('pageRange'), year=g('pubYear'), kind='article', abstract=g('abstract')))
    return clean(q.group(1)) if q else '', int(n.group(1).replace(',', '')) if n else None, recs
def son(t):
    q = re.search(r'id="searchKeyword"[^>]*value="([^"]*)"', t) or re.search(r'name="query"[^>]*value="([^"]*)"', t)
    n = re.search(r'class="total-num">\s*검색결과\s*<b[^>]*>\(([\d,]+)\)', t)
    recs = []
    for b in re.split(r'<div class="powerful-con[^"]*" id="result_item_t', t)[1:]:
        rid = b[:b.find('"')]
        tag = clean((re.search(r'<div class="list_top_tag_box">\s*<span>(.*?)</span>', b, re.S) or [None, ''])[1])
        a = re.search(r'class="subject"[^>]*>(.*?)</a>', b, re.S); en = ''
        if a:
            body = a.group(1); m = re.search(r'<em class="subject_en">(.*?)</em>', body, re.S)
            en = clean(m.group(1)) if m else ''; ko = clean(re.sub(r'<em class="subject_en">.*?</em>', '', body, flags=re.S))
        else: ko = ''
        info = clean((re.search(r'<p class="info[^"]*">(.*?)</p>', b, re.S) or [None, ''])[1])
        yr = re.findall(r'(?:,|\))\s*((?:19|20)\d\d)\b', info)
        pp = re.search(r'pp\.\s*(\d+)\s*-\s*(\d+)', info)
        ab = clean((re.search(r'<p class="(?:txt|abstract)[^"]*">(.*?)</p>', b, re.S) or [None, ''])[1])
        recs.append(dict(id=rid, title_ko=ko, title_en=en, authors='', source=info[:200], vol='', pages=f"pp.{pp.group(1)}-{pp.group(2)}" if pp else '',
                         year=yr[0] if yr else '', kind=tag, abstract=ab))
    return clean(q.group(1)) if q else '', int(n.group(1).replace(',', '')) if n else None, recs
def riss(t):
    q = re.search(r'<dt>검색키워드</dt>\s*<dd>\s*(.*?)\s*<span>', t, re.S); n = re.search(r'\(검색결과 <span class="num">([\d,]+)</span>', t)
    tab = re.search(r'class="on"[^>]*>\s*<a[^>]*>([^<]*학위논문[^<]*)<', t)
    recs = []
    lst = t.split('class="srchResultListW">', 1)
    if len(lst) > 1:
        for b in re.split(r'\n<li>\s*\n', lst[1])[1:]:
            a = re.search(r'<p class="title"><a href="([^"]*)"[^>]*>(.*?)</a>', b, re.S)
            if not a: continue
            spans = [clean(s) for s in re.findall(r'<p class="etc">(.*?)</p>', b, re.S)[0].split('</span>')] if '<p class="etc">' in b else []
            yr = next((s for s in spans if re.fullmatch(r'(19|20)\d\d', s)), '')
            deg = next((s for s in spans if '석사' in s or '박사' in s), '')
            cn = re.search(r'control_no=(\w+)', a.group(1))
            ab = clean((re.search(r'<p class="preAbstract">(.*?)</p>', b, re.S) or [None, ''])[1])
            recs.append(dict(id=cn.group(1) if cn else '', title_ko=clean(a.group(2)), title_en='', authors=spans[0] if spans else '', source=spans[1] if len(spans) > 1 else '',
                             vol='', pages='', year=yr, kind=deg, abstract=ab))
    return clean(q.group(1)) if q else '', int(n.group(1).replace(',', '')) if n else None, recs
P, R = [], []
for f in sorted(os.listdir(raw)):
    if not f.endswith('.html'): continue
    t = open(os.path.join(raw, f), encoding='utf-8', errors='replace').read()
    db = f.split('_')[0]; fq = ' '.join(f.split('_')[1:-1]); pg = re.search(r'_p(\d+)\.html$', f).group(1)
    q, n, recs = {'KS': ks, 'SON': son, 'RISS': riss}[db](t)
    P.append(dict(file=f, db=db, query_from_name=fq, query_in_page=q, page=pg, total=n, records_on_page=len(recs)))
    for i, r in enumerate(recs, 1): R.append(dict(file=f, db=db, query=fq, page=pg, rank=i, **r))
os.makedirs(out, exist_ok=True)
for name, rows in (('pages.csv', P), ('records.csv', R)):
    with open(os.path.join(out, name), 'w', newline='', encoding='utf-8') as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
print(len(P), 'pages', len(R), 'records')
