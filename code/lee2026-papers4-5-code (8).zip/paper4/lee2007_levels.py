"""
Level-wise reanalysis of the one further complete Sasang retest table found after reanalysis.py was written:
  Lee JH, Chae H, Park SJ, Kwon YK. Korean J Orient Physiol Pathol 2007;21(5):1319-1331, Table 2
  (QSCC II in 2005 and 2006, 80 students with a determinate type both times; rows = 2006, cols = 2005).
Uses stats() and collapse() from reanalysis.py. Type order: Taeeum, Soeum, Soyang. Seed 2007.
Run: python lee2007_levels.py
"""
import numpy as np
from reanalysis import stats, collapse, YANG, YY_CROSS, GL_CROSS

LEE2007 = np.array([[10, 2, 2], [2, 44, 5], [0, 3, 12]])
GLV = np.array([0, 1, 1])

def main():
    rng = np.random.default_rng(2007)
    M = LEE2007; n = int(M.sum()); p = (M / n).ravel()
    s = stats(M)
    print(f"Lee JH 2007 QSCC II one-year retest: n {n}, agreement {s['po']*100:.1f}%, kappa {s['kappa']:.3f} (published 0.675)")
    out = []
    for lab, g in (("three types", None), ("yin/yang", YANG), ("greater/lesser", GLV)):
        f = (lambda X: stats(X)["kappa"]) if g is None else (lambda X, g=g: stats(collapse(X, g))["kappa"])
        bs = [f(rng.multinomial(n, p).reshape(3, 3)) for _ in range(4000)]
        out.append(f"{lab} {f(M):.3f} [{np.percentile(bs, 2.5):.2f}, {np.percentile(bs, 97.5):.2f}]")
    print("level-wise kappa: " + "; ".join(out))
    err_t = M.sum(0) - np.diag(M); tot = int(err_t.sum())
    for lab, frac, g in (("yin/yang", YY_CROSS, YANG), ("greater/lesser", GL_CROSS, GLV)):
        obs = int(sum(M[i, j] for i in range(3) for j in range(3) if i != j and g[i] != g[j]))
        print(f"{lab}: {obs} of {tot} changes cross ({obs/tot*100:.0f}%); null {err_t @ frac / tot * 100:.1f}%")

if __name__ == "__main__":
    main()
