"""Meta-analysis of type-level agreement in Korean constitutional diagnosis.

Reads extraction.csv, computes standard errors for Cohen's kappa, pools by design
with REML random-effects models, fits a meta-regression on design, and runs the
KS-15 bounds analysis. Writes units.csv and results.json (Figure 1 is drawn by forest.py).

Run: python3 -I analysis.py <path-to-extraction.csv> <outdir>
"""
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import optimize, stats

RNG = np.random.default_rng(20261031)
PE_DEFAULT = 0.37  # chance agreement assumed for 3-type Sasang tables lacking po


def kappa_se(kappa, po, n):
    """Large-sample SE of Cohen's kappa, simple form sqrt(po(1-po)/n)/(1-pe)."""
    if np.isnan(po):
        pe = PE_DEFAULT
        po = kappa * (1 - pe) + pe
    else:
        pe = (po - kappa) / (1 - kappa)
    return np.sqrt(po * (1 - po) / n) / (1 - pe), pe


def reml(y, v, X=None):
    """REML random-effects (meta-regression if X given). Returns dict."""
    y = np.asarray(y, float)
    v = np.asarray(v, float)
    k = len(y)
    if X is None:
        X = np.ones((k, 1))
    X = np.asarray(X, float)
    p = X.shape[1]

    def negll(log_tau2):
        t2 = np.exp(log_tau2)
        W = np.diag(1 / (v + t2))
        XtWX = X.T @ W @ X
        beta = np.linalg.solve(XtWX, X.T @ W @ y)
        r = y - X @ beta
        return 0.5 * (np.sum(np.log(v + t2)) + np.log(np.linalg.det(XtWX)) + r @ W @ r)

    if k - p >= 1:
        res = optimize.minimize_scalar(negll, bounds=(-20, 2), method="bounded")
        tau2 = float(np.exp(res.x))
        if tau2 < 1e-8:
            tau2 = 0.0
    else:
        tau2 = 0.0
    W = np.diag(1 / (v + tau2))
    XtWX = X.T @ W @ X
    cov = np.linalg.inv(XtWX)
    beta = cov @ X.T @ W @ y
    se = np.sqrt(np.diag(cov))
    # Q and I2 from fixed-effect fit
    W0 = np.diag(1 / v)
    b0 = np.linalg.solve(X.T @ W0 @ X, X.T @ W0 @ y)
    Q = float((y - X @ b0) @ W0 @ (y - X @ b0))
    df = k - p
    I2 = max(0.0, (Q - df) / Q) if Q > 0 and df > 0 else 0.0
    out = {
        "k": k,
        "beta": beta.tolist(),
        "se": se.tolist(),
        "ci_low": (beta - 1.96 * se).tolist(),
        "ci_high": (beta + 1.96 * se).tolist(),
        "z_p": (2 * stats.norm.sf(np.abs(beta / se))).tolist(),
        "tau2": tau2,
        "Q": Q,
        "Q_df": df,
        "Q_p": float(stats.chi2.sf(Q, df)) if df > 0 else None,
        "I2": I2,
    }
    if p == 1:
        half = 1.96 * np.sqrt(se[0] ** 2 + tau2)
        out["pi_low"] = float(beta[0] - half)
        out["pi_high"] = float(beta[0] + half)
    return out


def aggregate(sub, rho=0.5):
    """Average correlated estimates from one sample; SE allows correlation rho."""
    y = sub["kappa"].to_numpy()
    s = sub["se"].to_numpy()
    m = len(y)
    cov = rho * np.outer(s, s)
    np.fill_diagonal(cov, s ** 2)
    return float(y.mean()), float(np.sqrt(cov.sum()) / m)


def main(csv_path, outdir):
    out = Path(outdir)
    out.mkdir(parents=True, exist_ok=True)
    d = pd.read_csv(csv_path)
    d["flag"] = d["flag"].fillna("")
    se_pe = d.apply(lambda r: kappa_se(r.kappa, r.po, r.n) if not np.isnan(r.kappa) else (np.nan, np.nan), axis=1)
    d["se"] = [a for a, _ in se_pe]
    d["pe"] = [b for _, b in se_pe]

    results = {"per_estimate": d.to_dict(orient="records")}

    # ---- Independent-sample units for the primary analysis
    units = []
    kd = d[~d["kappa"].isna()].copy()
    # Baek inter-expert pairs share patients: aggregate
    b_inter = kd[kd.id.isin([1, 2, 3])]
    y, s = aggregate(b_inter)
    units.append(dict(unit="Baek 2014 inter-expert (3 pairs)", design="different classifiers, same occasion",
                      system="Sasang", kappa=y, se=s, n=80, interval_days=0, in_sample=0, sens_flag="derived_kappa"))
    b_ref = kd[kd.id.isin([4, 5, 6])]
    y, s = aggregate(b_ref)
    units.append(dict(unit="Baek 2014 experts vs treatment-confirmed reference (3)", design="vs treatment-confirmed reference",
                      system="Sasang", kappa=y, se=s, n=80, interval_days=np.nan, in_sample=0, sens_flag=""))
    for _, r in kd[~kd.id.isin([1, 2, 3, 4, 5, 6])].iterrows():
        des = "same classifier, across occasions" if r.same_classifier == 1 else "different classifiers, same occasion"
        units.append(dict(unit=r.study, design=des, system=r.system, kappa=r.kappa, se=r.se, n=r.n,
                          interval_days=r.interval_days, in_sample=int("in_sample" in r.flag), sens_flag=r.flag))
    U = pd.DataFrame(units)
    U.to_csv(out / "units.csv", index=False)
    results["units"] = U.to_dict(orient="records")

    # ---- Pooled by design
    pooled = {}
    for des, g in U[U.in_sample == 0].groupby("design"):
        pooled[des] = reml(g.kappa, g.se ** 2)
        pooled[des]["units"] = g.unit.tolist()
    # Sasang only, different classifiers same occasion
    g = U[(U.design == "different classifiers, same occasion") & (U.system == "Sasang") & (U.in_sample == 0)]
    pooled["different classifiers, same occasion (Sasang only)"] = reml(g.kappa, g.se ** 2)
    results["pooled"] = pooled

    # ---- Meta-regression: same classifier across occasions vs different classifiers same occasion
    M = U[(U.design.isin(["same classifier, across occasions", "different classifiers, same occasion"])) & (U.in_sample == 0)].copy()
    M["same_cls"] = (M.design == "same classifier, across occasions").astype(int)
    X = np.column_stack([np.ones(len(M)), M.same_cls])
    results["metareg_design"] = reml(M.kappa, M.se ** 2, X)
    results["metareg_design"]["terms"] = ["intercept (different classifiers, same occasion)", "same classifier across occasions"]
    # Sensitivity: Sasang only, and excluding derived/range-mid estimates
    Ms = M[M.system == "Sasang"]
    Xs = np.column_stack([np.ones(len(Ms)), Ms.same_cls])
    results["metareg_design_sasang"] = reml(Ms.kappa, Ms.se ** 2, Xs)
    Mr = M[~M.sens_flag.str.contains("range_mid|derived_kappa", regex=True)]
    Xr = np.column_stack([np.ones(len(Mr)), Mr.same_cls])
    results["metareg_design_reported_only"] = reml(Mr.kappa, Mr.se ** 2, Xr)
    results["metareg_design_reported_only"]["units"] = Mr.unit.tolist()

    # ---- Retest agreement (po) against interval, self-report instruments
    R = d[(d.design == "retest") & (d.classifier_a == "instrument")].copy()
    R = R[~R.id.isin([19])]  # row 19 overlaps row 18's sample
    R["logit_po"] = np.log(R.po / (1 - R.po))
    R["v"] = 1 / (R.n * R.po * (1 - R.po))
    R["log_days"] = np.log(R.interval_days)
    X = np.column_stack([np.ones(len(R)), R.log_days])
    results["po_vs_interval"] = reml(R.logit_po, R.v, X)
    results["po_vs_interval"]["rows"] = R[["study", "interval_days", "n", "po"]].to_dict(orient="records")

    # ---- KS-15 bounds analysis
    k2, k2se = d.loc[d.id == 15, ["kappa", "se"]].iloc[0]
    k1, k1se = d.loc[d.id == 16, ["kappa", "se"]].iloc[0]
    pe1 = float(d.loc[d.id == 16, "pe"].iloc[0])
    sims = 200000
    a = RNG.normal(k2, k2se, sims)
    b = RNG.normal(k1, k1se, sims)
    pi = (1 - b / a) * (1 - pe1)
    results["ks15_bound"] = {
        "kappa_2wk": k2, "kappa_1yr": k1, "pe_1yr": pe1,
        "ratio": k1 / k2,
        "pi_upper_point": (1 - k1 / k2) * (1 - pe1),
        "pi_upper_ci": [float(np.quantile(pi, 0.025)), float(np.quantile(pi, 0.975))],
    }

    # ---- Expert across-occasion vs expert same-occasion (direct contrast)
    e_same = U[U.unit.str.startswith("Baek 2014 inter-expert")].iloc[0]
    e_cross = U[U.unit.str.startswith("Jang 2012c")].iloc[0]
    diff = e_cross.kappa - e_same.kappa
    dse = np.sqrt(e_cross.se ** 2 + e_same.se ** 2)
    results["expert_contrast"] = {
        "cross_occasion_same_expert": e_cross.kappa, "same_occasion_different_experts": e_same.kappa,
        "diff": diff, "ci": [diff - 1.96 * dse, diff + 1.96 * dse], "p": float(2 * stats.norm.sf(abs(diff / dse))),
    }
    with open(out / "results.json", "w") as f:
        json.dump(results, f, indent=2, default=lambda o: None if (isinstance(o, float) and np.isnan(o)) else o)
    return U, results


if __name__ == "__main__":
    U, res = main(sys.argv[1], sys.argv[2])
    pd.set_option("display.width", 200)
    print(U[["unit", "design", "kappa", "se"]].round(3).to_string())
    for k, v in res["pooled"].items():
        print(f"\n{k}: k={v['k']} kappa={v['beta'][0]:.3f} [{v['ci_low'][0]:.3f},{v['ci_high'][0]:.3f}] "
              f"tau2={v['tau2']:.4f} I2={v['I2']:.2f} PI=[{v.get('pi_low', float('nan')):.3f},{v.get('pi_high', float('nan')):.3f}]")
    for key in ["metareg_design", "metareg_design_sasang", "metareg_design_reported_only"]:
        m = res[key]
        print(f"\n{key}: k={m['k']} b0={m['beta'][0]:.3f} b1={m['beta'][1]:.3f} "
              f"[{m['ci_low'][1]:.3f},{m['ci_high'][1]:.3f}] p={m['z_p'][1]:.4f} tau2={m['tau2']:.4f}")
    m = res["po_vs_interval"]
    print(f"\npo vs log interval: k={m['k']} slope={m['beta'][1]:.3f} [{m['ci_low'][1]:.3f},{m['ci_high'][1]:.3f}] p={m['z_p'][1]:.4f}")
    print("\nKS-15 bound:", json.dumps(res["ks15_bound"], indent=1))
    print("\nExpert contrast:", json.dumps(res["expert_contrast"], indent=1))
