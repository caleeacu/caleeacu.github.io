"""
Joint (eight-type) latent trait-state model for the four-visit, two-panel design of paper 5.

Differs from lm.py in two ways:
  1. It is fitted to the eight-type calls, so both levels (group, form) are estimated from one model, and the
     lasting-change share at each level is read off the joint transition matrix:
        Delta_group = sum_{c1,c2} pi_c1 G[c1,c2] 1[group(c1) != group(c2)], Delta_form likewise for form.
  2. A passing state is drawn from a trait-dependent kernel: with prob s_b the presented type is z ~ R[c, :],
     where c is the block trait.  A state that redraws the form within the patient's group (or the group with
     the form kept) is therefore representable, which the single-level model of lm.py could not do.
Optional panel-shared misreading: with prob d_P a panel reads, at both of its visits, a type a ~ Omega_P[c1, :]
that depends on the patient's baseline trait (so a misreading of the form within the group is representable).  EM is exact; SQUAREM acceleration with a monotone fallback.
"""
import numpy as np

PANEL_VISITS = {0: (0, 3), 1: (1, 2)}
BLOCK = (0, 0, 1, 1)
EPS = 1e-12
K = 8
GRP = np.arange(8) // 2
FRM = np.arange(8) % 2
DG = (GRP[:, None] != GRP[None, :]).astype(float)
DF = (FRM[:, None] != FRM[None, :]).astype(float)


def _norm(x, axis=-1):
    return x / np.maximum(x.sum(axis, keepdims=True), EPS)


def init_params(panel, rng=None, acc=0.7):
    off = (1 - acc) / (K - 1)
    M0 = np.full((K, K), off) + np.eye(K) * (acc - off)
    R0 = _norm(np.ones((K, K)) - np.eye(K))
    p = dict(pi=np.full(K, 1 / K), G=0.9 * np.eye(K) + 0.1 / K, s=np.array([0.05, 0.05]), R=R0,
             M=[[M0.copy() for _ in range(3)] for _ in range(4)],
             d=np.array([0.02, 0.02]) if panel else np.zeros(2), om=[_norm(np.ones((K, K)) - np.eye(K)), _norm(np.ones((K, K)) - np.eye(K))])
    if rng is not None:
        p["pi"] = _norm(rng.dirichlet(np.ones(K)) + 0.2)
        p["G"] = _norm(np.eye(K) * rng.uniform(0.6, 0.95) + rng.dirichlet(np.ones(K), K) * 0.2)
        p["s"] = rng.uniform(0.01, 0.15, 2)
        p["R"] = _norm(rng.dirichlet(np.ones(K), K))
        p["M"] = [[_norm(np.eye(K) * rng.uniform(0.4, 0.8) + rng.dirichlet(np.ones(K), K) * (1 - acc)) for _ in range(3)]
                  for _ in range(4)]
        if panel:
            p["d"] = rng.uniform(0.005, 0.08, 2)
    return p


def _pack(p):
    return np.concatenate([p["pi"], p["G"].ravel(), p["s"], p["R"].ravel(), np.ravel(p["M"]), p["d"], np.ravel(p["om"])])


def _unpack(x):
    i = 0
    def take(m):
        nonlocal i
        out = x[i:i + m]; i += m; return out
    p = dict(pi=take(K), G=take(K * K).reshape(K, K), s=take(2), R=take(K * K).reshape(K, K))
    Mf = take(4 * 3 * K * K).reshape(4, 3, K, K)
    p["M"] = [[Mf[v, r] for r in range(3)] for v in range(4)]
    p["d"] = take(2); p["om"] = list(take(2 * K * K).reshape(2, K, K))
    return p


def _project(p, panel):
    cl = lambda a: np.clip(a, 1e-10, None)
    return dict(pi=_norm(cl(p["pi"])), G=_norm(cl(p["G"])), s=np.clip(p["s"], 1e-6, 0.95), R=_norm(cl(p["R"])),
                M=[[_norm(cl(m)) for m in row] for row in p["M"]],
                d=np.clip(p["d"], 1e-6, 0.5) if panel else np.zeros(2), om=[_norm(cl(o)) for o in p["om"]])


def em_step(Y, wt, oh, panel, p):
    n = wt.sum()
    e = [np.prod([p["M"][v][r][:, Y[:, v, r]].T for r in range(3)], axis=0) for v in range(4)]   # u x K (read cat)
    eR = [e[v] @ p["R"].T for v in range(4)]                       # u x K (trait): sum_z R[c,z] e[u,z]
    L = [(1 - p["s"][BLOCK[v]]) * e[v] + p["s"][BLOCK[v]] * eR[v] for v in range(4)]
    F, Fparts = [], []
    for P_, (va, vb) in PANEL_VISITS.items():
        ee = e[va] * e[vb]
        den = np.maximum(ee @ p["om"][P_].T, 1e-300)
        none = (1 - p["d"][P_]) * L[va][:, :, None] * L[vb][:, None, :]
        mis = p["d"][P_] * den
        F.append(none + mis[:, :, None]); Fparts.append((none, mis, ee, den))
    joint = p["pi"][None, :, None] * p["G"][None] * F[0] * F[1]
    lik = np.maximum(joint.sum((1, 2)), 1e-300)
    ll = float(wt @ np.log(lik))
    w = joint / lik[:, None, None] * wt[:, None, None]
    newp = dict(pi=_norm(w.sum((0, 2))), G=_norm(w.sum(0) + 1e-9))
    exp_state = np.zeros(2); R_cnt = np.zeros((K, K)); d_cnt = np.zeros(2); om_cnt = [np.zeros((K, K)), np.zeros((K, K))]
    readpost = [None] * 4
    for P_, (va, vb) in PANEL_VISITS.items():
        none, mis, ee, den = Fparts[P_]
        Ftot = np.maximum(F[P_], 1e-300)
        r_none = w * (none / Ftot)
        wm = w * (mis[:, :, None] / Ftot)
        pm = wm.sum((1, 2))
        d_cnt[P_] = pm.sum()
        wc1 = wm.sum(2) / den
        om_cnt[P_] += p["om"][P_] * (wc1.T @ ee)
        am = (wc1 @ p["om"][P_]) * ee
        for v, first in ((va, True), (vb, False)):
            q = r_none.sum(2 if first else 1)
            qm = wm.sum(2 if first else 1)
            sb = p["s"][BLOCK[v]]
            Lv = np.maximum(L[v], 1e-300)
            trait_part = q * (1 - sb) * e[v] / Lv
            a = q * sb / Lv
            state_part = (a @ p["R"]) * e[v]
            R_cnt += p["R"] * (a.T @ e[v]) + sb * qm.sum(0)[:, None] * p["R"]
            exp_state[BLOCK[v]] += state_part.sum() + sb * pm.sum()
            readpost[v] = trait_part + state_part + am
    newp["s"] = np.clip(exp_state / (2 * n), 1e-6, 0.95)
    newp["R"] = _norm(R_cnt + 1e-9)
    newp["M"] = [[_norm(readpost[v].T @ oh[v][r] + 1e-6) for r in range(3)] for v in range(4)]
    newp["d"] = np.clip(d_cnt / n, 1e-6, 0.5) if panel else np.zeros(2)
    newp["om"] = [_norm(om_cnt[P_] + 1e-9) for P_ in (0, 1)] if panel else p["om"]
    return newp, ll


def deltas(p):
    J = p["pi"][:, None] * p["G"]
    return float((J * DG).sum()), float((J * DF).sum())


def fit(Y, panel=False, iters=4000, tol=None, params=None):
    n = Y.shape[0]
    tol = 1e-8 * n if tol is None else tol
    U, wt = np.unique(Y.reshape(n, 12), axis=0, return_counts=True)
    U = U.reshape(-1, 4, 3); wt = wt.astype(float)
    oh = [[np.eye(K)[U[:, v, r]] for r in range(3)] for v in range(4)]
    step = lambda q: em_step(U, wt, oh, panel, q)
    p = params or init_params(panel)
    ll_old = -np.inf
    for it in range(iters):
        p1, ll0 = step(p)
        p2, ll1 = step(p1)
        x0, x1, x2 = _pack(p), _pack(p1), _pack(p2)
        r = x1 - x0; v = x2 - x1 - r
        nv = np.linalg.norm(v)
        alpha = min(-1.0, -np.linalg.norm(r) / nv if nv > 0 else -1.0)
        cand = _project(_unpack(x0 - 2 * alpha * r + alpha ** 2 * v), panel)
        p3, ll_c = step(cand)
        p, ll = (p3, ll_c) if ll_c >= ll1 else (p2, ll1)
        if abs(ll - ll_old) < tol:
            break
        ll_old = ll
    _, ll = step(p)
    return p, ll, deltas(p), it + 1


def fit_best(Y, panel=False, starts=2, seed=0, warm=None):
    rng = np.random.default_rng(seed)
    res = [fit(Y, panel)]
    if panel and warm is not None:
        w = {k: (v.copy() if isinstance(v, np.ndarray) else v) for k, v in warm.items()}
        w["M"] = [[m.copy() for m in row] for row in warm["M"]]
        w["d"] = np.array([0.01, 0.01]); w["om"] = [m.copy() for m in init_params(True)["om"]]
        res.append(fit(Y, True, params=w))
        w2 = dict(w); w2["d"] = np.array([0.25, 0.25])
        w2["om"] = [_norm(0.5 * np.eye(K) + 0.5 / K), _norm(0.5 * np.eye(K) + 0.5 / K)]
        res.append(fit(Y, True, params=w2))                 # a second warm start with a large panel term
    for _ in range(starts - 1):
        res.append(fit(Y, panel, params=init_params(panel, rng)))
    return max(res, key=lambda r: r[1])
