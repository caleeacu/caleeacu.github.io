"""Identifiability check for lm_joint.py: data drawn from the joint model itself (states at baseline only, drawn from a
within-group form kernel), n = 5,000, raters of accuracy 0.8. Prints (s0, [Delta_group, Delta_form], fitted s). Seed 3."""
import sys; sys.argv=['x']; sys.path.insert(0,'.'); sys.path.insert(0,'..')
import numpy as np, lm_joint as LJ
import paper5_sim as S
rng=np.random.default_rng(3); n=5000; K=8
pi=S.ECM
# kernel: redraw form from p(form|group)
R=np.zeros((8,8))
for c in range(8):
    g=c//2; R[c,2*g]=S.P_F_GIVEN_G[g,0]; R[c,2*g+1]=S.P_F_GIVEN_G[g,1]
def M(acc):  # simple
    m=np.full((8,8),(1-acc)/7); np.fill_diagonal(m,acc); return m
for s0 in (0.3,0.75):
    c1=rng.choice(8,n,p=pi); Y=np.zeros((n,4,3),int)
    for v in range(4):
        st=(rng.random(n)<(s0 if v<2 else 0))
        z=np.array([rng.choice(8,p=R[c]) for c in c1])
        read=np.where(st,z,c1)
        for r in range(3):
            cm=np.cumsum(M(0.8),1); Y[:,v,r]=(rng.random(n)[:,None]>cm[read]).sum(1)
    b=LJ.fit(Y,False); print(s0, np.round(b[2],3), np.round(b[0]['s'],3))
