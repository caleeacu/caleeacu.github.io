"""
Joint eight-type latent model (lm_joint.py) against the kappa-based estimator E, on studies simulated with the
data-generating model of paper5_sim.py.  Run from this folder:
  python sim7.py --part=SELF                 one large study per scenario (n = 20,000), several starts
  python sim7.py --part=CMP --reps=40        n = 1,000, point estimates at both levels
Seed 7072026.
"""
import sys, os, time
import numpy as np
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
_argv = sys.argv; sys.argv = [sys.argv[0]]
import paper5_sim as S
sys.argv = _argv
from sim6 import make_calls, level_arrays, kappa_E
import lm_joint as LJ

SEED = 7072026

# name, scenario dict, kwargs, (true group share, true form share)
SCEN7 = [
    ("Fixed", {}, {}, (0, 0)),
    ("Non-fixed: group 10%, form 10%", {"dg": 0.10, "df": 0.10}, {}, (0.10, 0.10)),
    ("Hierarchical: form 15%", {"df": 0.15}, {}, (0, 0.15)),
    ("Fixed + recurring form states 15%", {"rec_f": 0.15}, {}, (0, 0)),
    ("Fixed + recurring group states 15%", {"rec_g": 0.15}, {}, (0, 0)),
    ("Form 15% hidden by recurring form states 15%", {"df": 0.15, "rec_f": 0.15}, {}, (0, 0.15)),
    ("Group 15% hidden by recurring group states 15%", {"dg": 0.15, "rec_g": 0.15}, {}, (0.15, 0)),
    ("Fixed + form states 30% per visit, baseline only", {"rec_f_v": (0.3, 0.3, 0, 0)}, {}, (0, 0)),
    ("Fixed + group states 30% per visit, baseline only", {"rec_g_v": (0.3, 0.3, 0, 0)}, {}, (0, 0)),
    ("Form 10%, partner-structured errors", {"df": 0.10}, {"mode": "side"}, (0, 0.10)),
    ("Form 10%, legibility falls for all", {"df": 0.10}, {"fall": (0.10, 0.05)}, (0, 0.10)),
    ("Form 10% + misreading within each panel 10%", {"df": 0.10, "shared": ("f", 0.10)}, {}, (0, 0.10)),
    ("Fixed + legibility lost by 30% of patients", {}, {"patfall": (0.3, 0.25, 0.95)}, (0, 0)),
    ("Form 10% + rater memory 50%", {"df": 0.10}, {"memory": 0.5}, (0, 0.10)),
    ("Fixed + form state through follow-up block 15%", {"blk_f": 0.15}, {}, (0, 0.15)),
]


def one(n, sc, kw, rng, starts, panel):
    R = make_calls(n, sc, rng, **kw)
    Y8 = np.stack([np.stack(R[v], 1) for v in range(4)], 1)
    Eg = kappa_E(level_arrays(R, "group")[0], 4)[0]
    Ef = kappa_E(level_arrays(R, "form")[0], 2)[0]
    b0 = LJ.fit_best(Y8, False, starts=starts, seed=int(rng.integers(1e9)))
    out = [Eg, Ef, *b0[2]]
    if panel:
        b1 = LJ.fit_best(Y8, True, starts=starts, seed=int(rng.integers(1e9)), warm=b0[0])
        out += list(b1[2])
    return out


def run(say, n, reps, starts, panel):
    say(f"n = {n}, {reps} studies per row, group accuracy 0.8, form accuracy 0.95; point estimates of the lasting-change share")
    hdr = "scenario | truth g, f | E group: mean (SD) | E form | joint LM group | joint LM form"
    say(hdr + (" | joint LM+panel group | joint LM+panel form" if panel else ""))
    rng = np.random.default_rng(SEED + n)
    for name, sc, kw, truth in SCEN7:
        a = np.array([one(n, sc, kw, rng, starts, panel) for _ in range(reps)])
        tr = [truth[0], truth[1]] * (a.shape[1] // 2)
        cells = [f"{a[:, j].mean():.3f} ({a[:, j].std():.3f}; RMSE {np.sqrt(((a[:, j] - tr[j]) ** 2).mean()):.3f})"
                 for j in range(a.shape[1])]
        say(f"{name} | {truth[0]:.2f}, {truth[1]:.2f} | " + " | ".join(cells))


if __name__ == "__main__":
    part = [a.split("=")[1] for a in sys.argv if a.startswith("--part=")][0]
    reps = int(([a.split("=")[1] for a in sys.argv if a.startswith("--reps=")] or ["40"])[0])
    only = [a.split("=")[1] for a in sys.argv if a.startswith("--rows=")]
    if only:
        idx = [int(i) for i in only[0].split(",")]; SCEN7[:] = [SCEN7[i] for i in idx]
    lines = []; say = lambda s="": (print(s, flush=True), lines.append(s))
    t = time.time()
    if part == "SELF":
        run(say, 5000, int(([a.split("=")[1] for a in sys.argv if a.startswith("--reps=")] or ["2"])[0]), 1, True)
    else:
        run(say, 1000, reps, 1, "--panel" in sys.argv)
    say(f"(elapsed {time.time() - t:.0f} s)")
    open(f"sim7_output_{part}{'_' + only[0].replace(',', '-') if only else ''}.txt", "w").write("\n".join(lines) + "\n")
