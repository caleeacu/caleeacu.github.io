Code and output for:
  Lee, H. (2026). What Counts as Error? A Structured Review and Meta-Analysis of Agreement in Korean Constitutional Diagnosis, by Who Classifies and When. SSRN Working Paper (paper 4).
  Lee, H. (2026). At What Level Is Constitution Fixed? Separating Lasting Change, Passing State and Rater Error in a Nested Categorical Diagnosis. SSRN Working Paper (paper 5).

Requirements: Python 3 with NumPy; SciPy and pandas for paper4/meta and paper4/search; matplotlib only for the figures. Run each script from its own folder
(ratio_check.py and sim_extra.py import simulation.py; scripts in latent/ import paper5_sim.py from the folder above). All scripts use fixed seeds. Set OMP_NUM_THREADS=1.

paper4/search/  logged search and screening (paper 4, sections 2.1-2.3 and 3.1, Figure 1)
  protocol.md     the protocol written before the logged search (not registered; note at the top)
  search_log.csv  every search run on 8-9 November 2026 with its date and number of records,
                  including searches that returned nothing, failed, or were not parsed
  records_kci_pubmed_koreascience.csv   the records logged during screening, with bibliographic details
  screening_log.csv   one row per unique record screened (database and other methods), with stage,
                  decision, reason and the included report it became
  prisma.py       counts every box of the PRISMA 2020 diagram from the two logs and draws it:
                    python3 prisma.py      (writes figure1_prisma.png and prisma_counts.txt)
paper4/meta/   meta-analysis (paper 4, sections 2.4-2.7 and 3.1-3.4, Table 1, Figure 2)
  extraction.csv  every included estimate (34 rows from 23 reports), with source, design class and flags
  excluded.csv    reports excluded at full text or not retrieved, and estimates excluded within included reports
  analysis.py     REML pooling by design and by type of pair, meta-regression, sensitivity analyses,
                  percentage agreement against interval (section 3.3), KS-15 change bound (3.4),
                  specialist contrast (3.2):
                    python3 analysis.py extraction.csv out      (writes out/units.csv and out/results.json)
  analysis_output.txt, units.csv, results.json   the output of that command, as reported in the paper
  forest.py       Figure 2:  python3 forest.py units.csv results.json figure2_forest.png
paper4/        reanalysis of published cross-tabulations (paper 4, sections 2.8 and 3.5, Tables 2-3) and earlier simulations
  reanalysis.py   -> reanalysis_output.txt   five tables from the first version (KS-15 retest, three specialists
                                             against a reference, SCAT, KS-15 in Japan, ECM questionnaire), the
                                             independence test, level-wise kappa, the reference-conditioned null.
  added_tables_levels.py -> added_tables_levels_output.txt   level-wise kappa and yin-yang crossing for the other
                                             eight Sasang tables in Table 3 (Lee JH 2007 and the seven tables added
                                             by the logged search); imports reanalysis.py.
  simulation.py, sim_extra.py, ratio_check.py and their outputs: simulations from the earlier version of paper 4,
                  kept for reproducibility of that version; the current paper does not report them.
                  sim_extra.py run on its own uses another seed.

paper5/
  paper5_sim.py   -> paper5_sim_output.txt   every number in sections 6.1 and 6.2 and Appendix A (seed 5052026).
                     Run one part at a time, e.g.
                       OMP_NUM_THREADS=1 python paper5_sim.py --part=B --facc=0.95 --n=1000
                       OMP_NUM_THREADS=1 python paper5_sim.py --part=P --cell=1
                     The script header lists every part. Parts P (full registered rule, all scenarios) and
                     Q (full rule near the margin) give Table 3 and section 6.2.
  figure1.py      -> figure1.png             Figure 1 of paper 5 (section 6.2), read from the output file.
  latent/lm.py                               single-level latent trait-state model (the "earlier model of one level
                                             at a time" in section 6.3); sim6.py -> sim6_output.txt gives its numbers.
  latent/lm_joint.py                         joint eight-type latent trait-state model of section 4.3 (EM with SQUAREM;
                                             type-dependent state kernel; optional panel misreading).
  latent/sim7.py  -> latent/sim7_output_CMP.txt   Table 4 (section 6.3):  python3 sim7.py --part=CMP --reps=40 --panel
                                             (seed 7072026; rows can be split across processes with --rows=0,1,2 ...)
  latent/selftest_joint.py -> latent/selftest_joint_output.txt   self-consistency check of section 4.3
                                             (prints true state probability, fitted change shares, fitted state probability).

Author: Hoon Lee, L.Ac. (caleeacu@gmail.com)

Version: November 2026 (final versions of papers 4 and 5).
