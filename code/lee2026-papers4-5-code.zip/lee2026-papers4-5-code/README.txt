Code and output for:
  Lee, H. (2026). What Counts as Error? Constitutional Diagnosis, Reliability Statistics, and the Ontology They Presuppose. SSRN Working Paper (paper 4).
  Lee, H. (2026). At What Level Is Constitution Fixed? A Staged Design That Measures Pulse Readability Before Testing Fixed, Non-Fixed and Hierarchical Accounts of Eight Constitution Medicine. SSRN Working Paper (paper 5).

Requirements: Python 3 with NumPy (matplotlib only for the figure). Run each script from its own folder
(ratio_check.py and sim_extra.py import simulation.py). All scripts use fixed seeds. Set OMP_NUM_THREADS=1.

paper4/
  reanalysis.py   -> reanalysis_output.txt   Section 7: all five published tables, the independence test of 7.2,
                                             level-wise kappa (Table 7), the reference-conditioned null of 7.3.
  simulation.py   -> simulation_output.txt   Section 6 (runs sim_extra.py; over an hour single-threaded).
                     Paper sections and output headers:
                       6.1 Table 1     <- "6.1" and "6.5a", "6.5b" (base-rate-aware rater, cited in the text)
                       6.2 Table 2     <- "6.2"
                       6.3 Tables 3-4  <- "6.3", "6.5d", and the "Checks" block
                       6.4 Table 5     <- "6.6" and "6.6b"
                     The output also contains analyses from earlier drafts that the paper no longer reports
                     (6.4 G-study, 6.5c, 6.5e, 6.5f); they are kept so that every reported number is reproduced
                     with the same random-number stream.
                     sim_extra.py run on its own uses another seed and does not reproduce the paper.
  ratio_check.py  -> ratio_check_output.txt  supplementary check of the stability ratio cited in 6.3.

paper5/
  paper5_sim.py   -> paper5_sim_output.txt   all simulated numbers. Run one part at a time, e.g.
                       OMP_NUM_THREADS=1 python paper5_sim.py --part=B --facc=0.95 --n=1000
                       OMP_NUM_THREADS=1 python paper5_sim.py --part=P --cell=1
                     The script header lists every part. The supplied output concatenates parts
                     A, E, F, B, C, G, H, I, J, K, M, L, N, O (from the earlier draft; unchanged) and the new parts
                     P (full registered rule, all scenarios; cells 0-2) and Q (full rule near the margin).
  figure1.py      -> figure1.png             operating-characteristic curves (paper 5, Figure 1, section 7.1), read from the output file.
  latent/lm.py                               latent trait-state model (section 6 and Appendix B.2): EM with SQUAREM acceleration,
                                             optional shared-error term within each rater panel.
  latent/sim6.py  -> latent/sim6_output.txt  (joins the runs) run from latent/:  python sim6.py --part=SELF   (identifiability, data drawn from
                                             the model, n = 50,000)   and   python sim6.py --part=CMP --level=form|group
                                             (Table B2 of paper 5). Imports paper5_sim.py from the folder above. Seed 6062026.

Author: Hoon Lee, L.Ac. (caleeacu@gmail.com)
