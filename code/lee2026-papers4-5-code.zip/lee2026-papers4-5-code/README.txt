Code and output for:
  Lee, H. (2026). What Counts as Error? Constitutional Diagnosis, Reliability Statistics, and the Ontology They Presuppose. SSRN Working Paper (paper 4).
  Lee, H. (2026). At What Level Is Constitution Fixed? A Pre-Registrable Design for Telling Fixed, Non-Fixed and Hierarchical Accounts of Eight Constitution Medicine Apart. SSRN Working Paper (paper 5).

Requirements: Python 3 with NumPy. Run each script from its own folder (ratio_check.py and sim_extra.py import simulation.py). All scripts use fixed seeds. simulation.py takes over an hour single-threaded (set OMP_NUM_THREADS=1).

paper4/
  simulation.py, sim_extra.py  -> simulation_output.txt (Sections 6.1-6.6). Run simulation.py, which imports sim_extra.py;
                                  sim_extra.py run on its own uses another seed and does not reproduce the paper.
  reanalysis.py                -> reanalysis_output.txt (Section 7)
  ratio_check.py               -> ratio_check_output.txt (stability-ratio check cited in Section 6.5; imports simulation.py)
paper5/
  paper5_sim.py                -> paper5_sim_output.txt
  Run one part at a time, e.g.  OMP_NUM_THREADS=1 python paper5_sim.py --part=B --facc=0.95 --n=1000
  The script's header lists every part; the supplied output concatenates all parts.

Author: Hoon Lee, L.Ac. (caleeacu@gmail.com)
