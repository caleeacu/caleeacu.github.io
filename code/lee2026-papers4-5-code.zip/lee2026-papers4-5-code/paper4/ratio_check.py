"""
Supplementary check for Lee (2026), What Counts as Error?, sections 5.2 and 6.3.
Stability ratio (cross-occasion between-rater kappa / geometric mean of same-day kappas, eight types)
under the conditions of section 6.3 (group accuracy 0.85, form accuracy 0.80, 3 raters, 300,000 persons),
with the composition of change varied and with even or partner-structured rater errors.
Uses the functions of simulation.py (same folder). Run: python ratio_check.py  (writes ratio_check_output.txt)
"""
import numpy as np
import simulation as S

SEED = 5052027


def main():
    rng = np.random.default_rng(SEED)
    N = 300_000
    lines = ["composition of change (45% of persons change in all rows) | errors | stability ratio | true kappa | share held"]
    for pf, pg, label in [(0.35, 0.10, "as in 6.3: 35% form, 10% group"), (0.45, 0.0, "all form within group"),
                          (0.225, 0.225, "half form, half group"), (0.0, 0.45, "all to another group")]:
        for mode in ("even", "side"):
            t1 = rng.choice(8, N, p=S.ECM)
            t2 = S.change_types(t1, pf, pg, rng, "partner")
            r1 = [S.ecm_rater(t1, 0.85, 0.80, rng, mode, 0.6) for _ in range(3)]
            r2 = [S.ecm_rater(t2, 0.85, 0.80, rng, mode, 0.6) for _ in range(3)]
            k1 = S.mean_pairwise(r1, r1, 8, True); k2 = S.mean_pairwise(r2, r2, 8, True)
            kx = S.mean_pairwise(r1, r2, 8, False)
            lines.append(f"{label:32s} | {mode:4s} | {S.stability_ratio(k1, k2, kx):.3f} | {S.kappa(t1, t2, 8):.3f} | {np.mean(t1 == t2):.3f}")
    print("\n".join(lines))
    open("ratio_check_output.txt", "w").write("\n".join(lines) + "\n")


if __name__ == "__main__":
    main()
