"""
Reanalysis of published Sasang and ECM cross-tabulations (Section 7 of
Lee, H. (2026). What Counts as Error? ...).

Data are transcribed from the published tables:
  KS-15 test-retest: Kim Y, Jang E. J Physiol Pathol Korean Med 2016;30(3):177-183, Table 4.
  Expert vs database: Baek YH et al. J Sasang Constitut Med 2014;26(3):295-303, Tables 3-4.
Type order: 0 Taeeum (TE), 1 Soeum (SE), 2 Soyang (SY). Taeyang did not occur.
  ECM questionnaire model vs pulse diagnosis: Min J, Kim M, Park Y, Park Y.
    J Korea Inst Orient Med Diagn 2007;11(2):27-44, Table 11 (in-sample predictions
    of a multinomial logistic model on seven factor scores, n=409).
Run: python reanalysis.py
"""
import numpy as np

TYPES = ["Taeeum", "Soeum", "Soyang"]
YANG = np.array([0, 0, 1])   # yin types (Taeeum, Soeum) vs yang type (Soyang)

# KS-15: rows = retest, cols = first test
KS15 = np.array([[54, 0, 9], [2, 137, 10], [7, 11, 73]])

# Baek 2014, Table 3: rows = expert diagnosis, cols = database diagnosis
BAEK = {
    "A": np.array([[22, 3, 8], [1, 10, 2], [10, 8, 15]]),   # 79 valid calls
    "B": np.array([[23, 6, 11], [2, 9, 3], [9, 6, 12]]),
    "C": np.array([[27, 5, 10], [2, 11, 3], [5, 5, 13]]),
}
# Baek 2014, Table 4: cases on which experts agreed, common call vs database
BAEK_CONSENSUS = {
    "A&B": np.array([[16, 3, 2], [0, 6, 0], [4, 3, 7]]),
    "A&C": np.array([[20, 2, 6], [1, 8, 0], [3, 4, 10]]),
    "B&C": np.array([[22, 3, 5], [0, 7, 1], [5, 3, 8]]),
    "A&B&C": np.array([[16, 2, 2], [0, 6, 0], [3, 2, 6]]),
}
# Min 2007, Table 11: rows = pulse-diagnosed type, cols = questionnaire-model prediction
# order: Hep, Cho, Pan, Gas, Pul, Col, Ren, Ves  (groups: Wood, Earth, Metal, Water)
ECM_TYPES = ["Hep", "Cho", "Pan", "Gas", "Pul", "Col", "Ren", "Ves"]
MIN2007 = np.array([
    [61,  8,  0, 0,  0,  0,  0,  0],
    [18,  9,  1, 0,  0,  0,  0,  2],
    [ 0,  1, 94, 0,  2,  0,  0,  0],
    [ 0,  0,  0, 2,  0,  0,  1,  0],
    [ 0,  0,  2, 0, 68,  3,  0,  1],
    [ 1,  0,  0, 0,  4, 74,  1,  1],
    [ 0,  0,  0, 0,  0,  2, 14,  6],
    [ 0,  0,  0, 0,  1,  0,  5, 27],
])
MIN_PCT_CORRECT = [88.4, 30.0, 96.9, 66.7, 91.9, 91.4, 63.6, 81.8]
ECM_GROUP = np.array([0, 0, 1, 1, 2, 2, 3, 3])
# Vagotonia (Wood, Earth) vs sympathicotonia (Metal, Water), as stated in Min 2007, p. 28
ECM_SIDE = np.array([0, 0, 0, 0, 1, 1, 1, 1])

PUBLISHED_KAPPA = {"KS15": 0.794, "A": 0.376, "B": 0.287, "C": 0.421,
                   "A&B": 0.537, "A&C": 0.532, "B&C": 0.484, "A&B&C": 0.604}


def stats(M):
    M = np.asarray(M, float)
    n = M.sum()
    P = M / n
    pr, pc = P.sum(1), P.sum(0)
    po = np.trace(P)
    pe = pr @ pc
    kappa = (po - pe) / (1 - pe)
    pi = (pr + pc) / 2
    k = len(pi)
    pe_ac1 = np.sum(pi * (1 - pi)) / (k - 1)
    ac1 = (po - pe_ac1) / (1 - pe_ac1)
    pabak = (k * po - 1) / (k - 1)
    pmax = np.minimum(pr, pc).sum()
    kmax = (pmax - pe) / (1 - pe)
    bias = 0.5 * np.abs(pr - pc).sum()          # share of calls that would have to move to equalise marginals
    return dict(n=int(n), po=po, pe=pe, kappa=kappa, ac1=ac1, pabak=pabak, kmax=kmax, bias=bias, pr=pr, pc=pc)


def collapse(M, groups):
    g = np.max(groups) + 1
    out = np.zeros((g, g))
    for i in range(M.shape[0]):
        for j in range(M.shape[1]):
            out[groups[i], groups[j]] += M[i, j]
    return out


def main():
    lines = []
    say = lambda s="": (print(s), lines.append(s))

    say("=== Extraction check: recomputed vs published kappa ===")
    for name, M in [("KS15", KS15)] + list(BAEK.items()) + list(BAEK_CONSENSUS.items()):
        s = stats(M)
        say(f"{name:6s} n={s['n']:3d} po={s['po']:.3f} kappa={s['kappa']:.3f} (published {PUBLISHED_KAPPA[name]:.3f})")

    say("\n=== KS-15, two-week test-retest (self-report questionnaire) ===")
    s = stats(KS15)
    say(f"po {s['po']:.3f}  chance floor {s['pe']:.3f}  kappa {s['kappa']:.3f}  AC1 {s['ac1']:.3f}  PABAK {s['pabak']:.3f}  "
        f"kappa max {s['kmax']:.3f}  marginal shift {s['bias']*100:.1f}%")
    stay = np.diag(KS15) / KS15.sum(0)
    say("share keeping the same type at retest: " + ", ".join(f"{t} {x*100:.1f}%" for t, x in zip(TYPES, stay)))
    sb = stats(collapse(KS15, YANG))
    say(f"yin/yang level: po {sb['po']:.3f}  kappa {sb['kappa']:.3f}")

    say("\n=== Baek 2014: each expert vs database diagnosis (reference = response to constitutional herbs) ===")
    conf_pairs = {"TE-SE": 0, "TE-SY": 0, "SE-SY": 0}
    for name, M in BAEK.items():
        s = stats(M)
        sens = np.diag(M) / M.sum(0)
        ppv = np.diag(M) / M.sum(1)
        sb = stats(collapse(M, YANG))
        say(f"Expert {name}: n {s['n']} po {s['po']:.3f} chance floor {s['pe']:.3f} kappa {s['kappa']:.3f} AC1 {s['ac1']:.3f} "
            f"kappa max {s['kmax']:.3f} marginal shift {s['bias']*100:.1f}% | yin/yang po {sb['po']:.3f} kappa {sb['kappa']:.3f}")
        say("    sensitivity " + ", ".join(f"{t} {x*100:.0f}%" for t, x in zip(TYPES, sens)) +
            " | PPV " + ", ".join(f"{t} {x*100:.0f}%" for t, x in zip(TYPES, ppv)))
        conf_pairs["TE-SE"] += M[0, 1] + M[1, 0]
        conf_pairs["TE-SY"] += M[0, 2] + M[2, 0]
        conf_pairs["SE-SY"] += M[1, 2] + M[2, 1]
    tot = sum(conf_pairs.values())
    say("errors by type pair, three experts pooled: " +
        ", ".join(f"{k} {v} ({v/tot*100:.0f}%)" for k, v in conf_pairs.items()) + f"; total {tot}")

    say("\n=== Baek 2014: do the specialists err together? (independence null) ===")
    # Under conditional independence each specialist calls c for a patient of reference type t
    # with probability P_k(c|t), estimated from his own table (plug-in). Expected counts of
    # agreement, and of agreement on a wrong call, follow analytically.
    db = np.array([34, 21, 26]) / 81
    dbA = BAEK['A'].sum(0) / BAEK['A'].sum()   # reference mix of the 79 patients in A's table (33/21/25)
    dbm = lambda members: dbA if 'A' in members else db
    cond = {k: M / M.sum(0) for k, M in BAEK.items()}
    sets = {"A&B": ("A", "B"), "A&C": ("A", "C"), "B&C": ("B", "C"), "A&B&C": ("A", "B", "C")}
    from math import comb
    def upper_tail(n, p, x):
        return sum(comb(n, k) * p**k * (1 - p)**(n - k) for k in range(x, n + 1))
    for name, members in sets.items():
        N = 79 if "A" in members else 81
        p_agree = p_wrong = 0.0
        for t in range(3):
            for c in range(3):
                pr = dbm(members)[t] * np.prod([cond[m][c, t] for m in members])
                p_agree += pr
                if c != t:
                    p_wrong += pr
        T = BAEK_CONSENSUS[name]
        obs_agree, obs_wrong = int(T.sum()), int(T.sum() - np.trace(T))
        say(f"{name:6s} N={N}: agreed {obs_agree} (expected {N*p_agree:.1f}, P={upper_tail(N, p_agree, obs_agree):.2g}); "
            f"agreed on a wrong call {obs_wrong} (expected {N*p_wrong:.1f}, P={upper_tail(N, p_wrong, obs_wrong):.2g}); "
            f"accuracy when agreeing {np.trace(T)/T.sum()*100:.1f}% (expected {(p_agree-p_wrong)/p_agree*100:.1f}%)")
    # parametric bootstrap for the unanimous-wrong count: re-estimate each specialist's
    # conditional call probabilities from his own (resampled) table on every draw
    def p_wrong_set(c, members):
        return sum(dbm(members)[t] * np.prod([c[m][cc, t] for m in members]) for t in range(3) for cc in range(3) if cc != t)
    rngb = np.random.default_rng(5)
    Bdraws = 20000
    exceed = {name: 0 for name in sets}
    for _ in range(Bdraws):
        cb = {}
        for k, M in BAEK.items():
            cols = [rngb.multinomial(int(M[:, t].sum()), M[:, t] / M[:, t].sum()) / M[:, t].sum() for t in range(3)]
            cb[k] = np.array(cols).T
        for name, members in sets.items():
            N = 79 if "A" in members else 81
            T = BAEK_CONSENSUS[name]
            exceed[name] += rngb.binomial(N, p_wrong_set(cb, members)) >= int(T.sum() - np.trace(T))
    for name in sets:
        say(f"parametric bootstrap P(same wrong call count at least as observed), {name}: {exceed[name]/Bdraws:.4f}")
    say(f"parametric bootstrap P(>= 9 unanimous wrong calls) = {exceed['A&B&C']/Bdraws:.4f}")
    # exact conditional test for the pair B and C (both tables cover the same 81 patients): permute C's calls
    # among patients of the same reference type, keeping both specialists' tables fixed (Monte Carlo, 200,000 draws)
    rngp = np.random.default_rng(7); Rp = 200000
    Wp = np.zeros(Rp); Ap = np.zeros(Rp)
    for t in range(3):
        bcalls = np.repeat(np.arange(3), BAEK["B"][:, t]); ccalls = np.repeat(np.arange(3), BAEK["C"][:, t])
        cp = ccalls[np.argsort(rngp.random((Rp, len(ccalls))), axis=1)]
        same = cp == bcalls
        Ap += same.sum(1); Wp += (same & (bcalls != t)).sum(1)
    T = BAEK_CONSENSUS["B&C"]
    say(f"exact within-reference permutation test, B&C: P(same wrong call >= {int(T.sum() - np.trace(T))}) = {np.mean(Wp >= T.sum() - np.trace(T)):.4f}; "
        f"P(agreement >= {int(T.sum())}) = {np.mean(Ap >= T.sum()):.5f}")
    errs = sum(BAEK.values()); off = errs.sum() - np.trace(errs)
    cross = errs[0, 2] + errs[2, 0] + errs[1, 2] + errs[2, 1]
    say(f"errors crossing the yin/yang line: {cross} of {off} ({cross/off*100:.0f}%); structural share if errors were spread evenly over the three pairs: 67%")
    cross_gl = errs[0, 1] + errs[1, 0] + errs[0, 2] + errs[2, 0]
    say(f"errors crossing the greater/lesser line (Taeeum vs Soeum, Soyang): {cross_gl} of {off} ({cross_gl/off*100:.0f}%); even spread: 67%")
    GL = np.array([0, 1, 1])   # greater (Taeeum) vs lesser (Soeum, Soyang)
    for name, M in [("KS-15", KS15)] + [(f"Specialist {k}", M) for k, M in BAEK.items()]:
        st = stats(collapse(M, GL))
        say(f"{name}: greater/lesser kappa {st['kappa']:.3f} (three types {stats(M)['kappa']:.3f})")
    # construction check for the earlier 'selection by agreement' reading
    full = BAEK_CONSENSUS["A&B&C"]
    rng = np.random.default_rng(1)
    Nsim = 400_000
    t = rng.choice(3, Nsim, p=db)
    calls = {}
    for k in "ABC":
        u = rng.random(Nsim); cum = np.cumsum(cond[k][:, t], axis=0)
        calls[k] = (u[None, :] > cum).sum(0)
    un = (calls["A"] == calls["B"]) & (calls["B"] == calls["C"])
    for k, M in BAEK.items():
        rest_acc = (np.trace(M) - np.trace(full)) / (M.sum() - full.sum())
        say(f"construction check, specialist {k}: accuracy outside unanimous cases {rest_acc*100:.1f}% "
            f"vs {np.mean(calls[k][~un] == t[~un])*100:.1f}% expected under independence")

    say("\n=== Bootstrap 95% intervals (multinomial resampling of each published table, 4000 draws) ===")
    def ci(M, groups=None):
        M = np.asarray(M)
        n = int(M.sum()); p = (M / n).ravel()
        f = (lambda X: stats(X)["kappa"]) if groups is None else (lambda X: stats(collapse(X, groups))["kappa"])
        bs = [f(rng.multinomial(n, p).reshape(M.shape)) for _ in range(4000)]
        return f(M), np.percentile(bs, 2.5), np.percentile(bs, 97.5)
    rows = [("KS-15, three types", KS15, None), ("KS-15, yin/yang", KS15, YANG)]
    for k, M in BAEK.items():
        rows += [(f"Specialist {k}, three types", M, None), (f"Specialist {k}, yin/yang", M, YANG)]
    rows += [("ECM, eight types", MIN2007, None), ("ECM, four groups", MIN2007, ECM_GROUP), ("ECM, two divisions", MIN2007, ECM_SIDE)]
    for lab, M, g in rows:
        k, lo, hi = ci(M, g)
        say(f"{lab:30s} kappa {k:.2f} [{lo:.2f}, {hi:.2f}]")
    pooled = sum(BAEK.values())
    k3, lo3, hi3 = ci(pooled); k2, lo2, hi2 = ci(pooled, YANG)
    say(f"{'Specialists pooled, three types':30s} kappa {k3:.2f} [{lo3:.2f}, {hi3:.2f}]")
    say(f"{'Specialists pooled, yin/yang':30s} kappa {k2:.2f} [{lo2:.2f}, {hi2:.2f}]")
    # paired comparison of levels (same bootstrap draw) for the pooled specialist table
    n = int(pooled.sum()); p = (pooled / n).ravel()
    d = []
    for _ in range(4000):
        X = rng.multinomial(n, p).reshape(3, 3)
        d.append(stats(X)["kappa"] - stats(collapse(X, YANG))["kappa"])
    say(f"pooled specialists (tables treated as independent, which understates uncertainty), three-type minus yin/yang kappa: {k3-k2:.2f} [{np.percentile(d,2.5):.2f}, {np.percentile(d,97.5):.2f}]")
    n = int(MIN2007.sum()); p = (MIN2007 / n).ravel()
    d = []
    for _ in range(4000):
        X = rng.multinomial(n, p).reshape(8, 8)
        d.append(stats(collapse(X, ECM_GROUP))["kappa"] - stats(X)["kappa"])
    g_point = stats(collapse(MIN2007, ECM_GROUP))["kappa"] - stats(MIN2007)["kappa"]
    say(f"ECM, four-group minus eight-type kappa: {g_point:.2f} [{np.percentile(d,2.5):.2f}, {np.percentile(d,97.5):.2f}]")

    say("\n=== Min 2007: ECM questionnaire model vs pulse diagnosis, level by level ===")
    M = MIN2007
    pct = np.diag(M) / M.sum(1) * 100
    say("extraction check, % correct per row: " + ", ".join(f"{t} {p:.1f} (pub {q})" for t, p, q in zip(ECM_TYPES, pct, MIN_PCT_CORRECT))
        + f"; overall {np.trace(M)/M.sum()*100:.1f}% (pub 85.3)")
    for lab, MM in (("8 types", M), ("4 groups", collapse(M, ECM_GROUP)), ("2 sides", collapse(M, ECM_SIDE))):
        st = stats(MM)
        say(f"{lab:8s}: po {st['po']:.3f} chance floor {st['pe']:.3f} kappa {st['kappa']:.3f} AC1 {st['ac1']:.3f}")
    off = M.sum() - np.trace(M)
    within = sum(M[i, j] for i in range(8) for j in range(8) if i != j and ECM_GROUP[i] == ECM_GROUP[j])
    say(f"disagreements {off}; within a group (form only) {within} ({within/off*100:.0f}%)")
    sens = np.diag(M) / M.sum(1); ppv = np.diag(M) / M.sum(0)
    say("sensitivity / PPV per type: " + ", ".join(f"{t} {a*100:.0f}/{b*100:.0f}" for t, a, b in zip(ECM_TYPES, sens, ppv)))
    form = np.array([[M[i::2, j::2].sum() for j in range(2)] for i in range(2)])   # yang (even index) vs yin form, all groups
    st = stats(form)
    say(f"form (yang vs yin) across groups: po {st['po']:.3f} kappa {st['kappa']:.3f}")
    names = ["Wood", "Earth", "Metal", "Water"]
    parts = []
    for g in range(4):
        sub = M[2 * g:2 * g + 2, 2 * g:2 * g + 2]
        st = stats(sub)
        parts.append(f"{names[g]} {int(np.trace(sub))}/{int(sub.sum())} agree, kappa {st['kappa']:.2f}")
    say("form within each group (patients called in the right group by both): " + "; ".join(parts))

    with open("reanalysis_output.txt", "w") as fh:
        fh.write("\n".join(lines) + "\n")


if __name__ == "__main__":
    main()
