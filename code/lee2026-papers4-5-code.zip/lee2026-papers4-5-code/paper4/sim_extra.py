"""
Additional simulations for Sections 6.5 and 6.6:
  (a) power of the outline decision rule of Section 6.5 (superseded by the companion protocol)
  (b) latent class models for the recommended design with a shared-error term
Imported and run from simulation.py, which produces the numbers reported in the paper (all in simulation_output.txt).
It can also be run alone (python sim_extra.py [--quick]) for testing, but then it uses its own seed, skips run_checks
and writes sim_extra_output.txt, whose numbers do not reproduce the paper's.
"""
import sys
import numpy as np
import simulation as S

QUICK = "--quick" in sys.argv


# ---------------------------------------------------------------------------
# fast kappa on many resamples
# ---------------------------------------------------------------------------
def kappa_idx(a, b, k, idx):
    """Cohen's kappa of label vectors a, b restricted to rows idx (with repeats)."""
    aa, bb = a[idx], b[idx]
    n = len(idx)
    C = np.bincount(aa * k + bb, minlength=k * k).reshape(k, k) / n
    po = np.trace(C)
    pe = C.sum(1) @ C.sum(0)
    return (po - pe) / (1 - pe) if pe < 1 else 0.0


def study_stats(r1, r2, idx, k):
    R = len(r1)
    same1 = np.mean([kappa_idx(r1[i], r1[j], k, idx) for i in range(R) for j in range(i + 1, R)])
    same2 = np.mean([kappa_idx(r2[i], r2[j], k, idx) for i in range(R) for j in range(i + 1, R)])
    cross = np.mean([kappa_idx(r1[i], r2[j], k, idx) for i in range(R) for j in range(R) if i != j])
    return same1, same2, cross


def full_rule_study(n, g1, g2, pc, rng, B):
    """One simulated study. Returns (gate_passed, gap_significant)."""
    t1 = rng.choice(8, n, p=S.ECM)
    t2 = S.change_types(t1, pc / 2, pc / 2, rng, "any")
    r1 = [S.ecm_rater(t1, g1, 0.80, rng, "even") for _ in range(3)]
    r2 = [S.ecm_rater(t2, g2, 0.80, rng, "even") for _ in range(3)]
    r1g = [x // 2 for x in r1]; r2g = [x // 2 for x in r2]
    full = np.arange(n)
    s1, s2, cx = study_stats(r1, r2, full, 8)
    gap = np.sqrt(max(s1, 1e-9) * max(s2, 1e-9)) - cx
    gaps, g1s, g2s = [], [], []
    for _ in range(B):
        idx = rng.integers(0, n, n)
        a1, a2, ac = study_stats(r1, r2, idx, 8)
        gaps.append(np.sqrt(max(a1, 1e-9) * max(a2, 1e-9)) - ac)
        b1, b2, _ = study_stats(r1g, r2g, idx, 4)
        g1s.append(b1); g2s.append(b2)
    gate = np.percentile(g1s, 2.5) > 0.20 and np.percentile(g2s, 2.5) > 0.20
    signif = np.percentile(gaps, 5) > 0          # one-sided 95% lower bound above zero
    return gate, signif


def run_full_rule(rng, say):
    reps = 60 if QUICK else 300
    B = 60 if QUICK else 150
    say("\n=== 6.5f Full decision rule: four-group gate (lower 95% bound of same-day kappa > 0.20 at both visits)"
        " then one-sided bootstrap test of the corrected gap at eight types ===")
    say("cells: n, group accuracy visit 1 / visit 2, share changing | P(gate passed) | P(gate passed and change detected)")
    for n in (150, 500):
        for g1, g2 in ((0.7, 0.7), (0.7, 0.6), (0.8, 0.8), (0.8, 0.7)):
            for pc in (0.0, 0.10, 0.25):
                res = [full_rule_study(n, g1, g2, pc, rng, B) for _ in range(reps)]
                gate = np.mean([r[0] for r in res])
                both = np.mean([r[0] and r[1] for r in res])
                say(f"n={n:3d} acc {g1:.1f}/{g2:.1f} change {pc:4.0%} | gate {gate:.2f} | gate+detect {both:.2f}")


# ---------------------------------------------------------------------------
# latent class models with a shared-error term
# ---------------------------------------------------------------------------
def shared_misread(truth, acc, d, rng, n_raters, K=4):
    """n_raters of one modality; with probability d per patient all report the same
    wrong group; otherwise independent with accuracy acc/(1-d) (marginal accuracy acc)."""
    n = len(truth)
    shared = rng.random(n) < d
    target = (truth + rng.integers(1, K, n)) % K
    out = []
    for _ in range(n_raters):
        r = S.group_rater(truth, acc / (1 - d), rng, K)
        r[shared] = target[shared]
        out.append(r)
    return out


def lca_blocks(Y, blocks, K=4, iters=1000, tol=1e-9):
    """Latent class model with shared-error blocks.
    Y: n x J labels. blocks: list of lists of column indices; every column belongs to
    exactly one block. In a block of two or more indicators, with probability delta_b a
    patient's indicators in that block all report one common wrong class (uniform over
    the K-1 others); otherwise they err independently given the latent class t.
    Single-column blocks have no shared component. Blocks are independent given t.
    Returns pi, deltas, marginal accuracy of each column."""
    n, J = Y.shape
    init = lambda: np.full((K, K), 0.4 / (K - 1)) + np.eye(K) * (0.6 - 0.4 / (K - 1))
    pi = np.full(K, 1 / K)
    P = [init() for _ in range(J)]
    delta = [0.05 if len(b) > 1 else 0.0 for b in blocks]
    oh = [np.eye(K)[Y[:, j]] for j in range(J)]
    same = [np.all(Y[:, b] == Y[:, b[:1]], axis=1) if len(b) > 1 else None for b in blocks]
    ll_old = -np.inf
    for _ in range(iters):
        logL = np.log(pi)[None, :].repeat(n, 0)
        comp = []                      # per block: (independent likelihood, shared likelihood), n x K, not logged
        for bi, b in enumerate(blocks):
            ind = np.exp(sum(np.log(P[j][:, Y[:, j]].T) for j in b)) * (1 - delta[bi])
            sh = np.zeros((n, K))
            if len(b) > 1:
                for t in range(K):
                    ok = same[bi] & (Y[:, b[0]] != t)
                    sh[ok, t] = delta[bi] / (K - 1)
            comp.append((ind, sh))
            logL = logL + np.log(ind + sh + 1e-300)
        m = logL.max(1, keepdims=True)
        w = np.exp(logL - m); tot = w.sum(1, keepdims=True); post = w / tot
        ll = float(np.sum(np.log(tot) + m))
        pi = post.mean(0)
        for bi, b in enumerate(blocks):
            ind, sh = comp[bi]
            p_ind = ind / (ind + sh + 1e-300)          # P(independent component | t, y)
            wgt = post * p_ind
            if len(b) > 1:
                delta[bi] = float(np.sum(post * (1 - p_ind)) / n)
            for j in b:
                P[j] = (wgt.T @ oh[j] + 1e-9) / (wgt.sum(0)[:, None] + K * 1e-9)
        if ll - ll_old < tol:
            break
        ll_old = ll
    acc = []
    for bi, b in enumerate(blocks):
        for j in b:
            acc.append((j, (1 - delta[bi]) * float(np.sum(pi * np.diag(P[j])))))
    acc = [a for _, a in sorted(acc)]
    return pi, delta, acc


def run_lca_shared(rng, say):
    say("\n=== 6.6b Recommended design: three pulse raters, questionnaire, body form ===")
    G4 = np.array([S.ECM[0] + S.ECM[1], S.ECM[2] + S.ECM[3], S.ECM[4] + S.ECM[5], S.ECM[6] + S.ECM[7]])
    N = 20_000 if not QUICK else 8_000
    PULSE, QUEST, FORM = 0.75, 0.65, 0.60
    say("columns: pulse shared-misread rate, questionnaire/body-form shared-misread rate | true pulse/quest/form accuracy |"
        " standard LCA on 5 indicators | standard LCA, pulse majority as one indicator | shared-error term for pulse |"
        " shared-error terms for pulse and for questionnaire/body form")
    for d_p, d_qf in ((0.0, 0.0), (0.10, 0.0), (0.20, 0.0), (0.10, 0.10), (0.20, 0.10)):
        t = rng.choice(4, N, p=G4)
        P3 = shared_misread(t, PULSE, d_p, rng, 3)
        Q, F = shared_misread(t, QUEST, d_qf, rng, 1)[0], None
        # questionnaire and body form share a body-cue misreading at rate d_qf
        if d_qf > 0:
            n = len(t); sh = rng.random(n) < d_qf
            target = (t + rng.integers(1, 4, n)) % 4
            Q = S.group_rater(t, QUEST / (1 - d_qf), rng); F = S.group_rater(t, FORM / (1 - d_qf), rng)
            Q[sh] = target[sh]; F[sh] = target[sh]
        else:
            Q = S.group_rater(t, QUEST, rng); F = S.group_rater(t, FORM, rng)
        true = [np.mean(P3[0] == t), np.mean(Q == t), np.mean(F == t)]
        # (i) standard LCA on all five
        pi, P = S.lca_em(np.column_stack(P3 + [Q, F]), 4)
        acc_i = [S.lca_accuracy(pi, P, j) for j in range(5)]
        # (ii) pulse majority as one indicator (ties -> first rater)
        stack = np.column_stack(P3)
        maj = P3[0].copy()
        agree12 = stack[:, 1] == stack[:, 2]
        maj[agree12] = stack[agree12, 1]
        true_maj = np.mean(maj == t)
        pi2, P2 = S.lca_em(np.column_stack([maj, Q, F]), 4)
        acc_ii = [S.lca_accuracy(pi2, P2, j) for j in range(3)]
        Y5 = np.column_stack(P3 + [Q, F])
        # (iii) shared-error term for the pulse block only
        _, d3, a3 = lca_blocks(Y5, [[0, 1, 2], [3], [4]])
        # (iv) shared-error terms for the pulse block and the questionnaire/body-form pair
        _, d4, a4 = lca_blocks(Y5, [[0, 1, 2], [3, 4]])
        say(f"pulse {d_p:.2f} Q-F {d_qf:.2f} | true {true[0]:.2f}/{true[1]:.2f}/{true[2]:.2f} (majority {true_maj:.2f}) | "
            f"std5 {np.mean(acc_i[:3]):.2f}/{acc_i[3]:.2f}/{acc_i[4]:.2f} | "
            f"majority {acc_ii[0]:.2f}/{acc_ii[1]:.2f}/{acc_ii[2]:.2f} | "
            f"pulse-block {np.mean(a3[:3]):.2f}/{a3[3]:.2f}/{a3[4]:.2f} (delta {d3[0]:.3f}) | "
            f"two blocks {np.mean(a4[:3]):.2f}/{a4[3]:.2f}/{a4[4]:.2f} (deltas {d4[0]:.3f}, {d4[1]:.3f})")


if __name__ == "__main__":
    rng = np.random.default_rng(20261004)
    out = []
    say = lambda s="": (print(s), out.append(s))
    run_lca_shared(rng, say)
    run_full_rule(rng, say)
    with open("sim_extra_output.txt", "w") as fh:
        fh.write("\n".join(out) + "\n")


# ---------------------------------------------------------------------------
# Numbers quoted in the text that the main sections do not print, and a check of
# the two-block latent class model at a realistic sample size. Uses its own seed,
# so it does not change any earlier output.
# ---------------------------------------------------------------------------
def run_checks(say):
    rng = np.random.default_rng(777)
    say("\n=== Checks quoted in the text ===")
    # true cross-occasion kappa and share held under the change models
    for pc in (0.25, 0.50):
        t1 = rng.choice(8, 400_000, p=S.ECM); t2 = S.change_types(t1, pc / 2, pc / 2, rng, "any")
        say(f"6.5 change model, {pc:.0%} change: share of patients whose type held {np.mean(t1 == t2):.2f}, "
            f"true cross-occasion kappa {S.kappa(t1, t2, 8):.2f}")
    t1 = rng.choice(8, 400_000, p=S.ECM); t2 = S.change_types(t1, 0.35, 0.10, rng, "partner")
    say(f"6.3 non-fixed scenario: share held {np.mean(t1 == t2):.2f}, true cross-occasion kappa {S.kappa(t1, t2, 8):.2f}")
    # spread of the stability ratio at n = 150
    r = []
    for _ in range(1000):
        t1 = rng.choice(8, 150, p=S.ECM); t2 = S.change_types(t1, 0.125, 0.125, rng, "any")
        k1, k2, kx = S.contrasts(t1, t2, 0.7, 0.7, 0.8, rng)
        r.append(S.stability_ratio(k1, k2, kx))
    lo, hi = np.percentile(r, [2.5, 97.5])
    say(f"6.5 stability ratio, n=150, accuracy 0.7, 25% change: central 95% of 1000 studies {lo:.2f} to {hi:.2f}")
    # four-group kappa at group accuracy 0.6
    t = rng.choice(8, 400_000, p=S.ECM)
    a = S.ecm_rater(t, 0.6, 0.8, rng, "even") // 2; b = S.ecm_rater(t, 0.6, 0.8, rng, "even") // 2
    say(f"6.5 four-group same-day kappa at group accuracy 0.6: {S.kappa(a, b, 4):.2f}")
    # two-block latent class model at n = 500
    G4 = np.array([S.ECM[0] + S.ECM[1], S.ECM[2] + S.ECM[3], S.ECM[4] + S.ECM[5], S.ECM[6] + S.ECM[7]])
    reps = 40 if QUICK else 200
    est = []
    for _ in range(reps):
        n = 500
        t = rng.choice(4, n, p=G4)
        P3 = shared_misread(t, 0.75, 0.20, rng, 3)
        sh = rng.random(n) < 0.10
        target = (t + rng.integers(1, 4, n)) % 4
        Q = S.group_rater(t, 0.65 / 0.90, rng); F = S.group_rater(t, 0.60 / 0.90, rng)
        Q[sh] = target[sh]; F[sh] = target[sh]
        _, d, acc = lca_blocks(np.column_stack(P3 + [Q, F]), [[0, 1, 2], [3, 4]])
        est.append([np.mean(acc[:3]), acc[3], acc[4], d[0], d[1]])
    est = np.array(est)
    lab = ["pulse accuracy (true 0.75)", "questionnaire (0.65)", "body form (0.60)",
           "pulse sharing rate (0.20)", "questionnaire-body form sharing rate (0.10)"]
    say(f"6.6 two-block model at n=500, {reps} studies, pulse sharing 20%, questionnaire-body form sharing 10%:")
    for j, l in enumerate(lab):
        say(f"    {l}: mean {est[:, j].mean():.2f}, central 95% {np.percentile(est[:, j], 2.5):.2f} to "
            f"{np.percentile(est[:, j], 97.5):.2f}")
