"""
Simulation code for:
Lee, H. (2026). What Counts as Error? Constitutional Diagnosis, Reliability
Statistics, and the Ontology They Presuppose. SSRN Working Paper.

Reproduces every table in Section 6 (with sim_extra.py). Python 3, NumPy only.
Run:  python simulation.py            (full run; about 15 minutes to over an hour depending on the machine, single-threaded)
      python simulation.py --quick    (fewer replications, for checking)

All raters are simulated. No patient data are used.
"""
import sys
import numpy as np

QUICK = "--quick" in sys.argv
SEED = 20261003

# ---------------------------------------------------------------------------
# Agreement statistics
# ---------------------------------------------------------------------------
def kappa(a, b, k):
    """Cohen's kappa for two label vectors with categories 0..k-1."""
    n = len(a)
    po = np.mean(a == b)
    pa = np.bincount(a, minlength=k) / n
    pb = np.bincount(b, minlength=k) / n
    pe = float(pa @ pb)
    return (po - pe) / (1 - pe)


def ac1(a, b, k):
    """Gwet's AC1 for two raters."""
    po = np.mean(a == b)
    pi = (np.bincount(a, minlength=k) + np.bincount(b, minlength=k)) / (2 * len(a))
    pe = float(np.sum(pi * (1 - pi))) / (k - 1)
    return (po - pe) / (1 - pe)


# ---------------------------------------------------------------------------
# Sasang model (Section 6.1)
# Types: 0 Taeyang, 1 Soyang, 2 Taeeum, 3 Soeum
# Canonical confusions (Byeonjeung 04, 06, 07): Taeyang, Soyang and Taeeum are
# mistaken only for Soeum; Soeum is mistaken for each of the other three equally.
# ---------------------------------------------------------------------------
LEE = np.array([0.1, 30.0, 50.0, 20.0]); LEE = LEE / LEE.sum()
UNIFORM4 = np.full(4, 0.25)


def sasang_rater(truth, acc, rng):
    out = truth.copy()
    wrong = rng.random(len(truth)) > acc
    soeum = truth == 3
    out[wrong & ~soeum] = 3
    idx = wrong & soeum
    out[idx] = rng.integers(0, 3, idx.sum())
    return out


def ppv_taeyang_analytic(acc, dist=LEE):
    tp = dist[0] * acc
    fp = dist[3] * (1 - acc) / 3
    return tp / (tp + fp)


def norm_ppf(p):
    """Inverse standard normal CDF (Acklam's rational approximation)."""
    a = [-3.969683028665376e+01, 2.209460984245205e+02, -2.759285104469687e+02,
         1.383577518672690e+02, -3.066479806614716e+01, 2.506628277459239e+00]
    b = [-5.447609879822406e+01, 1.615858368580409e+02, -1.556989798598866e+02,
         6.680131188771972e+01, -1.328068155288572e+01]
    c = [-7.784894002430293e-03, -3.223964580411365e-01, -2.400758277161838e+00,
         -2.549732539343734e+00, 4.374664141464968e+00, 2.938163982698783e+00]
    d = [7.784695709041462e-03, 3.224671290700398e-01, 2.445134137142996e+00,
         3.754408661907416e+00]
    pl = 0.02425
    if p < pl:
        q = np.sqrt(-2 * np.log(p))
        return (((((c[0]*q+c[1])*q+c[2])*q+c[3])*q+c[4])*q+c[5]) / ((((d[0]*q+d[1])*q+d[2])*q+d[3])*q+1)
    if p > 1 - pl:
        return -norm_ppf(1 - p)
    q = p - 0.5; r = q * q
    return (((((a[0]*r+a[1])*r+a[2])*r+a[3])*r+a[4])*r+a[5])*q / (((((b[0]*r+b[1])*r+b[2])*r+b[3])*r+b[4])*r+1)


def norm_cdf(x):
    from math import erf, sqrt
    return 0.5 * (1 + erf(x / sqrt(2)))


# ---------------------------------------------------------------------------
# ECM model (Sections 6.2-6.5)
# Eight types coded 2*group + form. Groups: 0 Metal, 1 Earth, 2 Wood, 3 Water.
# Binary division used by some lineages: {Wood, Earth} vs {Metal, Water}.
# Published clinic distribution: 925 ECM outpatients typed by pulse and
# response to constitution acupuncture (Kim HJ et al., 2009; ref. [12]).
# Order: Pulmotonia, Colonotonia, Pancreotonia, Gastrotonia,
#        Hepatonia, Cholecystonia, Renotonia, Vesicotonia
# ---------------------------------------------------------------------------
ECM = np.array([18.1, 17.3, 28.0, 0.4, 18.1, 7.0, 2.6, 8.5]); ECM = ECM / ECM.sum()
SIDE = np.array([1, 0, 0, 1])          # group -> binary side
PARTNER = np.array([3, 2, 1, 0])       # same-side partner group
OTHER_SIDE = {0: (1, 2), 3: (1, 2), 1: (0, 3), 2: (0, 3)}


def ecm_rater(truth, g_acc, f_acc, rng, error_mode="side", same_side=0.6):
    """Rate eight-type truths.
    error_mode 'side': a group error goes to the same-side partner group with
    probability `same_side`, otherwise to one of the two other-side groups.
    error_mode 'even': a group error goes to any of the three other groups.
    Form is correct with probability f_acc when the group is correct, and is
    random when the group is wrong."""
    n = len(truth)
    g, f = truth // 2, truth % 2
    gw = rng.random(n) > g_acc
    rg = g.copy()
    if error_mode == "side":
        stay = rng.random(n) < same_side
        pick = rng.integers(0, 2, n)
        other = np.array([OTHER_SIDE[x] for x in range(4)])[g, pick]
        rg[gw] = np.where(stay, PARTNER[g], other)[gw]
    else:
        shift = rng.integers(1, 4, n)
        rg[gw] = ((g + shift) % 4)[gw]
    rf = np.where(rng.random(n) < f_acc, f, 1 - f)
    rf[gw] = rng.integers(0, 2, gw.sum())
    return 2 * rg + rf


def levels(x):
    return {8: x, 4: x // 2, 2: SIDE[x // 2]}


def change_types(truth, p_form, p_group, rng, group_mode="partner"):
    """Between occasions: p_group of persons move to another group (form
    random), a further p_form change form within their group. Mutually exclusive."""
    n = len(truth)
    g, f = truth // 2, truth % 2
    u = rng.random(n)
    mg = u < p_group
    mf = (u >= p_group) & (u < p_group + p_form)
    ng = g.copy()
    if group_mode == "partner":
        ng[mg] = PARTNER[g[mg]]
    else:
        ng[mg] = ((g + rng.integers(1, 4, n)) % 4)[mg]
    nf = f.copy()
    nf[mf] = 1 - f[mf]
    nf[mg] = rng.integers(0, 2, mg.sum())
    return 2 * ng + nf


def mean_pairwise(ratings_a, ratings_b, k, same_set):
    """Mean Cohen's kappa over rater pairs. If same_set, unordered pairs of
    distinct raters within one occasion; otherwise ordered pairs A(occ1)-B(occ2)
    with A != B."""
    R = len(ratings_a)
    vals = []
    for i in range(R):
        for j in range(R):
            if i == j or (same_set and j < i):
                continue
            vals.append(kappa(ratings_a[i], ratings_b[j], k))
    return float(np.mean(vals))


def contrasts(truth1, truth2, g_acc1, g_acc2, f_acc, rng, n_raters=3, k=8,
              error_mode="even"):
    """Same-day between-rater kappa at each occasion and cross-occasion
    between-rater kappa (different raters only)."""
    lv = lambda x: levels(x)[k]
    r1 = [lv(ecm_rater(truth1, g_acc1, f_acc, rng, error_mode)) for _ in range(n_raters)]
    r2 = [lv(ecm_rater(truth2, g_acc2, f_acc, rng, error_mode)) for _ in range(n_raters)]
    k1 = mean_pairwise(r1, r1, k, True)
    k2 = mean_pairwise(r2, r2, k, True)
    kx = mean_pairwise(r1, r2, k, False)
    return k1, k2, kx


def corrected_gap(k1, k2, kx):
    """Attenuation-corrected contrast: geometric mean of the two same-day
    kappas minus the cross-occasion kappa (cf. Spearman's correction)."""
    return np.sqrt(max(k1, 1e-9) * max(k2, 1e-9)) - kx


def stability_ratio(k1, k2, kx):
    return kx / np.sqrt(max(k1, 1e-9) * max(k2, 1e-9))


# ---------------------------------------------------------------------------
# Latent class analysis (Section 6.6)
# ---------------------------------------------------------------------------
def lca_em(Y, K, iters=500, tol=1e-9, init_acc=0.6):
    """Standard latent class model (conditional independence) fitted by EM.
    Y: n x J matrix of category labels 0..K-1. Returns class prevalences and
    per-indicator K x K response matrices P[j][class, response]."""
    n, J = Y.shape
    pi = np.full(K, 1.0 / K)
    P = [np.full((K, K), (1 - init_acc) / (K - 1)) + np.eye(K) * (init_acc - (1 - init_acc) / (K - 1))
         for _ in range(J)]
    onehot = [np.eye(K)[Y[:, j]] for j in range(J)]
    ll_old = -np.inf
    for _ in range(iters):
        logp = np.log(pi)[None, :] + sum(np.log(P[j][:, Y[:, j]].T) for j in range(J))
        m = logp.max(1, keepdims=True)
        w = np.exp(logp - m); tot = w.sum(1, keepdims=True); post = w / tot
        ll = float(np.sum(np.log(tot) + m))
        pi = post.mean(0)
        P = [(post.T @ onehot[j] + 1e-9) / (post.sum(0)[:, None] + K * 1e-9) for j in range(J)]
        if ll - ll_old < tol:
            break
        ll_old = ll
    return pi, P


def lca_accuracy(pi, P, j):
    """Prevalence-weighted accuracy of indicator j implied by the fitted model
    (classes matched to categories by the diagonal, which the initialisation fixes)."""
    return float(np.sum(pi * np.diag(P[j])))


def group_rater(truth, acc, rng, K=4):
    n = len(truth)
    out = truth.copy()
    wrong = rng.random(n) > acc
    out[wrong] = ((truth + rng.integers(1, K, n)) % K)[wrong]
    return out


def dependent_pulse_pair(truth, acc, d, rng, K=4):
    """Two raters of the same lineage. With probability d per patient a shared
    lineage misreading occurs and both report the same wrong group; otherwise
    each errs independently. Marginal accuracy stays at `acc` for any d."""
    n = len(truth)
    shared = rng.random(n) < d
    wrong_target = (truth + rng.integers(1, K, n)) % K
    a_ind = acc / (1 - d)
    A = group_rater(truth, a_ind, rng, K); B = group_rater(truth, a_ind, rng, K)
    A[shared] = wrong_target[shared]; B[shared] = wrong_target[shared]
    return A, B


# ---------------------------------------------------------------------------
# G-study (Section 6.4): fully crossed persons x raters x occasions
# ---------------------------------------------------------------------------
def g_study(X):
    """ANOVA variance-component estimates for a p x r x o random design.
    Negative estimates are set to zero. Returns proportions of total."""
    P, R, O = X.shape
    m = X.mean()
    mp = X.mean((1, 2)); mr = X.mean((0, 2)); mo = X.mean((0, 1))
    mpr = X.mean(2); mpo = X.mean(1); mro = X.mean(0)
    ss = {}
    ss['p'] = R * O * np.sum((mp - m) ** 2)
    ss['r'] = P * O * np.sum((mr - m) ** 2)
    ss['o'] = P * R * np.sum((mo - m) ** 2)
    ss['pr'] = O * np.sum((mpr - mp[:, None] - mr[None, :] + m) ** 2)
    ss['po'] = R * np.sum((mpo - mp[:, None] - mo[None, :] + m) ** 2)
    ss['ro'] = P * np.sum((mro - mr[:, None] - mo[None, :] + m) ** 2)
    ss['e'] = np.sum((X - mpr[:, :, None] - mpo[:, None, :] - mro[None, :, :]
                      + mp[:, None, None] + mr[None, :, None] + mo[None, None, :] - m) ** 2)
    df = {'p': P-1, 'r': R-1, 'o': O-1, 'pr': (P-1)*(R-1), 'po': (P-1)*(O-1),
          'ro': (R-1)*(O-1), 'e': (P-1)*(R-1)*(O-1)}
    ms = {k: ss[k] / df[k] for k in ss}
    v = {}
    v['e'] = ms['e']
    v['pr'] = (ms['pr'] - ms['e']) / O
    v['po'] = (ms['po'] - ms['e']) / R
    v['ro'] = (ms['ro'] - ms['e']) / P
    v['p'] = (ms['p'] - ms['pr'] - ms['po'] + ms['e']) / (R * O)
    v['r'] = (ms['r'] - ms['pr'] - ms['ro'] + ms['e']) / (P * O)
    v['o'] = (ms['o'] - ms['po'] - ms['ro'] + ms['e']) / (P * R)
    v = {k: max(0.0, x) for k, x in v.items()}
    tot = sum(v.values())
    return {k: x / tot for k, x in v.items()}


def simulate_g(rng, P=200, R=3, O=3, s_p=1.0, s_po=0.0, s_r=0.04, s_ro=0.0, s_e=0.2):
    p = rng.normal(0, np.sqrt(s_p), (P, 1, 1))
    po = rng.normal(0, np.sqrt(s_po), (P, 1, O))
    r = rng.normal(0, np.sqrt(s_r), (1, R, 1))
    ro = rng.normal(0, np.sqrt(s_ro), (1, R, O))
    e = rng.normal(0, np.sqrt(s_e), (P, R, O))
    return p + po + r + ro + e


# ---------------------------------------------------------------------------
def main():
    rng = np.random.default_rng(SEED)
    out = []
    say = lambda s="": (print(s), out.append(s))

    # ---------------- 6.1 -----------------
    say("=== 6.1 Sasang: prevalence and the rare type ===")
    N = 200_000
    for acc in (0.80, 0.70):
        for name, dist in (("Uniform", UNIFORM4), ("Lee", LEE)):
            t = rng.choice(4, N, p=dist)
            a, b = sasang_rater(t, acc, rng), sasang_rater(t, acc, rng)
            say(f"acc {acc:.2f} {name:8s} po {np.mean(a==b):.3f}  kappa {kappa(a,b,4):.3f}  AC1 {ac1(a,b,4):.3f}")
    N2 = 2_000_000
    t = rng.choice(4, N2, p=LEE)
    a = sasang_rater(t, 0.80, rng)
    calls = a == 0
    say(f"2M run, acc 0.80: Taeyang calls {calls.sum():,}; true Taeyang among them {np.mean(t[calls]==0)*100:.1f}%"
        f" (analytic {ppv_taeyang_analytic(0.8)*100:.1f}%)")

    # ---------------- 6.2 -----------------
    say("\n=== 6.2 ECM hierarchy and the random rater ===")
    say("ECM distribution (Kim 2009, n=925): " + ", ".join(f"{x*100:.1f}" for x in ECM))
    N = 200_000
    t = rng.choice(8, N, p=ECM)
    a = ecm_rater(t, 0.80, 0.65, rng, "side", 0.6)
    b = ecm_rater(t, 0.80, 0.65, rng, "side", 0.6)
    rnd = rng.choice(8, N, p=ECM)
    die = rng.integers(0, 8, N)
    for lab, other in (("rater vs rater", b), ("rater vs random rater", rnd), ("rater vs fair die", die)):
        la, lo = levels(a), levels(other)
        say(f"{lab:24s} k8 {kappa(la[8],lo[8],8):.2f}  k4 {kappa(la[4],lo[4],4):.2f}  k2 {kappa(la[2],lo[2],2):.2f}"
            f"   po8 {np.mean(la[8]==lo[8]):.3f} po4 {np.mean(la[4]==lo[4]):.3f} po2 {np.mean(la[2]==lo[2]):.3f}")
    # analytic ceiling for the binary level
    bin_acc = 0.80 + 0.20 * 0.6
    say(f"binary per-rater accuracy {bin_acc:.2f}; two-rater agreement {bin_acc**2+(1-bin_acc)**2:.3f}; "
        f"kappa ceiling with pe>=0.5: {((bin_acc**2+(1-bin_acc)**2)-0.5)/0.5:.3f}")

    # ---------------- 6.3 -----------------
    say("\n=== 6.3 Three accounts, three signatures (3 raters, large sample) ===")
    N = 100_000
    G3, F3 = 0.85, 0.80
    for scen in ("fixed", "nonfixed", "nosignal"):
        t1 = rng.choice(8, N, p=ECM)
        t2 = t1 if scen != "nonfixed" else change_types(t1, 0.35, 0.10, rng, "partner")
        def rate(t):
            if scen == "nosignal":
                return rng.choice(8, N, p=ECM)
            return ecm_rater(t, G3, F3, rng, "side", 0.6)
        R1 = [rate(t1) for _ in range(3)]
        R1rep = [rate(t1) for _ in range(3)]
        R2 = [rate(t2) for _ in range(3)]
        res = []
        for k in (8, 4):
            L = lambda x: levels(x)[k]
            r1 = [L(x) for x in R1]; r1r = [L(x) for x in R1rep]; r2 = [L(x) for x in R2]
            same_day = mean_pairwise(r1, r1, k, True)
            imm = float(np.mean([kappa(r1[i], r1r[i], k) for i in range(3)]))
            cross_between = mean_pairwise(r1, r2, k, False)
            later_same = float(np.mean([kappa(r1[i], r2[i], k) for i in range(3)]))
            same_day2 = mean_pairwise(r2, r2, k, True)
            res.append((same_day, imm, cross_between, later_same, same_day2))
        say(f"{scen:9s} " + " | ".join(
            f"k{k}: sameday {s:.2f} imm {i:.2f} cross(betw) {c:.2f} later(same) {l:.2f} sameday2 {s2:.2f}"
            for k, (s, i, c, l, s2) in zip((8, 4), res)))

    # ---------------- 6.4 -----------------
    say("\n=== 6.4 G-study variance proportions (200 persons, 3 raters, 3 occasions) ===")
    specs = {"fixed": dict(s_p=1.0, s_po=0.0, s_r=0.04, s_ro=0.0, s_e=0.21),
             # person x occasion drawn independently at each occasion: lasting change and passing state alike
             "chg/state": dict(s_p=0.60, s_po=0.40, s_r=0.03, s_ro=0.0, s_e=0.16),
             "nosignal": dict(s_p=0.0, s_po=0.0, s_r=0.01, s_ro=0.01, s_e=1.0)}
    for scen, sp in specs.items():
        v = g_study(simulate_g(rng, **sp))
        say(f"{scen:9s} p {v['p']:.2f}  pxo {v['po']:.2f}  r {v['r']:.2f}  resid {v['e']:.2f}  "
            f"(pr {v['pr']:.2f}, o {v['o']:.2f}, rxo {v['ro']:.2f})")

    # ---------------- 6.5 -----------------
    say("\n=== 6.5a PPV of a Taeyang call (base-rate-blind rater, analytic) ===")
    say("  ".join(f"{a:.1f}: {ppv_taeyang_analytic(a)*100:.1f}%" for a in (0.5, 0.6, 0.7, 0.8, 0.9)))

    say("\n=== 6.5b Base-rate-aware rater (signal detection, Taeyang vs Soeum) ===")
    sens0, fpr0 = 0.80, 0.20 / 3
    dprime = norm_ppf(sens0) - norm_ppf(fpr0)
    say(f"d' implied by sensitivity 0.80 and Soeum false-call rate 1/15: {dprime:.2f}")
    for fpr in (fpr0, 0.01, 0.001, 0.0001):
        crit = norm_ppf(1 - fpr)
        sens = 1 - norm_cdf(crit - dprime)
        tp = LEE[0] * sens; fp = LEE[3] * fpr
        say(f"Soeum false-call rate {fpr*100:6.2f}%  sensitivity {sens*100:5.1f}%  PPV {tp/(tp+fp)*100:5.1f}%")

    say("\n=== 6.5c Change signal, equal accuracy across visits (large samples, 3 raters) ===")
    N = 200_000
    for ga in (0.6, 0.7, 0.8, 0.9):
        row = []
        for pc in (0.0, 0.05, 0.10, 0.25, 0.50):
            t1 = rng.choice(8, N, p=ECM)
            t2 = change_types(t1, pc / 2, pc / 2, rng, "any")
            k1, k2, kx = contrasts(t1, t2, ga, ga, 0.80, rng)
            row.append((k1, k1 - kx, stability_ratio(k1, k2, kx)))
        say(f"acc {ga:.1f} same-day k8 {row[0][0]:.2f} | raw gap " +
            " ".join(f"{pc:.0%}:{r[1]:.3f}" for pc, r in zip((0, .05, .1, .25, .5), row)) +
            " | ratio " + " ".join(f"{r[2]:.2f}" for r in row))

    say("\n=== 6.5d Fixed constitution, pulse less legible at visit 2 (large samples) ===")
    for ga2 in (0.80, 0.70, 0.60):
        t1 = rng.choice(8, N, p=ECM)
        k1, k2, kx = contrasts(t1, t1, 0.80, ga2, 0.80, rng)
        say(f"visit-2 acc {ga2:.2f}: same-day k1 {k1:.2f} k2 {k2:.2f} cross {kx:.2f} raw gap {k1-kx:.3f} "
            f"corrected gap {corrected_gap(k1,k2,kx):.3f} ratio {stability_ratio(k1,k2,kx):.2f}")
    # and with real change plus attenuation
    t1 = rng.choice(8, N, p=ECM); t2 = change_types(t1, 0.125, 0.125, rng, "any")
    k1, k2, kx = contrasts(t1, t2, 0.80, 0.60, 0.80, rng)
    say(f"25% change + visit-2 acc 0.60: raw gap {k1-kx:.3f} corrected gap {corrected_gap(k1,k2,kx):.3f} ratio {stability_ratio(k1,k2,kx):.2f}")

    say("\n=== 6.5e Power of the corrected contrast: patient-level bootstrap test ===")
    # Each replicate: simulate one study, estimate the corrected gap, bootstrap
    # patients (B resamples) for its SE, reject if gap/SE > 1.645 (one-sided 5%).
    reps = 100 if QUICK else 500
    B = 100 if QUICK else 200
    def one_study(n, ga, pc):
        t1 = rng.choice(8, n, p=ECM)
        t2 = change_types(t1, pc / 2, pc / 2, rng, "any")
        r1 = [ecm_rater(t1, ga, 0.80, rng, "even") for _ in range(3)]
        r2 = [ecm_rater(t2, ga, 0.80, rng, "even") for _ in range(3)]
        def gap(idx):
            a = [x[idx] for x in r1]; b = [x[idx] for x in r2]
            return corrected_gap(mean_pairwise(a, a, 8, True), mean_pairwise(b, b, 8, True),
                                 mean_pairwise(a, b, 8, False))
        g = gap(np.arange(n))
        se = np.std([gap(rng.integers(0, n, n)) for _ in range(B)])
        return g / se > 1.645
    def power(n, ga, pc, r):
        return float(np.mean([one_study(n, ga, pc) for _ in range(r)]))
    for ga in (0.7, 0.8, 0.9):
        size = power(150, ga, 0.0, reps)
        pw = [power(150, ga, pc, reps) for pc in (0.05, 0.10, 0.25, 0.50)]
        say(f"n=150 acc {ga:.1f} type-I {size:.3f} power " + " ".join(f"{p:.2f}" for p in pw))
    for n in (300, 500):
        say(f"n={n} acc 0.8 10% change: power {power(n, 0.8, 0.10, reps):.2f}; "
            f"5% change: power {power(n, 0.8, 0.05, reps):.2f}")

    say("\n=== 6.6 Latent class analysis when two methods share errors ===")
    # Four ECM groups, prevalences from the eight-type distribution.
    G4 = np.array([ECM[0]+ECM[1], ECM[2]+ECM[3], ECM[4]+ECM[5], ECM[6]+ECM[7]])
    say("group prevalences: " + ", ".join(f"{x*100:.1f}" for x in G4))
    N = 20_000
    PULSE, QUEST, FORM = 0.75, 0.65, 0.60
    for d in (0.0, 0.05, 0.10, 0.20):
        t = rng.choice(4, N, p=G4)
        A, B = dependent_pulse_pair(t, PULSE, d, rng)
        Q = group_rater(t, QUEST, rng)
        F = group_rater(t, FORM, rng)
        # design 1: two same-lineage pulse raters + questionnaire
        pi, P = lca_em(np.column_stack([A, B, Q]), 4)
        acc1 = [lca_accuracy(pi, P, j) for j in range(3)]
        # design 2: one pulse rater + questionnaire + body form (different modalities)
        pi2, P2 = lca_em(np.column_stack([A, Q, F]), 4)
        acc2 = [lca_accuracy(pi2, P2, j) for j in range(3)]
        obs = [np.mean(A == t), np.mean(Q == t), np.mean(F == t)]
        say(f"shared-error rate {d:.2f} | true pulse {obs[0]:.2f} quest {obs[1]:.2f} form {obs[2]:.2f} | "
            f"2 pulse+Q: pulse {np.mean(acc1[:2]):.2f} quest {acc1[2]:.2f} | "
            f"pulse+Q+form: pulse {acc2[0]:.2f} quest {acc2[1]:.2f} form {acc2[2]:.2f}")

    # Additional analyses (sim_extra.py)
    import sim_extra
    sim_extra.QUICK = QUICK
    sim_extra.run_lca_shared(rng, say)
    sim_extra.run_full_rule(rng, say)
    sim_extra.run_checks(say)

    with open("simulation_output.txt", "w") as fh:
        fh.write("\n".join(out) + "\n")


if __name__ == "__main__":
    main()
