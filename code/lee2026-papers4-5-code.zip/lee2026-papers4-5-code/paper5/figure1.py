"""Figure 1 of paper 5: P(stable) and P(changed) against the true share with lasting change, n = 1,000,
group accuracy 0.8, form accuracy 0.95; core rule (part A) and full rule (part Q). Reads paper5_sim_output.txt."""
import re
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

txt = open("paper5_sim_output.txt").read()
A = txt.split("PART A")[1].split("PART E")[0]
Q = txt.split("PART Q")[1].split("PART")[0]
core = {"group": [], "form": []}
for line in A.splitlines():
    m = re.match(r"(group|form)\s*\| 0\.95 \| 1000 \| ([\d.]+) \| [-\d.]+ \| ([\d.]+) \| [\d.]+ \| ([\d.]+)", line)
    if m:
        core[m.group(1)].append((float(m.group(2)), float(m.group(3)), float(m.group(4))))
full = {"group": [], "form": []}
for line in Q.splitlines():
    m = re.match(r"(group|form)\s*\| 1000 \| ([\d.]+) \| [\d.]+, ([\d.]+) \| [\d.]+, ([\d.]+)", line)
    if m:
        full[m.group(1)].append((float(m.group(2)), float(m.group(3)), float(m.group(4))))

fig, axes = plt.subplots(1, 2, figsize=(9, 3.6), sharey=True)
for ax, lev in zip(axes, ("group", "form")):
    for data, ls, lab in ((core[lev], "--", "core rule"), (full[lev], "-", "full rule")):
        x = [d[0] for d in data]
        ax.plot(x, [d[1] for d in data], ls, color="#1f5f8b", marker="o", ms=3.5, label=f"stable, {lab}")
        ax.plot(x, [d[2] for d in data], ls, color="#b5451b", marker="s", ms=3.5, label=f"changed, {lab}")
    ax.axvline(0.10, color="0.5", lw=0.8, ls=":")
    ax.set_title(f"{lev.capitalize()} level")
    ax.set_xlabel("True share with lasting change (E)")
    ax.set_xticks([0, 0.05, 0.10, 0.15, 0.20])
    ax.grid(alpha=0.25)
axes[0].set_ylabel("Share of simulated studies")
axes[1].legend(fontsize=7.5, loc="center right", frameon=False)
fig.tight_layout()
fig.savefig("figure1.png", dpi=200)
print("core", core, "\nfull", full)
