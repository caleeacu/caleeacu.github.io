"""
Latent trait-state model for the four-visit, two-panel design of paper 5, fitted by EM, one level at a time.

Model (per patient, one level with K categories)
  c1 ~ pi                     constitution in the baseline block
  c2 | c1 ~ Gamma[c1, :]      constitution in the follow-up block (lasting change if c2 != c1)
  visit v in block b(v): with prob 1 - s_b the presented category is the block trait c_b;
                         with prob s_b it is a state draw z ~ rho (which may equal c_b)
  optional panel-shared misreading: for panel P (A reads visits 1 and 4, B visits 2 and 3), with prob d_P the
                         panel reads one category a ~ omega_P at both of its visits, whatever is presented
  calls: each rater r at visit v reports y with prob M[v][r][read category, y], independently given the
                         category that rater's panel reads at that visit
Estimand: lasting change share  Delta = 1 - sum_c pi_c Gamma_cc.
All latent sums are done exactly (no sampling); EM is closed-form in every M-step.
"""
import numpy as np

PANEL_VISITS = {0: (0, 3), 1: (1, 2)}      # panel A: visits 1 and 4; panel B: visits 2 and 3
BLOCK = (0, 0, 1, 1)
EPS = 1e-12


def _norm(x, axis=-1):
    return x / np.maximum(x.sum(axis, keepdims=True), EPS)


def init_params(K, panel, rng=None, acc=0.75):
    off = (1 - acc) / (K - 1)
    M0 = np.full((K, K), off) + np.eye(K) * (acc - off)
    p = dict(pi=np.full(K, 1 / K), G=0.9 * np.eye(K) + 0.1 / K, s=np.array([0.05, 0.05]), rho=np.full(K, 1 / K),
             M=[[M0.copy() for _ in range(3)] for _ in range(4)],
             d=np.array([0.02, 0.02]) if panel else np.zeros(2), om=[np.full(K, 1 / K), np.full(K, 1 / K)])
    if rng is not None:                              # random start (diagonal kept dominant to fix labels)
        p["pi"] = _norm(rng.dirichlet(np.ones(K)) + 0.2)
        p["G"] = _norm(np.eye(K) * rng.uniform(0.6, 0.95) + rng.dirichlet(np.ones(K), K) * 0.2)
        p["s"] = rng.uniform(0.01, 0.15, 2)
        p["M"] = [[_norm(np.eye(K) * rng.uniform(0.4, 0.8) + rng.dirichlet(np.ones(K), K) * (1 - acc)) for _ in range(3)]
                  for _ in range(4)]
        if panel:
            p["d"] = rng.uniform(0.005, 0.08, 2)
    return p


def _pack(p):
    return np.concatenate([p["pi"], p["G"].ravel(), p["s"], p["rho"], np.ravel(p["M"]), p["d"], np.ravel(p["om"])])


def _unpack(x, K):
    i = 0
    def take(m):
        nonlocal i
        out = x[i:i + m]; i += m; return out
    p = dict(pi=take(K), G=take(K * K).reshape(K, K), s=take(2), rho=take(K))
    Mf = take(4 * 3 * K * K).reshape(4, 3, K, K)
    p["M"] = [[Mf[v, r] for r in range(3)] for v in range(4)]
    p["d"] = take(2); p["om"] = list(take(2 * K).reshape(2, K))
    return p


def _project(p, panel):
    cl = lambda a: np.clip(a, 1e-10, None)
    q = dict(pi=_norm(cl(p["pi"])), G=_norm(cl(p["G"])), s=np.clip(p["s"], 1e-6, 0.95), rho=_norm(cl(p["rho"])),
             M=[[_norm(cl(m)) for m in row] for row in p["M"]],
             d=np.clip(p["d"], 1e-6, 0.5) if panel else np.zeros(2), om=[_norm(cl(o)) for o in p["om"]])
    return q


def em_step(Y, wt, oh, K, panel, p):
    """One EM step. Y: unique call patterns (u x 4 x 3), wt: their counts. Returns (updated params, loglik of p)."""
    n = wt.sum()
    e = [np.prod([p["M"][v][r][:, Y[:, v, r]].T for r in range(3)], axis=0) for v in range(4)]
    L = []
    for v in range(4):
        sb = p["s"][BLOCK[v]]
        L.append((1 - sb) * e[v] + sb * (e[v] @ p["rho"])[:, None])
    F, Fparts = [], []
    for P_, (va, vb) in PANEL_VISITS.items():      # va in the baseline block, vb in the follow-up block
        none = (1 - p["d"][P_]) * L[va][:, :, None] * L[vb][:, None, :]
        mis = p["d"][P_] * ((e[va] * e[vb]) @ p["om"][P_])
        F.append(none + mis[:, None, None])
        Fparts.append((none, mis))
    joint = p["pi"][None, :, None] * p["G"][None] * F[0] * F[1]
    lik = np.maximum(joint.sum((1, 2)), 1e-300)
    ll = float(wt @ np.log(lik))
    w = joint / lik[:, None, None] * wt[:, None, None]          # weighted posterior of (c1, c2)
    newp = dict(pi=_norm(w.sum((0, 2))), G=_norm(w.sum(0) + 1e-9))
    exp_state = np.zeros(2); rho_cnt = np.zeros(K); d_cnt = np.zeros(2); om_cnt = [np.zeros(K), np.zeros(K)]
    readpost = [None] * 4
    for P_, (va, vb) in PANEL_VISITS.items():
        none, mis = Fparts[P_]
        Ftot = np.maximum(F[P_], 1e-300)
        r_none = w * (none / Ftot)
        pm = (w * (mis[:, None, None] / Ftot)).sum((1, 2))
        d_cnt[P_] = pm.sum()
        am = p["om"][P_][None, :] * e[va] * e[vb]
        am = am / np.maximum(am.sum(1, keepdims=True), 1e-300) * pm[:, None]
        om_cnt[P_] += am.sum(0)
        for v, first in ((va, True), (vb, False)):
            q = r_none.sum(2 if first else 1)
            sb = p["s"][BLOCK[v]]
            Lv = np.maximum(L[v], 1e-300)
            trait_part = q * (1 - sb) * e[v] / Lv
            state_part = (q * sb / Lv).sum(1)[:, None] * p["rho"][None, :] * e[v]
            exp_state[BLOCK[v]] += state_part.sum() + sb * pm.sum()      # state indicator still drawn when the panel misreads
            rho_cnt += state_part.sum(0) + sb * pm.sum() * p["rho"]
            readpost[v] = trait_part + state_part + am
    newp["s"] = np.clip(exp_state / (2 * n), 1e-6, 0.95)
    newp["rho"] = _norm(rho_cnt + 1e-9)
    newp["M"] = [[_norm(readpost[v].T @ oh[v][r] + 1e-6) for r in range(3)] for v in range(4)]
    newp["d"] = np.clip(d_cnt / n, 1e-6, 0.5) if panel else np.zeros(2)
    newp["om"] = [_norm(om_cnt[P_] + 1e-9) for P_ in (0, 1)] if panel else p["om"]
    return newp, ll


def fit(Y, K, panel=False, iters=3000, tol=None, params=None):
    """Y: int array (n, 4 visits, 3 raters) of calls at one level. EM accelerated by SQUAREM (Varadhan & Roland
    2008) with a monotonicity safeguard. Returns params, loglik, Delta, iterations."""
    n = Y.shape[0]
    tol = 1e-8 * n if tol is None else tol
    U, wt = np.unique(Y.reshape(n, 12), axis=0, return_counts=True)
    U = U.reshape(-1, 4, 3); wt = wt.astype(float)
    oh = [[np.eye(K)[U[:, v, r]] for r in range(3)] for v in range(4)]
    step = lambda q: em_step(U, wt, oh, K, panel, q)
    p = params or init_params(K, panel)
    ll_old = -np.inf
    for it in range(iters):
        p1, ll0 = step(p)
        p2, ll1 = step(p1)
        x0, x1, x2 = _pack(p), _pack(p1), _pack(p2)
        r = x1 - x0; v = x2 - x1 - r
        nv = np.linalg.norm(v)
        alpha = -np.linalg.norm(r) / nv if nv > 0 else -1.0
        alpha = min(-1.0, alpha)
        cand = _project(_unpack(x0 - 2 * alpha * r + alpha ** 2 * v, K), panel)
        p3, ll_c = step(cand)
        if ll_c >= ll1:
            p, ll = p3, ll_c
        else:
            p, ll = p2, ll1                    # fall back to plain EM
        if abs(ll - ll_old) < tol:
            break
        ll_old = ll
    _, ll = step(p)
    delta = 1 - float(np.sum(p["pi"] * np.diag(p["G"])))
    return p, ll, delta, it + 1


def fit_best(Y, K, panel, starts=3, seed=0, warm=None):
    """Default start plus random starts; keep the highest log-likelihood. Also returns the spread of Delta among
    starts whose log-likelihood is within 0.5 of the best (a check on local maxima). For the panel model, one start
    is warm: the fitted model without the panel term (warm), with a small panel term added."""
    rng = np.random.default_rng(seed)
    res = [fit(Y, K, panel)]
    if panel and warm is not None:
        w = {k: (v.copy() if isinstance(v, np.ndarray) else v) for k, v in warm.items()}
        w["M"] = [[m.copy() for m in row] for row in warm["M"]]
        w["d"] = np.array([0.01, 0.01]); w["om"] = [warm["pi"].copy(), warm["pi"].copy()]
        res.append(fit(Y, K, True, params=w))
    for _ in range(starts - 1):
        res.append(fit(Y, K, panel, params=init_params(K, panel, rng)))
    best = max(res, key=lambda r: r[1])
    near = [r[2] for r in res if r[1] > best[1] - 0.5]
    return best, (min(near), max(near)), [r[1] for r in res]


def simulate(n, K, pi, G, s, rho, M, d=(0, 0), om=None, rng=None):
    """Draw calls from the model itself (for identifiability checks). M[v][r]: K x K misclassification."""
    c1 = rng.choice(K, n, p=pi)
    cum = np.cumsum(G, 1)
    c2 = (rng.random(n)[:, None] > cum[c1]).sum(1)
    Y = np.zeros((n, 4, 3), int)
    read = []
    for v in range(4):
        c = c1 if BLOCK[v] == 0 else c2
        st = rng.random(n) < s[BLOCK[v]]
        read.append(np.where(st, rng.choice(K, n, p=rho), c))
    for P_, (va, vb) in PANEL_VISITS.items():
        if d[P_] > 0:
            m = rng.random(n) < d[P_]
            a = rng.choice(K, n, p=om[P_])
            read[va] = np.where(m, a, read[va]); read[vb] = np.where(m, a, read[vb])
    for v in range(4):
        for r in range(3):
            cumM = np.cumsum(M[v][r], 1)
            Y[:, v, r] = (rng.random(n)[:, None] > cumM[read[v]]).sum(1)
    return Y, float(np.mean(c1 != c2))
