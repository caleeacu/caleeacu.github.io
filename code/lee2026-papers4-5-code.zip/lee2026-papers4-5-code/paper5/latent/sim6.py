"""
Latent trait-state model vs the kappa-based estimator of paper 5, on the same simulated studies.
Uses the data-generating model of paper5_sim.py (imported).  Run from this folder:
  python sim6.py --part=ID      identifiability: recovery at n = 50,000 with several starts
  python sim6.py --part=CMP [--level=form|group] [--reps=100]
"""
import sys, os, time
import numpy as np
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))   # paper5_sim.py
_argv = sys.argv; sys.argv = [sys.argv[0]]
import paper5_sim as S
sys.argv = _argv
import lm

SEED = 6062026


def make_calls(n, sc, rng, f_acc=0.95, **kw):
    """Eight-type calls R[v][r] exactly as one_study() of paper5_sim.py generates them."""
    P = S.present(n, sc, rng)
    mode = kw.get("mode", "even")
    if "patfall" in kw:
        share, g_to, f_to = kw["patfall"]
        sub = rng.random(n) < share
        def acc_v(v, r):
            g, f = S.accs(dict(kw, f_acc=f_acc), v, r)
            hard = v >= 2 if kw.get("pat_when", "follow") == "follow" else v <= 1
            return (np.where(sub, g_to, g), np.where(sub, f_to, f)) if hard else (g, f)
        R = [[S.rate(P[v], *acc_v(v, r), mode, rng) for r in range(3)] for v in range(4)]
    else:
        R = [[S.rate(P[v], *S.accs(dict(kw, f_acc=f_acc), v, r), mode, rng) for r in range(3)] for v in range(4)]
    if kw.get("memory", 0) > 0:
        for v, src in ((2, 1), (3, 0)):
            for r in range(3):
                R[v][r] = np.where(rng.random(n) < kw["memory"], R[src][r], R[v][r])
    return R


def level_arrays(R, lev):
    fn = (lambda x: x // 2) if lev == "group" else (lambda x: x % 2)
    L = [[fn(x) for x in R[v]] for v in range(4)]
    Y = np.stack([np.stack(L[v], 1) for v in range(4)], 1)         # n x 4 x 3
    return L, Y


def kappa_E(L, K):
    st = S.level_stats(L, K, S.Boot(len(L[0][0]), 0, None))
    return float(st["E"][0]), float(st["S"][0])


SCEN6 = [
    # name, scenario dict, kwargs, true lasting share at the level tested (None = level not changed: 0)
    ("Fixed", {}, {}),
    ("Lasting change 10%", "chg10", {}),
    ("Lasting change 25%", "chg25", {}),
    ("Fixed + recurring states 15%", "rec15", {}),
    ("Change 15% hidden by recurring states 15%", "chg15rec15", {}),
    ("Fixed + transient state 25% at visit 2", "tr25", {}),
    ("Change 10% + legibility falls for all", "chg10", {"fall": (0.10, 0.05)}),
    ("Change 10%, structured errors (partner)", "chg10", {"mode": "side"}),
    ("Change 10%, unequal raters (0.95, 0.8, 0.6)", "chg10", {"drift": [(0.95, 0.8, 0.6)] * 4}),
    ("Fixed + misreading within each panel 10%", "shared10", {}),
    ("Change 10% + misreading within each panel 10%", "chg10shared10", {}),
    ("Fixed + legibility lost by 30% of patients", {}, {"patfall": (0.3, 0.25, 0.95)}),
    ("Change 10% + rater memory 50%", "chg10", {"memory": 0.5}),
    ("Fixed + states 30% per visit, baseline only", "imb30", {}),
    ("Fixed + state through follow-up block 15%", "blk15", {}),
]


def scen_dict(code, lev):
    k = "f" if lev == "form" else "g"
    d = {}
    if not isinstance(code, str):
        return dict(code), 0.0
    truth = 0.0
    for part, val in (("chg10", 0.10), ("chg25", 0.25), ("chg15", 0.15)):
        if code.startswith(part):
            d["df" if k == "f" else "dg"] = val; truth = val
    if "rec15" in code: d["rec_" + k] = 0.15
    if code == "tr25": d["tr_" + k] = {1: 0.25}
    if "shared10" in code: d["shared"] = (k, 0.10)
    if code == "imb30": d["rec_" + k + "_v"] = (0.3, 0.3, 0, 0)
    if code == "blk15": d["blk_" + k] = 0.15; truth = 0.15        # reads as lasting change by the design's definition
    return d, truth


def part_ID(say):
    say("PART ID  identifiability: n = 50,000, form accuracy 0.95, group accuracy 0.8; 4 starts (default + 3 random)")
    say("level | scenario | truth | kappa E | LM (no panel term): Delta, spread over starts | LM + panel term: Delta, spread, d_A, d_B, s_1, s_2")
    rng = np.random.default_rng(SEED)
    for lev, K in (("form", 2), ("group", 4)):
        for name, code, kw in SCEN6:
            sc, truth = scen_dict(code, lev)
            R = make_calls(50_000, sc, rng, **kw)
            L, Y = level_arrays(R, lev)
            E, _ = kappa_E(L, K)
            (p0, ll0, d0, _), sp0, _ = lm.fit_best(Y, K, False, starts=4, seed=1)
            (p1, ll1, d1, _), sp1, _ = lm.fit_best(Y, K, True, starts=4, seed=2, warm=p0)
            say(f"{lev:5s} | {name:46s} | {truth:.3f} | {E:.3f} | {d0:.3f} [{sp0[0]:.3f}, {sp0[1]:.3f}] | "
                f"{d1:.3f} [{sp1[0]:.3f}, {sp1[1]:.3f}], d {p1['d'][0]:.3f} {p1['d'][1]:.3f}, s {p1['s'][0]:.3f} {p1['s'][1]:.3f}")


def part_CMP(say, levels, reps):
    say(f"PART CMP  n = 1,000, {reps} studies per row, form accuracy 0.95, group accuracy 0.8; point estimates only")
    say("level | scenario | truth | kappa E: mean, SD, RMSE | LM: mean, SD, RMSE | LM + panel term: mean, SD, RMSE")
    for lev in levels:
        K = 2 if lev == "form" else 4
        rng = np.random.default_rng(SEED + (1 if lev == "form" else 2))
        for name, code, kw in SCEN6:
            sc, truth = scen_dict(code, lev)
            est = []
            for _ in range(reps):
                R = make_calls(1000, sc, rng, **kw)
                L, Y = level_arrays(R, lev)
                E, _ = kappa_E(L, K)
                b0 = lm.fit_best(Y, K, False, starts=2, seed=3)[0]
                d0 = b0[2]
                d1 = lm.fit_best(Y, K, True, starts=2, seed=4, warm=b0[0])[0][2]
                est.append((E, d0, d1))
            a = np.array(est)
            cells = [f"{a[:, j].mean():.3f}, {a[:, j].std():.3f}, {np.sqrt(((a[:, j] - truth) ** 2).mean()):.3f}" for j in range(3)]
            say(f"{lev:5s} | {name:46s} | {truth:.3f} | " + " | ".join(cells))


def part_SELF(say):
    """Identifiability under the model's own assumptions: data drawn from the latent model itself, n = 50,000,
    raters of accuracy 0.9 / 0.8 / 0.7 falling by 0.1 at follow-up; several starts."""
    say("PART SELF  data from the latent model itself; n = 50,000; 3 starts (no panel term), 5 starts (panel term)")
    say("K | scenario | true Delta | LM: Delta [spread over starts within 0.5 log-lik] | LM + panel: Delta [spread], s (true), d (true) | log-lik of starts minus best")
    rng = np.random.default_rng(SEED + 10)
    Mm = lambda K, a: np.full((K, K), (1 - a) / (K - 1)) + np.eye(K) * (a - (1 - a) / (K - 1))
    for K, pi in ((2, np.array([0.65, 0.35])), (4, np.array([0.35, 0.28, 0.25, 0.12]))):
        for lab, lc, s, d in (("clean, 10% change", 0.10, (0, 0), (0, 0)), ("10% change + states 20%", 0.10, (0.2, 0.2), (0, 0)),
                              ("10% change + panel misreading 10%", 0.10, (0, 0), (0.1, 0.1)),
                              ("10% change + states 15% + panel misreading 10%", 0.10, (0.15, 0.15), (0.1, 0.1)),
                              ("10% change + states 30% baseline / 5% follow-up", 0.10, (0.3, 0.05), (0, 0)),
                              ("fixed + states 20% + panel misreading 10%", 0.0, (0.2, 0.2), (0.1, 0.1))):
            G = (1 - lc) * np.eye(K) + lc * (np.ones((K, K)) - np.eye(K)) / (K - 1)
            M = [[Mm(K, (0.9, 0.8, 0.7)[r] - (0.1 if v >= 2 else 0)) for r in range(3)] for v in range(4)]
            Y, tr = lm.simulate(50_000, K, pi, G, s, pi, M, d, [pi, pi], rng)
            b0, sp0, _ = lm.fit_best(Y, K, False, starts=3, seed=1)
            b1, sp1, ll1 = lm.fit_best(Y, K, True, starts=5, seed=5, warm=b0[0])
            say(f"{K} | {lab:48s} | {tr:.3f} | {b0[2]:.3f} [{sp0[0]:.3f}, {sp0[1]:.3f}] | {b1[2]:.3f} [{sp1[0]:.3f}, {sp1[1]:.3f}], "
                f"s {b1[0]['s'][0]:.3f} {b1[0]['s'][1]:.3f} ({s[0]}, {s[1]}), d {b1[0]['d'][0]:.3f} {b1[0]['d'][1]:.3f} ({d[0]}, {d[1]}) | "
                + " ".join(f"{x - max(ll1):.1f}" for x in ll1))


if __name__ == "__main__":
    part = [a.split("=")[1] for a in sys.argv if a.startswith("--part=")][0]
    levels = [a.split("=")[1] for a in sys.argv if a.startswith("--level=")] or ["form", "group"]
    reps = int(([a.split("=")[1] for a in sys.argv if a.startswith("--reps=")] or ["100"])[0])
    lines = []
    say = lambda s="": (print(s, flush=True), lines.append(s))
    t = time.time()
    if part == "ID":
        part_ID(say)
    elif part == "SELF":
        part_SELF(say)
    else:
        part_CMP(say, levels, reps)
    say(f"(elapsed {time.time() - t:.0f} s)")
    tag = part + ("_" + "_".join(levels) if part == "CMP" else "")
    if part == "CMP" and reps != 100:
        tag += f"_r{reps}"
    open(f"sim6_output_{tag}.txt", "w").write("\n".join(lines) + "\n")
