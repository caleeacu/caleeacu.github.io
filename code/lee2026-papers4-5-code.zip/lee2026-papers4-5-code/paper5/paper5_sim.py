"""
Operating characteristics for:
Lee, H. (2026). At What Level Is Constitution Fixed? A Pre-Registrable Design for
Telling Fixed, Non-Fixed and Hierarchical Accounts of Eight Constitution Medicine Apart.

Self-contained (numpy only).
Run:  python paper5_sim.py --part=A|B|C|E|F|G|H|I|J|K|M|L|N|O|P|Q [--facc=0.90] [--n=1000] [--cell=0|1|2] [--quick]
Each run writes paper5_sim_output_<parts>.txt; the supplied paper5_sim_output.txt concatenates
the outputs of parts A, E, F, B, C, G, H, I, J, K, M, L, N and O, run separately (part B once per form accuracy and
sample size, e.g. --part=B --facc=0.95 --n=1000; each cell has its own seed).  With
OMP_NUM_THREADS=1 and two processes at a time the whole set takes about an hour.

DESIGN SIMULATED
  Four visits in two blocks: baseline (visits 1 and 2, about two weeks apart) and follow-up
  (visits 3 and 4, about two weeks apart, several months later).  Two panels of three pulse
  raters: panel A reads visits 1 and 4, panel B visits 2 and 3, so that no rater is compared with
  his own earlier call and no rater reads a patient twice within a block (memory across the gap
  between the blocks is reduced, not removed; simulated raters have no memory except in parts I, K and M).
  Each eight-type call is scored at two levels: GROUP (Metal, Earth, Wood, Water) and FORM.

ESTIMANDS (per level)
  same-day kappa at visit v : mean kappa over the 3 rater pairs of the panel reading visit v
  R_ab = cross-visit kappa (mean over the 9 rater pairs) / sqrt(same_a * same_b)
  pi_ab = (1 - R_ab) * (1 - pe_ab)    share of patients whose level differs between visits a, b
                                       (exact when R equals the kappa between true types and
                                       pe uses the true marginals; here pe uses pooled calls)
  E = (pi_13 + pi_24)/2 - (pi_12 + pi_34)/2    share with LASTING change between the blocks:
        a state confined to any one visit, a recurring state, or a change within a block
        contributes zero; a change between the blocks that persists contributes one.
  S = (pi_12 + pi_34)/2                         within-block disagreement (passing states).

DECISION RULE (per level), smallest effect of interest e0 = 0.10 on E:
  gate          lower 2.5% bound of same-day kappa > 0.20 at every visit, else 'unreadable'
  stable        upper 97.5% bound of S < 0.05 (state ceiling) AND
                upper 97.5% bound of E < e0 * (1 - 2 * upper bound of S)
                (passing states attenuate E: under symmetric binary misclassification by states,
                E = true lasting share * (1 - 2S) exactly; the ceiling keeps S where this holds
                approximately in the simulated model, see part G)
  changed       lower 2.5%  bound of E >  e0   (states only lower E, so no adjustment is needed)
  memory        (registered, applied on top of the core rule; part K) the stability bound is further multiplied by
                1 - CMEM * max(hi(D), 0), D = same-rater minus different-rater kappa between the two visits each
                panel reads, averaged over the two panels
  undetermined  otherwise
  state flag    lower 2.5% bound of S > 0.05
  verdict       (group, form): (stable, stable) fixed; (stable, changed) hierarchical;
                (changed, stable) reverse hierarchical; (changed, changed) non-fixed;
                anything else undetermined.
Percentile intervals from a patient-level bootstrap; all statistics share each resample.

DATA-GENERATING MODEL
  Constitution drawn from the distribution of 925 ECM outpatients (Kim et al. 2009).
  Change is marginal-preserving: a changing patient's group is redrawn from p(group | form)
  (form kept), or the form from p(form | group) (group kept); redraw rates are scaled so that
  the stated share is the expected share whose level actually differs.
  Lasting change happens between the blocks and persists.  A transient state alters the
  presentation at one named visit; a recurring state alters it at every visit independently.
  All raters read the presented type.  A rater reads the group correctly with prob g_acc; a
  wrong group goes to another group ('even'), to the same-autonomic-side partner with prob 0.6
  ('side'), or to the mirror group with prob 0.6 ('mirror'); the form is read correctly with
  prob f_acc when the group is right and is random otherwise.
"""
import sys
import numpy as np

# Pul, Col, Pan, Gas, Hep, Cho, Ren, Ves -> type = 2*group + form; group 0 Metal 1 Earth 2 Wood 3 Water
ECM = np.array([167, 160, 259, 4, 167, 65, 24, 79], float); ECM /= ECM.sum()
JOINT = ECM.reshape(4, 2)
P_G_GIVEN_F = JOINT / JOINT.sum(0, keepdims=True)
P_F_GIVEN_G = JOINT / JOINT.sum(1, keepdims=True)
NG = sum(JOINT[:, f].sum() * (1 - (P_G_GIVEN_F[:, f] ** 2).sum()) for f in range(2))
NF = sum(JOINT[g].sum() * (1 - (P_F_GIVEN_G[g] ** 2).sum()) for g in range(4))
PARTNER = np.array([3, 2, 1, 0])   # same autonomic side: Metal-Water, Earth-Wood
MIRROR = np.array([2, 3, 0, 1])    # strongest/weakest organs swapped: Metal-Wood, Earth-Water
E0, GATE, SFLAG, SCAP = 0.10, 0.20, 0.05, 0.05
CMEM = 3.4   # memory adjustment: E is lowered by about the factor (1 - CMEM * D) under memory (part K); re-estimated in Stage 1
SEED = 5052026
QUICK = "--quick" in sys.argv
PANEL = (0, 1, 1, 0)               # panel reading visit 1..4 (A, B, B, A)
PAIRS = {"12": (0, 1), "34": (2, 3), "13": (0, 2), "24": (1, 3)}


def redraw_group(t, share, rng):
    g, f = t // 2, t % 2
    m = rng.random(len(t)) < share / NG
    u = rng.random(len(t))
    cum = np.cumsum(P_G_GIVEN_F, axis=0)[:, f]
    ng = (u[None, :] > cum).sum(0)
    return np.where(m, 2 * ng + f, t)


def redraw_form(t, share, rng):
    g, f = t // 2, t % 2
    m = rng.random(len(t)) < share / NF
    nf = (rng.random(len(t)) > P_F_GIVEN_G[g, 0]).astype(int)
    return np.where(m, 2 * g + nf, t)


def present(n, sc, rng):
    """Presented eight-type at visits 1-4 for scenario dict sc.
    sc['shared'] = (level, share): each panel persistently misreads a fixed set of patients at that
    level (the same patients and the same wrong reading at both of its visits and for all three of its
    raters); the two panels misread independently."""
    c1 = rng.choice(8, n, p=ECM)
    c2 = redraw_form(redraw_group(c1, sc.get("dg", 0.0), rng), sc.get("df", 0.0), rng)
    if sc.get("dgp", 0) > 0:                 # lasting group change to the autonomic partner (form kept)
        c2 = np.where(rng.random(n) < sc["dgp"], 2 * PARTNER[c2 // 2] + c2 % 2, c2)
    out = []
    for v, c in enumerate((c1, c1, c2, c2)):
        p = c
        if sc.get("rec_g", 0) > 0:
            p = redraw_group(p, sc["rec_g"], rng)
        if sc.get("rec_f", 0) > 0:
            p = redraw_form(p, sc["rec_f"], rng)
        if "rec_f_v" in sc and sc["rec_f_v"][v] > 0:     # recurring form states at a per-visit rate
            p = redraw_form(p, sc["rec_f_v"][v], rng)
        if "rec_g_v" in sc and sc["rec_g_v"][v] > 0:
            p = redraw_group(p, sc["rec_g_v"][v], rng)
        if v in sc.get("tr_g", {}):
            p = redraw_group(p, sc["tr_g"][v], rng)
        if v in sc.get("tr_f", {}):
            p = redraw_form(p, sc["tr_f"][v], rng)
        out.append(p)
    for key, fn in (("blk_g", redraw_group), ("blk_f", redraw_form)):   # a state present at both follow-up visits
        if sc.get(key, 0) > 0:
            sub = np.random.default_rng(rng.integers(2**63)); st0 = sub.bit_generator.state
            for v in (2, 3):
                sub.bit_generator.state = st0
                out[v] = fn(out[v], sc[key], sub)
    if "shared" in sc:
        lev, share = sc["shared"]
        for panel in (0, 1):
            sub = np.random.default_rng(rng.integers(2**63))
            state = sub.bit_generator.state
            for v in range(4):
                if PANEL[v] == panel:
                    sub.bit_generator.state = state          # same draws at both visits of the panel
                    out[v] = (redraw_group if lev == "g" else redraw_form)(out[v], share, sub)
    return out


def rate(t, g_acc, f_acc, mode, rng):
    n = len(t)
    g, f = t // 2, t % 2
    gw = rng.random(n) > g_acc
    if mode == "even":
        wrong = (g + rng.integers(1, 4, n)) % 4
    else:
        sp = PARTNER if mode == "side" else MIRROR
        others = np.array([[x for x in range(4) if x != a and x != sp[a]] for a in range(4)])
        wrong = np.where(rng.random(n) < 0.6, sp[g], others[g, rng.integers(0, 2, n)])
    rg = np.where(gw, wrong, g)
    rf = np.where(rng.random(n) < f_acc, f, 1 - f)
    rf = np.where(gw, rng.integers(0, 2, n), rf)
    return 2 * rg + rf


class Boot:
    """Patient-level bootstrap held as multiplicity weights; row 0 is the original sample."""
    def __init__(self, n, B, rng):
        self.n, self.rows = n, B + 1
        W = np.ones((B + 1, n))
        if B:
            idx = rng.integers(0, n, (B, n))
            W[1:] = np.bincount((np.arange(B)[:, None] * n + idx).ravel(), minlength=B * n).reshape(B, n)
        self.W = W

    def kappa(self, a, b, K):
        oh = np.zeros((self.n, K * K)); oh[np.arange(self.n), a * K + b] = 1
        C = (self.W @ oh).reshape(self.rows, K, K) / self.n
        po = np.trace(C, axis1=1, axis2=2)
        pe = (C.sum(2) * C.sum(1)).sum(1)
        return (po - pe) / np.maximum(1 - pe, 1e-12)

    def marg(self, labs, K):
        oh = np.zeros((self.n, K))
        for a in labs:
            oh[np.arange(self.n), a] += 1
        return (self.W @ oh) / (self.n * len(labs))


def level_stats(L, K, bt):
    """L[v][r]: labels at visit v from rater r of the panel reading v."""
    same = [np.mean([bt.kappa(L[v][i], L[v][j], K) for i in range(3) for j in range(i + 1, 3)], 0) for v in range(4)]
    marg = [bt.marg(L[v], K) for v in range(4)]
    pi = {}
    for key, (a, b) in PAIRS.items():
        cross = np.mean([bt.kappa(L[a][i], L[b][j], K) for i in range(3) for j in range(3)], 0)
        R = cross / np.sqrt(np.maximum(same[a], 1e-9) * np.maximum(same[b], 1e-9))
        pi[key] = (1 - R) * (1 - (marg[a] * marg[b]).sum(1))
    E = (pi["13"] + pi["24"]) / 2 - (pi["12"] + pi["34"]) / 2
    S = (pi["12"] + pi["34"]) / 2
    return dict(same=np.array(same), E=E, S=S, pi12=pi["12"], pi34=pi["34"])


def classify(st):
    lo = lambda x: np.percentile(x[1:], 2.5)
    hi = lambda x: np.percentile(x[1:], 97.5)
    if not all(lo(st["same"][v]) > GATE for v in range(4)):
        return "unreadable", False
    s_hi = hi(st["S"])
    if s_hi < SCAP and hi(st["E"]) < E0 * (1 - 2 * max(s_hi, 0.0)):   # S floored at zero
        z = "stable"
    else:
        z = "changed" if lo(st["E"]) > E0 else "undetermined"
    return z, lo(st["S"]) > SFLAG


def maj3(c):
    """Majority call of three raters; -1 if all three differ."""
    a, b, d = c
    m = np.full(len(a), -1)
    m = np.where(b == d, b, m); m = np.where(a == d, a, m); m = np.where(a == b, a, m)
    return m


def welch_p(x, y):
    """Two-sided P for a difference in means (Welch z)."""
    from math import erfc, sqrt
    if len(x) < 2 or len(y) < 2:
        return 1.0
    se = sqrt(x.var(ddof=1) / len(x) + y.var(ddof=1) / len(y))
    if se == 0:
        return 1.0
    return erfc(abs(x.mean() - y.mean()) / se / sqrt(2))


def unanimity_ok(L):
    """Unanimity check (section 5): classify patients by one panel's majority calls (differ / agree between its
    two visits), score the change in the other panel's same-day unanimity; withhold 'changed' if either of the two
    comparisons differs at two-sided 2.5% (5% overall, Bonferroni)."""
    unan = lambda c: ((c[0] == c[1]) & (c[1] == c[2])).astype(float)
    for (ca, cb), (sa, sb) in (((1, 2), (0, 3)), ((0, 3), (1, 2))):
        ma, mb = maj3(L[ca]), maj3(L[cb])
        ok = (ma >= 0) & (mb >= 0)
        score = unan(L[sb]) - unan(L[sa])
        if welch_p(score[ok & (ma != mb)], score[ok & (ma == mb)]) < 0.025:
            return False
    return True


def balance_term(st):
    """Balance check (section 5): Delta^2 / {4 (1 - 2 S_bar)^2}, Delta = upper bound of |pi12 - pi34|."""
    D = np.percentile(np.abs(st["pi12"] - st["pi34"])[1:], 97.5)
    Sb = max(np.percentile(st["S"][1:], 97.5), 0.0)
    return D ** 2 / (4 * max(1 - 2 * Sb, 0.05) ** 2)


def classify_full(st, stable_adj, unan_ok):
    """Full registered rule at one level: memory-adjusted stability; change needs the balance-raised threshold
    and a passed unanimity check. Returns (outcome, withheld_by_check)."""
    lo = lambda x: np.percentile(x[1:], 2.5)
    if not all(lo(st["same"][v]) > GATE for v in range(4)):
        return "unreadable", False
    if stable_adj:
        return "stable", False
    core = lo(st["E"]) > E0
    full = lo(st["E"]) > E0 + balance_term(st) and unan_ok
    return ("changed" if full else "undetermined"), bool(core and not full)


TABLE = {("stable", "stable"): "fixed", ("stable", "changed"): "hierarchical",
         ("changed", "stable"): "reverse hierarchical", ("changed", "changed"): "non-fixed"}


def accs(kw, v, r):
    """(group accuracy, form accuracy) of rater r at visit v."""
    g = kw.get("g_acc", 0.8); f = kw["f_acc"]
    if "drift" in kw:                       # per-visit tuples of per-rater group accuracy
        g = kw["drift"][v][r]
    if "fall" in kw and v >= 2:             # legibility falls at follow-up
        g, f = g - kw["fall"][0], f - kw["fall"][1]
    return g, f


def one_study(n, sc, B, rng, **kw):
    P = present(n, sc, rng)
    mode = kw.get("mode", "even")
    if "patfall" in kw:                     # a fixed subset of patients becomes harder to read at follow-up
        share, g_to, f_to = kw["patfall"]
        sub = rng.random(n) < share
        def acc_v(v, r):
            g, f = accs(kw, v, r)
            hard = v >= 2 if kw.get("pat_when", "follow") == "follow" else v <= 1
            return (np.where(sub, g_to, g), np.where(sub, f_to, f)) if hard else (g, f)
        R = [[rate(P[v], *acc_v(v, r), mode, rng) for r in range(3)] for v in range(4)]
    else:
        R = [[rate(P[v], *accs(kw, v, r), mode, rng) for r in range(3)] for v in range(4)]
    if kw.get("pxr", 0) > 0:                # each rater persistently misreads the form of his own fixed set of patients
        for panel in (0, 1):
            for r in range(3):
                mk = rng.random(n) < kw["pxr"]
                for v in range(4):
                    if PANEL[v] == panel:
                        R[v][r] = np.where(mk, 2 * (R[v][r] // 2) + 1 - R[v][r] % 2, R[v][r])
    if kw.get("memory", 0) > 0:             # a rater repeats his own call from the other block (B: visit 2 -> 3, A: 1 -> 4)
        for v, src in ((2, 1), (3, 0)):
            for r in range(3):
                R[v][r] = np.where(rng.random(n) < kw["memory"], R[src][r], R[v][r])
    bt = Boot(n, B, rng)
    memdiag = np.nan
    if kw.get("keep_calls"):
        b0 = Boot(n, 0, rng)
        fa = [x % 2 for x in R[0]]; fd = [x % 2 for x in R[3]]
        same = np.mean([b0.kappa(fa[i], fd[i], 2)[0] for i in range(3)])
        diff = np.mean([b0.kappa(fa[i], fd[j], 2)[0] for i in range(3) for j in range(3) if i != j])
        memdiag = same - diff
    sg = level_stats([[x // 2 for x in R[v]] for v in range(4)], 4, bt)
    sf = level_stats([[x % 2 for x in R[v]] for v in range(4)], 2, bt)
    zg, fg = classify(sg); zf, ff = classify(sf)
    memfail = madj = None
    if kw.get("memcheck") or kw.get("full"):
        # memory diagnostic (unscaled): same-rater minus different-rater kappa between the two visits a panel reads
        # (A: visits 1-4, B: 2-3).  memfail: the earlier blocking check (lower 2.5% bound > 0, per panel and level).
        # madj: the adjusted stability condition, per level, with D = mean of the two panels' diagnostics:
        #   stable iff hi(S) < SCAP and hi(E) < e0 (1 - 2 max(hi(S), 0)) (1 - CMEM max(hi(D), 0))
        memfail, madj = {}, {}
        for lev, K, fn, st in (("g", 4, lambda x: x // 2, sg), ("f", 2, lambda x: x % 2, sf)):
            ds = []
            for pname, (a, b) in (("A", (0, 3)), ("B", (1, 2))):
                xa = [fn(x) for x in R[a]]; xb = [fn(x) for x in R[b]]
                same = np.mean([bt.kappa(xa[i], xb[i], K) for i in range(3)], 0)
                diff = np.mean([bt.kappa(xa[i], xb[j], K) for i in range(3) for j in range(3) if i != j], 0)
                memfail[pname + lev] = np.percentile((same - diff)[1:], 2.5) > 0
                ds.append(same - diff)
            hiD = max(np.percentile(((ds[0] + ds[1]) / 2)[1:], 97.5), 0.0)
            hiS = np.percentile(st["S"][1:], 97.5); hiE = np.percentile(st["E"][1:], 97.5)
            readable = classify(st)[0] != "unreadable"
            madj[lev] = bool(readable and hiS < SCAP and hiE < E0 * (1 - 2 * max(hiS, 0.0)) * (1 - CMEM * hiD))
    hi = lambda x: np.percentile(x[1:], 97.5)
    full = None
    if kw.get("full"):
        full = {}
        for lev, fn, st in (("g", lambda x: x // 2, sg), ("f", lambda x: x % 2, sf)):
            L = [[fn(x) for x in R[v]] for v in range(4)]
            full[lev] = classify_full(st, madj[lev], unanimity_ok(L))
        full["verdict"] = TABLE.get((full["g"][0], full["f"][0]), "undetermined")
    return dict(full=full, verdict=TABLE.get((zg, zf), "undetermined"), zg=zg, zf=zf, state=fg or ff,
                Eg=sg["E"][0], Ef=sf["E"][0], memdiag=memdiag, memfail=memfail, madj=madj,
                rs_g=hi(sg["E"]) / (E0 * (1 - 2 * max(hi(sg["S"]), 0.0))), sh_g=hi(sg["S"]),
                lo_g=np.percentile(sg["E"][1:], 2.5), lo_f=np.percentile(sf["E"][1:], 2.5))


def wilson_hi(k, n, z=1.96):
    p = k / n
    return (p + z * z / (2 * n) + z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n))) / (1 + z * z / n)


def oc_cells(say, reps, B, cells, seed):
    say("level | f_acc | n | true E | mean est E | P(stable) | P(undetermined) | P(changed) | P(unreadable)")
    rng = np.random.default_rng(seed)
    for f_acc, n in cells:
        for lev in ("group", "form"):
            for d in OC_GRID:
                sc = {"dg": d} if lev == "group" else {"df": d}
                res = [one_study(n, sc, B, rng, f_acc=f_acc) for _ in range(reps)]
                z = [r["zg"] if lev == "group" else r["zf"] for r in res]
                est = np.mean([r["Eg"] if lev == "group" else r["Ef"] for r in res])
                p = lambda s: np.mean([x == s for x in z])
                say(f"{lev:5s} | {f_acc:.2f} | {n:4d} | {d:.3f} | {est:.3f} | {p('stable'):.3f} | "
                    f"{p('undetermined'):.3f} | {p('changed'):.3f} | {p('unreadable'):.3f}")


OC_GRID = (0.0, 0.05, 0.075, 0.10, 0.125, 0.15, 0.20)


def part_A(say, reps, B):
    say("PART A  one level changes lastingly between blocks, the other fixed; group accuracy 0.8, even errors")
    oc_cells(say, reps, B, ((0.95, 1000), (0.95, 2000), (0.90, 1000)), SEED + 1)


def part_E(say, reps, B):
    say(f"PART E  size at the margin (true E = 0.10), {reps} studies per cell; group accuracy 0.8, even errors")
    say("level | f_acc | n | added states | mean est E | P(stable) | P(changed) | 95% upper bound of P(changed)")
    rng = np.random.default_rng(SEED + 5)
    cells = [(f, n, lev, {}) for f, n in ((0.95, 1000), (0.95, 2000), (0.90, 1000)) for lev in ("group", "form")]
    cells += [(0.95, 1000, "form", {"rec_f": 0.02}), (0.95, 1000, "form", {"tr_f": {1: 0.10}}),
              (0.95, 1000, "form", {"shared": ("f", 0.05)}), (0.95, 1000, "group", {"rec_g": 0.02})]
    for f_acc, n, lev, extra in cells:
            sc = dict({"dg": 0.10} if lev == "group" else {"df": 0.10}, **extra)
            res = [one_study(n, sc, B, rng, f_acc=f_acc) for _ in range(reps)]
            z = [r["zg"] if lev == "group" else r["zf"] for r in res]
            est = np.mean([r["Eg"] if lev == "group" else r["Ef"] for r in res])
            kc = sum(x == "changed" for x in z)
            say(f"{lev:5s} | {f_acc:.2f} | {n:4d} | {str(extra) or '-'} | {est:.3f} | {np.mean([x == 'stable' for x in z]):.3f} | "
                f"{kc / reps:.3f} | {wilson_hi(kc, reps):.3f}")


DRIFT = [(0.9, 0.8, 0.7), (0.9, 0.8, 0.7), (0.7, 0.8, 0.9), (0.7, 0.8, 0.9)]
SCEN = [
    ("Fixed", {}, "fixed", {}),
    ("Fixed + transient form state 25% at visit 2", {"tr_f": {1: 0.25}}, "fixed", {}),
    ("Fixed + transient group state 15% at visit 3", {"tr_g": {2: 0.15}}, "fixed", {}),
    ("Fixed + transient form state 15% at visit 1", {"tr_f": {0: 0.15}}, "fixed", {}),
    ("Fixed + recurring group states 10% per visit", {"rec_g": 0.10}, "fixed", {}),
    ("Fixed + recurring form states 15% per visit", {"rec_f": 0.15}, "fixed", {}),
    ("Fixed + legibility falls at follow-up", {}, "fixed", {"fall": (0.10, 0.05)}),
    ("Fixed + rater-order drift", {}, "fixed", {"drift": DRIFT}),
    ("Fixed + structured errors (partner)", {}, "fixed", {"mode": "side"}),
    ("Fixed + structured errors (mirror)", {}, "fixed", {"mode": "mirror"}),
    ("Below the margin: 6% at both levels", {"dg": 0.06, "df": 0.06}, "fixed", {}),
    ("Hierarchical: 25% form", {"df": 0.25}, "hierarchical", {}),
    ("Hierarchical, structured errors (partner)", {"df": 0.25}, "hierarchical", {"mode": "side"}),
    ("Hierarchical + transient form state 10% at visit 3", {"df": 0.25, "tr_f": {2: 0.10}}, "hierarchical", {}),
    ("Reverse: 20% group", {"dg": 0.20}, "reverse hierarchical", {}),
    ("Reverse + recurring group states 5% per visit", {"dg": 0.20, "rec_g": 0.05}, "reverse hierarchical", {}),
    ("Non-fixed: 20% group + 25% form", {"dg": 0.20, "df": 0.25}, "non-fixed", {}),
    ("Fixed + recurring form states 2% per visit", {"rec_f": 0.02}, "fixed", {}),
    ("Fixed + form misread in each panel, 10%", {"shared": ("f", 0.10)}, "fixed", {}),
    ("Hierarchical 15% form, masked by recurring form states 15%", {"df": 0.15, "rec_f": 0.15}, "hierarchical", {}),
    ("Hierarchical 15% form + form misread in each panel 10%", {"df": 0.15, "shared": ("f", 0.10)}, "hierarchical", {}),
    ("Reverse 15% group, masked by recurring group states 10%", {"dg": 0.15, "rec_g": 0.10}, "reverse hierarchical", {}),
]
VERD = ["fixed", "hierarchical", "reverse hierarchical", "non-fixed", "undetermined"]


def part_B(say, reps, B, faccs, ns=(150, 500, 1000)):
    say("PART B  named scenarios; group accuracy 0.8 unless stated")
    say("scenario | f_acc | n | correct | " + " / ".join(VERD) +
        " | wrong (95% upper) | reached a verdict | mean est E group, form | state flagged | form unreadable"
        " | level declared changed: group, form")
    for f_acc in faccs:
        for n in ns:
            rng = np.random.default_rng(SEED + 100 + int(round(f_acc * 100)) + n)   # one stream per cell
            for name, sc, truth, kw in SCEN:
                res = [one_study(n, sc, B, rng, f_acc=f_acc, **kw) for _ in range(reps)]
                share = [np.mean([r["verdict"] == v for r in res]) for v in VERD]
                k_wrong = sum(r["verdict"] not in (truth, "undetermined") for r in res)
                verd = np.mean([r["verdict"] != "undetermined" for r in res])
                say(f"{name:52s} | {f_acc:.2f} | {n:4d} | {np.mean([r['verdict'] == truth for r in res]):.3f} | "
                    + " / ".join(f"{s:.3f}" for s in share)
                    + f" | {k_wrong}/{reps} ({wilson_hi(k_wrong, reps):.3f}) | {verd:.3f} | "
                    f"{np.mean([r['Eg'] for r in res]):.3f}, {np.mean([r['Ef'] for r in res]):.3f} | "
                    f"{np.mean([r['state'] for r in res]):.3f} | {np.mean([r['zf'] == 'unreadable' for r in res]):.3f} | "
                    f"{np.mean([r['zg'] == 'changed' for r in res]):.3f}, {np.mean([r['zf'] == 'changed' for r in res]):.3f}")


def part_C(say, reps, B):
    say(f"PART C  readability (fixed constitution, even errors; {B} bootstrap resamples per study)")
    say("g_acc | f_acc | true same-day kappa group / form | gate passed at every visit, group, form: n=150 | 300 | 500 | 1000 "
        "| Stage 1 (n=150) point estimate of form kappa >= 0.25")
    rng = np.random.default_rng(SEED + 7)
    for g_acc in (0.7, 0.8, 0.9):
        for f_acc in (0.8, 0.85, 0.9, 0.95):
            t = rng.choice(8, 400_000, p=ECM)
            a = rate(t, g_acc, f_acc, "even", rng); b = rate(t, g_acc, f_acc, "even", rng)
            bt0 = Boot(400_000, 0, rng)
            kg = bt0.kappa(a // 2, b // 2, 4)[0]; kf = bt0.kappa(a % 2, b % 2, 2)[0]
            cells = []; go = 0
            for n in (150, 300, 500, 1000):
                pg = pf = 0
                for _ in range(reps):
                    c = rng.choice(8, n, p=ECM)
                    R = [[rate(c, g_acc, f_acc, "even", rng) for _ in range(3)] for _ in range(4)]
                    bt = Boot(n, B, rng)
                    for lev, K, fn in (("g", 4, lambda x: x // 2), ("f", 2, lambda x: x % 2)):
                        ok = True; pts = []
                        for v in range(4):
                            s = np.mean([bt.kappa(fn(R[v][i]), fn(R[v][j]), K) for i in range(3) for j in range(i + 1, 3)], 0)
                            ok &= np.percentile(s[1:], 2.5) > GATE
                            pts.append(s[0])
                        if lev == "g":
                            pg += ok
                        else:
                            pf += ok
                            if n == 150:
                                go += np.mean(pts) >= 0.25
                cells.append(f"{pg / reps:.2f}, {pf / reps:.2f}")
            say(f"{g_acc:.1f} | {f_acc:.2f} | {kg:.2f} / {kf:.2f} | " + " | ".join(cells) + f" | {go / reps:.2f}")


def part_F(say, B):
    """Calibration as in protocol item 9: the critical value for 'changed' is set to the 97.5th percentile
    of the lower bound of E in studies simulated at E = 0.10, then checked on fresh studies."""
    say("PART F  calibrated threshold for 'changed' (critical value c = 97.5th percentile of the lower bound of E "
        "in 600 studies at E = 0.10); checked on fresh studies")
    say("level | f_acc | n | c | P(changed) at E=0.10, fresh 400 (95% upper) | P(changed) at E=0.15, 300 | uncalibrated, same studies")
    rng = np.random.default_rng(SEED + 9)
    for lev, f_acc, n in (("form", 0.95, 1000), ("form", 0.90, 1000), ("group", 0.95, 1000), ("form", 0.95, 2000)):
        key = "lo_g" if lev == "group" else "lo_f"
        zk = "zg" if lev == "group" else "zf"
        mk = lambda d: {"dg": d} if lev == "group" else {"df": d}
        cal = [one_study(n, mk(0.10), B, rng, f_acc=f_acc) for _ in range(600)]
        c = np.percentile([r[key] for r in cal if r[zk] != "unreadable"], 97.5)
        val = [one_study(n, mk(0.10), B, rng, f_acc=f_acc) for _ in range(400)]
        pw = [one_study(n, mk(0.15), B, rng, f_acc=f_acc) for _ in range(300)]
        kv = sum(r[key] > c and r[zk] != "unreadable" for r in val)
        say(f"{lev:5s} | {f_acc:.2f} | {n:4d} | {c:.4f} | {kv / 400:.3f} ({wilson_hi(kv, 400):.3f}) | "
            f"{np.mean([r[key] > c and r[zk] != 'unreadable' for r in pw]):.3f} | "
            f"{np.mean([r[zk] == 'changed' for r in val]):.3f}, {np.mean([r[zk] == 'changed' for r in pw]):.3f}")


def part_H(say, B):
    """Two situations outside the guarantees of parts B and E.
    (1) A state that lasts through the whole follow-up block is, by construction, lasting change between the blocks.
    (2) Group change directed to the raters' main confusion (the autonomic partner) under partner-structured errors:
        size of the stability claim at the margin, and the calibration of item 9 applied to the stability bound
        (multiplier k = 2.5th percentile of hi(E) / (e0 (1 - 2 hi(S))) in 600 studies at E = 0.10; checked on 400 fresh)."""
    say("PART H  (1) block-long states; (2) change aligned with partner-structured errors; group accuracy 0.8, form 0.95")
    rng = np.random.default_rng(SEED + 13)
    say("(1) fixed constitution, state present at both follow-up visits, 300 studies of 1,000 | P(changed) group, form | mean est E group, form")
    for name, sc in (("form state 15% at visits 3-4", {"blk_f": 0.15}), ("group state 10% at visits 3-4", {"blk_g": 0.10})):
        res = [one_study(1000, sc, B, rng, f_acc=0.95) for _ in range(300)]
        say(f"{name:30s} | {np.mean([r['zg'] == 'changed' for r in res]):.3f}, {np.mean([r['zf'] == 'changed' for r in res]):.3f} | "
            f"{np.mean([r['Eg'] for r in res]):.3f}, {np.mean([r['Ef'] for r in res]):.3f}")
    say("(2) group level | n | k | P(stable) at E=0.10: uncalibrated, calibrated (fresh 400; 95% upper) | "
        "P(stable) at E=0.05 aligned: uncal, cal | P(stable) at E=0.05 random, even errors: uncal, cal | mean est E at 0.10")
    for n in (1000, 2000):
        cal = [one_study(n, {"dgp": 0.10}, B, rng, f_acc=0.95, mode="side") for _ in range(600)]
        k = min(1.0, np.percentile([r["rs_g"] for r in cal if r["zg"] != "unreadable"], 2.5))
        val = [one_study(n, {"dgp": 0.10}, B, rng, f_acc=0.95, mode="side") for _ in range(400)]
        p5a = [one_study(n, {"dgp": 0.05}, B, rng, f_acc=0.95, mode="side") for _ in range(300)]
        p5r = [one_study(n, {"dg": 0.05}, B, rng, f_acc=0.95) for _ in range(300)]
        st = lambda rs, kk: np.mean([r["rs_g"] < kk and r["sh_g"] < SCAP and r["zg"] != "unreadable" for r in rs])
        kv = sum(r["rs_g"] < k and r["sh_g"] < SCAP and r["zg"] != "unreadable" for r in val)
        say(f"group | {n:4d} | {k:.3f} | {st(val, 1.0):.3f}, {kv / 400:.3f} ({wilson_hi(kv, 400):.3f}) | "
            f"{st(p5a, 1.0):.3f}, {st(p5a, k):.3f} | {st(p5r, 1.0):.3f}, {st(p5r, k):.3f} | {np.mean([r['Eg'] for r in val]):.3f}")


def part_I(say, B):
    """Two further failure modes, both toward a wrong verdict and neither visible in S.
    (3) Legibility that falls for only some patients: the correction of section 4 assumes a common factor.
    (4) Rater memory across the gap between the blocks, with the diagnostic proposed in the protocol:
        kappa between visits 1 and 4 for the same panel-A rater minus that for different panel-A raters."""
    say("PART I  (3) legibility falling for a subset of patients; (4) rater memory across blocks; group accuracy 0.8, form 0.95, n = 1,000, 300 studies")
    rng = np.random.default_rng(SEED + 17)
    say("(3) fixed constitution | subset, group/form accuracy at follow-up | " + " / ".join(VERD) + " | mean est E group, form")
    for share, g_to, f_to in ((0.4, 0.3, 0.5), (0.3, 0.25, 0.95)):
        res = [one_study(1000, {}, B, rng, f_acc=0.95, patfall=(share, g_to, f_to)) for _ in range(300)]
        say(f"{share:.0%} of patients, {g_to}/{f_to} | " + " / ".join(f"{np.mean([r['verdict'] == v for r in res]):.3f}" for v in VERD)
            + f" | {np.mean([r['Eg'] for r in res]):.3f}, {np.mean([r['Ef'] for r in res]):.3f}")
    say("(4) memory m | true lasting form change | P(fixed) | P(state flag) | mean memory diagnostic (same-rater minus different-rater kappa, visits 1-4, form)")
    for m, df in ((0.0, 0.25), (0.5, 0.25), (0.7, 0.15), (1.0, 0.25)):
        out = []
        for _ in range(300):
            st = one_study(1000, {"df": df}, B, rng, f_acc=0.95, memory=m, keep_calls=True)
            out.append(st)
        say(f"{m:.1f} | {df:.2f} | {np.mean([r['verdict'] == 'fixed' for r in out]):.3f} | "
            f"{np.mean([r['state'] for r in out]):.3f} | {np.mean([r['memdiag'] for r in out]):.3f}")


def part_K(say, B):
    """The memory check.  (a) The blocking check (withhold stability if the diagnostic's lower bound exceeds 0) is
    triggered without any memory by a person x rater effect: each rater persistently misreading the form of his own
    fixed share of patients.  (b) The adjusted condition that replaces it (stability bound multiplied by
    1 - CMEM * upper bound of D) under the same person x rater effects, and under memory at and below the margin."""
    say("PART K  memory check; group accuracy 0.8, form 0.95, n = 1,000, 300 studies; CMEM = " + str(CMEM))
    say("(a,b) fixed constitution, no memory | share each rater persistently misreads (form) | P(form stable, core) | "
        "blocking check fails: panel A form, any of four | P(fixed): core + blocking check, core + adjusted condition")
    rng = np.random.default_rng(SEED + 19)
    for p in (0.0, 0.01, 0.02, 0.05):
        res = [one_study(1000, {}, B, rng, f_acc=0.95, pxr=p, memcheck=True) for _ in range(300)]
        anyf = [any(r["memfail"].values()) for r in res]
        say(f"{p:.2f} | {np.mean([r['zf'] == 'stable' for r in res]):.3f} | {np.mean([r['memfail']['Af'] for r in res]):.3f}, "
            f"{np.mean(anyf):.3f} | {np.mean([r['verdict'] == 'fixed' and not a for r, a in zip(res, anyf)]):.3f}, "
            f"{np.mean([r['madj']['g'] and r['madj']['f'] for r in res]):.3f}")
    say("(b) memory m (each rater repeats his own call from the other block) | true lasting form change | "
        "P(form stable): core, adjusted | mean est E form | mean diagnostic D form")
    fit = {}
    for m, df in ((0.0, 0.05), (0.0, 0.075), (0.0, 0.10), (0.1, 0.10), (0.2, 0.10), (0.3, 0.10), (0.5, 0.10), (0.2, 0.125), (0.1, 0.05)):
        res = [one_study(1000, {"df": df}, B, rng, f_acc=0.95, memory=m, memcheck=True, keep_calls=True) for _ in range(300)]
        if df == 0.10:
            fit[m] = (np.mean([r['Ef'] for r in res]), np.mean([r['memdiag'] for r in res]))
        say(f"{m:.1f} | {df:.3f} | {np.mean([r['zf'] == 'stable' for r in res]):.3f}, {np.mean([r['madj']['f'] for r in res]):.3f} | "
            f"{np.mean([r['Ef'] for r in res]):.3f} | {np.mean([r['memdiag'] for r in res]):.3f}")
    say("(b') implied memory factor for a true change of 0.10: (1 - E(m) / E(0)) / D(m), the basis of CMEM")
    say("; ".join(f"m = {m:.1f}: D = {d:.3f}, factor = {(1 - e / fit[0.0][0]) / d:.2f}" for m, (e, d) in fit.items() if m > 0))
    say("(c) no memory, each rater persistently misreading the form of his own share of patients, change below the margin | "
        "share | true lasting form change | P(form stable): core, adjusted | mean diagnostic D form")
    for p, df in ((0.02, 0.05), (0.05, 0.05), (0.02, 0.075), (0.05, 0.075)):
        res = [one_study(1000, {"df": df}, B, rng, f_acc=0.95, pxr=p, memcheck=True, keep_calls=True) for _ in range(300)]
        say(f"{p:.2f} | {df:.3f} | {np.mean([r['zf'] == 'stable' for r in res]):.3f}, {np.mean([r['madj']['f'] for r in res]):.3f} | "
            f"{np.mean([r['memdiag'] for r in res]):.3f}")


def part_M(say, B):
    """The memory adjustment at the group level (part K tests it at the form level): each rater repeats his own
    call from the other block with probability m; lasting group change at and below the margin."""
    say("PART M  memory adjustment at the group level; group accuracy 0.8, form 0.95, n = 1,000, 300 studies; CMEM = " + str(CMEM))
    say("memory m | true lasting group change | P(group stable): core, adjusted | mean est E group")
    rng = np.random.default_rng(SEED + 23)
    for m, dg in ((0.0, 0.05), (0.0, 0.10), (0.1, 0.10), (0.2, 0.10), (0.3, 0.10), (0.5, 0.10), (0.1, 0.05), (0.2, 0.05)):
        res = [one_study(1000, {"dg": dg}, B, rng, f_acc=0.95, memory=m, memcheck=True) for _ in range(300)]
        say(f"{m:.1f} | {dg:.3f} | {np.mean([r['zg'] == 'stable' for r in res]):.3f}, {np.mean([r['madj']['g'] for r in res]):.3f} | "
            f"{np.mean([r['Eg'] for r in res]):.3f}")


def part_N(say):
    """The memory diagnostic D (unscaled: same-rater minus different-rater kappa between the two visits a panel reads,
    averaged over the three raters and the two panels) with a fixed constitution and no memory, when the raters of a
    panel differ in group accuracy; large samples, point estimates."""
    say("PART N  memory diagnostic D without memory, unequal raters (group accuracies per panel), form 0.95, "
        "fixed constitution, n = 20,000, 3 studies per row")
    say("group accuracies | mean D group | mean D form | stability-bound factor 1 - CMEM*D: group, form")
    rng = np.random.default_rng(SEED + 31)
    for accs_g in ((0.8, 0.8, 0.8), (0.9, 0.8, 0.7), (0.95, 0.8, 0.6)):
        out = []
        for _ in range(3):
            Pv = present(20000, {}, rng)
            R = [[rate(Pv[v], accs_g[r], 0.95, "even", rng) for r in range(3)] for v in range(4)]
            b0 = Boot(20000, 0, rng); res = []
            for K, fn in ((4, lambda x: x // 2), (2, lambda x: x % 2)):
                ds = []
                for a, b in ((0, 3), (1, 2)):
                    xa = [fn(x) for x in R[a]]; xb = [fn(x) for x in R[b]]
                    same = np.mean([b0.kappa(xa[i], xb[i], K)[0] for i in range(3)])
                    diff = np.mean([b0.kappa(xa[i], xb[j], K)[0] for i in range(3) for j in range(3) if i != j])
                    ds.append(same - diff)
                res.append(np.mean(ds))
            out.append(res)
        dg, df = np.mean(out, 0)
        say(f"{accs_g} | {dg:.3f} | {df:.3f} | {1 - CMEM * max(dg, 0):.2f}, {1 - CMEM * max(df, 0):.2f}")


def part_L(say):
    """Same-day kappa between two raters at the eight-type, group and form levels under the rater model of part C
    (even errors), from 400,000 simulated patients per row; used to read the published eight-type kappa."""
    say("PART L  same-day kappa between two raters by level (even errors, 400,000 patients per row)")
    say("g_acc | f_acc | kappa eight types | kappa group | kappa form")
    rng = np.random.default_rng(SEED + 29)
    for g_acc in (0.6, 0.7, 0.8, 0.9):
        for f_acc in (0.8, 0.85, 0.9, 0.95):
            t = rng.choice(8, 400_000, p=ECM)
            a = rate(t, g_acc, f_acc, "even", rng); b = rate(t, g_acc, f_acc, "even", rng)
            bt0 = Boot(400_000, 0, rng)
            say(f"{g_acc:.1f} | {f_acc:.2f} | {bt0.kappa(a, b, 8)[0]:.3f} | {bt0.kappa(a // 2, b // 2, 4)[0]:.3f} | "
                f"{bt0.kappa(a % 2, b % 2, 2)[0]:.3f}")


def part_J(say):
    """Raters of unequal accuracy within each panel: bias in S and E with a fixed constitution
    (n = 20,000, 10 studies per row, no bootstrap; form accuracy 0.95)."""
    say("PART J  unequal raters within each panel, fixed constitution, n = 20,000, 10 studies per row, form accuracy 0.95")
    say("group accuracy of the three raters of each panel | mean est S group, form | mean est E group, form")
    rng = np.random.default_rng(SEED + 37)
    for acc in ((0.8, 0.8, 0.8), (0.9, 0.8, 0.7), (0.95, 0.8, 0.6)):
        a = []
        for _ in range(10):
            Pv = present(20000, {}, rng)
            R = [[rate(Pv[v], acc[r], 0.95, "even", rng) for r in range(3)] for v in range(4)]
            bt = Boot(20000, 0, rng)
            sg = level_stats([[x // 2 for x in R[v]] for v in range(4)], 4, bt)
            sf = level_stats([[x % 2 for x in R[v]] for v in range(4)], 2, bt)
            a.append((sg["S"][0], sf["S"][0], sg["E"][0], sf["E"][0]))
        m = np.mean(a, 0)
        say(f"{acc} | {m[0]:.4f}, {m[1]:.4f} | {m[2]:.4f}, {m[3]:.4f}")


def part_O(say):
    """Exact population values (no simulation) under the even-error rater model of rate():
    the ratio R = kappa(a, b) / sqrt(kappa(a, a) kappa(b, b)) between raters of different accuracy (section 4),
    and the population value of E for a 10% lasting change with pe taken from the raters' calls."""
    say("PART O  exact values from the error model (no sampling), ECM mix, even errors")
    def conf(g, f):
        m = np.zeros((8, 8))
        for t in range(8):
            for c in range(8):
                if c // 2 == t // 2:
                    m[t, c] = g * (f if c % 2 == t % 2 else 1 - f)
                else:
                    m[t, c] = (1 - g) / 3 * 0.5
        return m
    agg = {"group": np.kron(np.eye(4), np.ones((2, 1))), "form": np.kron(np.ones((4, 1)), np.eye(2))}
    def kap(J, lev):
        A = agg[lev]; L = A.T @ J @ A
        po = np.trace(L); pe = (L.sum(1) * L.sum(0)).sum()
        return (po - pe) / (1 - pe)
    def J(Ma, Mb, T=None):
        T = np.diag(ECM) if T is None else T          # T[i, j]: true type i at the first visit, j at the second
        return Ma.T @ T @ Mb
    say("accuracies a (group, form) -> b (group, form) | R group | R form")
    for a, b in (((0.8, 0.95), (0.7, 0.95)), ((0.8, 0.95), (0.7, 0.90)), ((0.8, 0.90), (0.7, 0.85))):
        Ma, Mb = conf(*a), conf(*b)
        R = [kap(J(Ma, Mb), lev) / np.sqrt(kap(J(Ma, Ma), lev) * kap(J(Mb, Mb), lev)) for lev in ("group", "form")]
        say(f"{a} -> {b} | {R[0]:.5f} | {R[1]:.5f}")
    say("lasting change 0.10 at one level, raters (0.8, f), pe from the calls | population E / 0.10")
    eye = np.eye(8)
    for lev, f in (("group", 0.95), ("form", 0.95), ("form", 0.90)):
        T = np.zeros((8, 8))
        for i in range(8):
            row = eye[i].copy()
            redraw = np.zeros(8)
            if lev == "group":
                fi = i % 2
                for g2 in range(4):
                    redraw[2 * g2 + fi] = P_G_GIVEN_F[g2, fi]
                share = 0.10 / NG
            else:
                gi = i // 2
                for f2 in range(2):
                    redraw[2 * gi + f2] = P_F_GIVEN_G[gi, f2]
                share = 0.10 / NF
            T[i] = ECM[i] * ((1 - share) * row + share * redraw)
        M = conf(0.8, f)
        same = kap(J(M, M), lev)
        cross = kap(J(M, M, T), lev)
        pe_calls = (lambda L: (L.sum(1) * L.sum(0)).sum())(agg[lev].T @ J(M, M) @ agg[lev])
        pi = (1 - cross / same) * (1 - pe_calls)
        say(f"{lev} (form accuracy {f}) | {pi / 0.10:.4f}")


def part_G(say):
    """Attenuation of E by passing states, at large n (point estimates, no bootstrap)."""
    say("PART G  attenuation of E by passing states: lasting change 10% at one level, n = 20,000, 20 studies per row, "
        "group accuracy 0.8, form accuracy 0.95")
    say("level | states | mean est E / 0.10 | mean est S | 1 - 2S")
    rng = np.random.default_rng(SEED + 11)
    for lev in ("form", "group"):
        k = "_f" if lev == "form" else "_g"
        rows = [("none", {})] + [(f"recurring {x:.2f}", {"rec" + k: x}) for x in (0.01, 0.02, 0.03, 0.05, 0.10)]
        rows += [(f"transient 0.10 at visit {v + 1}", {"tr" + k: {v: 0.10}}) for v in (0, 1, 2)]
        rows += [(f"misreading in each panel {x:.3f}", {"shared": (lev[0], x)}) for x in (0.025, 0.05)]
        for name, extra in rows:
            sc = dict({"df": 0.10} if lev == "form" else {"dg": 0.10}, **extra)
            a = []
            for _ in range(20):
                Pv = present(20000, sc, rng)
                R = [[rate(Pv[v], 0.8, 0.95, "even", rng) for r in range(3)] for v in range(4)]
                bt = Boot(20000, 0, rng)
                fn = (lambda x: x % 2) if lev == "form" else (lambda x: x // 2)
                st = level_stats([[fn(x) for x in R[v]] for v in range(4)], 2 if lev == "form" else 4, bt)
                a.append((st["E"][0], st["S"][0]))
            E, S = np.mean(a, 0)
            say(f"{lev:5s} | {name:32s} | {E / 0.10:.3f} | {S:.3f} | {1 - 2 * S:.3f}")


SCEN_P = SCEN + [
    ("Fixed + legibility lost by 40% of patients (0.3/0.5)", {}, "fixed", {"patfall": (0.4, 0.3, 0.5)}),
    ("Fixed + legibility lost by 30% of patients (0.25/0.95)", {}, "fixed", {"patfall": (0.3, 0.25, 0.95)}),
    ("Fixed + legibility lost by 20% of patients (0.5/0.8)", {}, "fixed", {"patfall": (0.2, 0.5, 0.8)}),
    ("Fixed + legibility gained by 30% after baseline (0.25/0.95)", {}, "fixed", {"patfall": (0.3, 0.25, 0.95), "pat_when": "base"}),
    ("Fixed + form states 20% per visit, baseline only", {"rec_f_v": (0.2, 0.2, 0, 0)}, "fixed", {}),
    ("Fixed + form states 30% per visit, baseline only", {"rec_f_v": (0.3, 0.3, 0, 0)}, "fixed", {}),
    ("Fixed + group states 20% per visit, baseline only", {"rec_g_v": (0.2, 0.2, 0, 0)}, "fixed", {}),
    ("Below the margin: 7% form + form states 20% at baseline only", {"df": 0.07, "rec_f_v": (0.2, 0.2, 0, 0)}, "fixed", {}),
    ("Fixed + rater memory 30%", {}, "fixed", {"memory": 0.3}),
    ("Hierarchical 25% form + rater memory 50%", {"df": 0.25}, "hierarchical", {"memory": 0.5}),
    ("Hierarchical 25% form + legibility falls for all", {"df": 0.25}, "hierarchical", {"fall": (0.10, 0.05)}),
    ("Hierarchical 25% form + legibility lost by 20% (0.5/0.8)", {"df": 0.25}, "hierarchical", {"patfall": (0.2, 0.5, 0.8)}),
]
P_CELLS = ((0.95, 500), (0.95, 1000), (0.90, 1000))


def part_P(say, reps, B, cells):
    """The full registered rule: core rule, memory-adjusted stability bound (CMEM), unanimity check and balance
    check, applied together, against the core rule alone, in the scenarios of part B and further scenarios for the
    failure modes the checks were added for.  The confirmation requirement and the Stage 1 calibration are not
    simulated."""
    say("PART P  full registered rule (core + memory adjustment + unanimity check + balance check); group accuracy 0.8 unless stated")
    say("scenario | f_acc | n | correct: core, full | wrong: core, full (95% upper, full) | " + " / ".join(VERD)
        + " (full) | a check withheld a change")
    for ci in cells:
        f_acc, n = P_CELLS[ci]
        rng = np.random.default_rng(SEED + 200 + ci)
        for name, sc, truth, kw in SCEN_P:
            res = [one_study(n, sc, B, rng, f_acc=f_acc, full=True, **kw) for _ in range(reps)]
            core_ok = np.mean([r["verdict"] == truth for r in res])
            full_ok = np.mean([r["full"]["verdict"] == truth for r in res])
            kc = sum(r["verdict"] not in (truth, "undetermined") for r in res)
            kf = sum(r["full"]["verdict"] not in (truth, "undetermined") for r in res)
            wh = np.mean([r["full"]["g"][1] or r["full"]["f"][1] for r in res])
            say(f"{name:62s} | {f_acc:.2f} | {n:4d} | {core_ok:.3f}, {full_ok:.3f} | {kc}, {kf} ({wilson_hi(kf, reps):.3f}) | "
                + " / ".join(f"{np.mean([r['full']['verdict'] == v for r in res]):.3f}" for v in VERD) + f" | {wh:.3f}")


def part_Q(say, reps, B):
    """Operating characteristics of the full rule near the margin (one level changes, the other fixed)."""
    say("PART Q  full rule near the margin; group accuracy 0.8, form 0.95, even errors")
    say("level | n | true E | P(stable): core, full | P(changed): core, full (95% upper, full) | studies")
    rng = np.random.default_rng(SEED + 300)
    for n in (1000, 2000):
        for lev in ("group", "form"):
            grid = OC_GRID if n == 1000 else (0.10,)
            for d in grid:
                r_ = 2 * reps if d == 0.10 else reps
                sc = {"dg": d} if lev == "group" else {"df": d}
                res = [one_study(n, sc, B, rng, f_acc=0.95, full=True) for _ in range(r_)]
                z = [r["zg"] if lev == "group" else r["zf"] for r in res]
                zf = [r["full"]["g" if lev == "group" else "f"][0] for r in res]
                kf = sum(x == "changed" for x in zf)
                say(f"{lev:5s} | {n:4d} | {d:.3f} | {np.mean([x == 'stable' for x in z]):.3f}, {np.mean([x == 'stable' for x in zf]):.3f} | "
                    f"{np.mean([x == 'changed' for x in z]):.3f}, {kf / r_:.3f} ({wilson_hi(kf, r_):.3f}) | {r_}")


def main():
    parts = [a.split("=")[1] for a in sys.argv if a.startswith("--part=")] or ["A", "E", "F", "B", "C", "G", "H", "I", "J", "K", "M", "L", "N", "O"]
    faccs = [float(a.split("=")[1]) for a in sys.argv if a.startswith("--facc=")] or [0.90, 0.95]
    ns = [int(a.split("=")[1]) for a in sys.argv if a.startswith("--n=")] or [150, 500, 1000]
    reps, B = (20, 100) if QUICK else (300, 500)
    lines = []
    say = lambda s="": (print(s, flush=True), lines.append(s))
    say(f"e0 = {E0}; gate = {GATE}; state flag = {SFLAG}; state ceiling = {SCAP}; studies per cell = {reps} (part E: {2 * reps}); "
        f"bootstrap resamples = {B} (part C: 200); NG = {NG:.3f}, NF = {NF:.3f}")
    for p in parts:
        if p == "A":
            part_A(say, reps, B)
        elif p == "E":
            part_E(say, 2 * reps, B)
        elif p == "B":
            part_B(say, reps, B, faccs, ns)
        elif p == "F":
            part_F(say, B)
        elif p == "I":
            part_I(say, B)
        elif p == "H":
            part_H(say, B)
        elif p == "K":
            part_K(say, B)
        elif p == "J":
            part_J(say)
        elif p == "M":
            part_M(say, B)
        elif p == "L":
            part_L(say)
        elif p == "N":
            part_N(say)
        elif p == "G":
            part_G(say)
        elif p == "O":
            part_O(say)
        elif p == "P":
            cells = [int(a.split("=")[1]) for a in sys.argv if a.startswith("--cell=")] or list(range(len(P_CELLS)))
            part_P(say, reps, B, cells)
        elif p == "Q":
            part_Q(say, reps, B)
        elif p == "C":
            part_C(say, reps, 100 if QUICK else 200)
    tag = "_".join(parts) + ("" if len(faccs) == 2 else "_" + "_".join(f"{x:.2f}" for x in faccs))
    tag += "" if len(ns) == 3 else "_n" + "_".join(map(str, ns))
    tag += "".join("_" + a[2:].replace("=", "") for a in sys.argv if a.startswith("--cell="))
    with open(f"paper5_sim_output_{tag}{'_quick' if QUICK else ''}.txt", "w") as fh:
        fh.write("\n".join(lines) + "\n")


if __name__ == "__main__":
    main()
