"""
Level-wise reanalysis of the complete Sasang tables found by the updated search (paper 4, Table 3 rows
added to those of reanalysis.py). Uses stats() and collapse() from reanalysis.py.
Type order in every matrix: Taeeum, Soeum, Soyang (Taeyang calls dropped where noted). Rows and columns
are re-ordered from the published tables, whose orientation is given below. Seed 2007; 4000 multinomial draws.
Run: python added_tables_levels.py
"""
import numpy as np
from reanalysis import stats, collapse, YANG, YY_CROSS, GL_CROSS

GLV = np.array([0, 1, 1])
TABLES = [
    # Lee JH 2007, Table 2: QSCC II one-year retest, 80 students (rows 2006, cols 2005)
    ("QSCC II one-year retest (Lee JH 2007)", np.array([[10, 2, 2], [2, 44, 5], [0, 3, 12]])),
    # Choi 2006, Table 3 summed over the third test: QSCC II+ 1st (rows) vs 2nd (cols), 266 adults
    ("QSCC II+ one-year retest (Choi 2006)", np.array([[92, 5, 15], [6, 50, 9], [18, 13, 58]])),
    # Ham 2006 study A, Table 2: specialist 1 (rows) vs specialist 2 (cols), 142 clients
    ("Two specialists, shared tool results (Ham 2006)", np.array([[54, 3, 9], [4, 22, 2], [5, 4, 39]])),
    # Kim DR 1994: questionnaire (rows) vs specialist (cols), 64 students (one questionnaire Taeyang call dropped)
    ("Questionnaire vs specialist (Kim DR 1994)", np.array([[23, 1, 1], [1, 19, 2], [5, 3, 9]])),
    # Pak 2016, Table 9: specialist (rows) vs SDQ_S (cols), test half, 105
    ("SDQ_S vs specialist (Pak 2016)", np.array([[33, 6, 4], [4, 22, 3], [2, 8, 23]])),
    # Baek 2015, Table 3 test group: KS-15 (rows) vs expert (cols), 222
    ("KS-15 vs expert (Baek 2015)", np.array([[87, 2, 11], [21, 25, 15], [30, 3, 28]])),
    # Kim SH 2021: KS-15 (rows) vs two agreeing experts (cols), 116 Vietnamese adults
    ("KS-15 vs agreeing experts (Kim SH 2021)", np.array([[35, 6, 6], [1, 18, 7], [5, 14, 24]])),
    # Choi 2006, Table 5: specialist with repeated prescription (rows) vs QSCC II+ (cols), 587
    ("QSCC II+ vs specialist reference (Choi 2006)", np.array([[160, 43, 34], [13, 83, 12], [68, 74, 100]])),
]


def main():
    rng = np.random.default_rng(2007)
    print("table | n | po | three types | yin/yang | greater/lesser | (point [95% interval])")
    for name, M in TABLES:
        n = int(M.sum()); p = (M / n).ravel(); cells = []
        for g in (None, YANG, GLV):
            f = (lambda X: stats(X)["kappa"]) if g is None else (lambda X, g=g: stats(collapse(X, g))["kappa"])
            bs = [f(rng.multinomial(n, p).reshape(3, 3)) for _ in range(4000)]
            cells.append(f"{f(M):.3f} [{np.percentile(bs, 2.5):.2f}, {np.percentile(bs, 97.5):.2f}]")
        print(f"{name:48s} | {n:3d} | {np.trace(M)/n:.3f} | " + " | ".join(cells))
    print("\nshare of disagreements crossing each division (null keeps each column type's error count, split evenly):")
    for name, M in TABLES:
        err_t = M.sum(0) - np.diag(M); tot = int(err_t.sum())
        out = []
        for lab, frac, g in (("yin/yang", YY_CROSS, YANG), ("greater/lesser", GL_CROSS, GLV)):
            obs = int(sum(M[i, j] for i in range(3) for j in range(3) if i != j and g[i] != g[j]))
            out.append(f"{lab} {obs}/{tot} ({obs/tot*100:.0f}%; null {err_t @ frac / tot * 100:.1f}%)")
        print(f"{name:48s} | " + "; ".join(out))


if __name__ == "__main__":
    main()
