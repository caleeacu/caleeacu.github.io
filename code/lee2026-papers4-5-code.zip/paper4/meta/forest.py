import json, sys
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
U = pd.read_csv(sys.argv[1]); R = json.load(open(sys.argv[2]))
order = ["different classifiers, same occasion", "vs treatment-confirmed reference", "same classifier, across occasions"]
labels = {"different classifiers, same occasion":"Different classifiers, same occasion",
          "vs treatment-confirmed reference":"Classifier vs treatment-confirmed reference",
          "same classifier, across occasions":"Same classifier, across occasions"}
rows=[]
for des in order:
    g = U[(U.design==des)].copy()
    g['yr'] = g.unit.str.extract(r'(\d{4})', expand=False).astype(int)
    g = g.sort_values(['yr', 'unit'], kind='stable')
    rows.append(("h", labels[des], None, None, None))
    for _,r in g.iterrows():
        lab = r.unit + ("  [in-sample; excluded]" if r.in_sample==1 else "")
        rows.append(("s", lab, r.kappa, r.kappa-1.96*r.se, r.kappa+1.96*r.se))
    if des in R["pooled"] and R["pooled"][des]["k"]>1:
        p=R["pooled"][des]; rows.append(("p","Pooled (REML)",p["beta"][0],p["ci_low"][0],p["ci_high"][0]))
    rows.append(("b","",None,None,None))
fig,ax=plt.subplots(figsize=(9,0.32*len(rows)+0.8))
y=len(rows)
for t,lab,k,lo,hi in rows:
    y-=1
    if t=="h": ax.text(-0.02,y,lab,fontweight="bold",ha="right",va="center",fontsize=9,transform=ax.get_yaxis_transform())
    elif t=="s":
        ax.plot([lo,hi],[y,y],color="#444",lw=1); ax.plot(k,y,"s",color="#2b5c8a",ms=5)
        ax.text(-0.02,y,lab,ha="right",va="center",fontsize=8,transform=ax.get_yaxis_transform())
        ax.text(1.02,y,f"{k:.2f} [{lo:.2f}, {hi:.2f}]",ha="left",va="center",fontsize=8,transform=ax.get_yaxis_transform())
    elif t=="p":
        ax.fill([lo,k,hi,k],[y,y+0.3,y,y-0.3],color="#c0392b")
        ax.text(-0.02,y,lab,ha="right",va="center",fontsize=8,fontstyle="italic",transform=ax.get_yaxis_transform())
        ax.text(1.02,y,f"{k:.2f} [{lo:.2f}, {hi:.2f}]",ha="left",va="center",fontsize=8,fontweight="bold",transform=ax.get_yaxis_transform())
ax.set_ylim(-0.5,len(rows)-0.5); ax.set_xlim(0,1); ax.set_yticks([])
ax.set_xlabel("Cohen's kappa (95% CI)"); ax.axvline(0.4,ls=":",color="#999",lw=0.8)
for s in ["top","right","left"]: ax.spines[s].set_visible(False)
plt.tight_layout(); plt.subplots_adjust(left=0.42,right=0.80)
plt.savefig(sys.argv[3],dpi=int(sys.argv[4]) if len(sys.argv)>4 else 200)
