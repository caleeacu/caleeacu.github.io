"""PRISMA 2020 flow diagram for paper 4 (database search 8-9 November 2026).
Counts come from search_log.csv (hits per search) and screening_log.csv (one row per unique record).
Run: python3 prisma.py  -> figure1_prisma.png and prisma_counts.txt"""
import re
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle

S = pd.read_csv("search_log.csv"); L = pd.read_csv("screening_log.csv")
num = lambda v: int(re.match(r"\d+", str(v)).group()) if re.match(r"\d+", str(v)) else 0
S = S[~S.records.astype(str).str.contains("error|invalid")]   # searches that failed (error page or unparsed query) are not counted
hits = S.assign(n=S.records.map(num)).groupby("db").n.sum().to_dict()
nsearch = S.assign(n=S.records.map(num)).groupby("db").size().to_dict()
displayed = {"KCI": hits["KCI"], "PubMed": hits["PubMed"], "KoreaScience": 76, "RISS": 3}   # KoreaScience: first page (10) per search; RISS: integrated-search preview of the theses tab
db = L[~L.database.str.startswith("other")]
oth = L[L.database.str.startswith("other")]
ident = sum(hits.values()); notshown = sum(hits[k] - displayed[k] for k in hits)
screened = len(db); dups = sum(displayed.values()) - screened
ta = (db.stage == "title/abstract").sum(); sought = screened - ta
nr = (db.decision == "not retrieved").sum(); assessed = sought - nr
ftx = db[(db.stage == "full text") & (db.decision == "exclude")]; inc_db = (db.decision == "include").sum()
assert assessed == len(ftx) + inc_db
reasons = ftx.reason.str.split(":").str[0].value_counts()
o_inc = (oth.decision == "include").sum(); o_nr = (oth.decision == "not retrieved").sum(); o_ex = oth[oth.decision == "exclude"]
total_inc = inc_db + o_inc
lines = [f"identified {ident} ({hits})", f"searches {nsearch}", f"not displayed {notshown}", f"duplicates {dups}", f"screened {screened}",
         f"excluded title/abstract {ta}", f"sought {sought}", f"not retrieved {nr}", f"assessed {assessed}", f"excluded full text {len(ftx)}",
         str(reasons.to_dict()), f"included from databases {inc_db}", f"other methods: identified {len(oth)}, not retrieved {o_nr}, assessed {len(oth)-o_nr}, excluded {len(o_ex)}, included {o_inc}",
         f"total included reports {total_inc}"]
open("prisma_counts.txt", "w").write("\n".join(lines) + "\n"); print("\n".join(lines))

T = dict(
 ident=f"Records identified (n = {ident})\n  KCI, {nsearch['KCI']} searches (n = {hits['KCI']})\n  KoreaScience, {nsearch['KoreaScience']} searches (n = {hits['KoreaScience']})\n  PubMed, 1 search (n = {hits['PubMed']})\n  RISS theses, 1 search (n = {hits['RISS']})",
 removed=f"Records removed before screening\n  Duplicate records (n = {dups})\n  Results beyond the first page,\n  not displayed (n = {notshown}):\n  KoreaScience {hits['KoreaScience']-displayed['KoreaScience']}, RISS {hits['RISS']-displayed['RISS']}",
 screened=f"Records screened (n = {screened})", excl_ta=f"Records excluded on title\nor abstract (n = {ta})",
 sought=f"Reports sought for retrieval (n = {sought})", notret=f"Reports not retrieved (n = {nr})",
 assessed=f"Reports assessed for eligibility (n = {assessed})",
 excl_ft=f"Reports excluded (n = {len(ftx)})\n" + "\n".join(f"  {k[0].upper()+k[1:]}\n    (n = {v})" if len(k)>30 else f"  {k[0].upper()+k[1:]} (n = {v})" for k, v in reasons.items()),
 o_ident=f"Records identified from:\n  Preliminary search\n  Citation searching\n  (n = {len(oth)})",
 o_sought=f"Reports sought for retrieval (n = {len(oth)})", o_nr=f"Reports not retrieved (n = {o_nr})\n  Unpublished master's theses",
 o_assessed=f"Reports assessed for eligibility (n = {len(oth)-o_nr})",
 o_excl=f"Reports excluded (n = {len(o_ex)})\n" + "\n".join(f"  {s.split(':')[0].split(';')[0].split(' (')[0][:1].upper()+s.split(':')[0].split(';')[0].split(' (')[0][1:]} (n = 1)" for s in o_ex.reason),
 included=f"Reports included in review (n = {total_inc})\n  From databases {inc_db}; from other methods {o_inc}\n  Kappa analyses: 19 reports\n  Percentage agreement only: 4 reports",
)
fig, ax = plt.subplots(figsize=(15, 11.5)); ax.set_xlim(0, 150); ax.set_ylim(0, 120); ax.axis("off")
def box(x, y, w, h, k, fc="white"):
    ax.add_patch(Rectangle((x, y), w, h, fc=fc, ec="#222", lw=0.9))
    ax.text(x + 1.2, y + h / 2, T[k], va="center", ha="left", fontsize=8.3, linespacing=1.35)
def arr(*pts):
    for (x1, y1), (x2, y2) in zip(pts[:-2], pts[1:-1]): ax.plot([x1, x2], [y1, y2], color="#222", lw=0.9)
    (x1, y1), (x2, y2) = pts[-2], pts[-1]
    ax.annotate("", xy=(x2, y2), xytext=(x1, y1), arrowprops=dict(arrowstyle="-|>", color="#222", lw=0.9, shrinkA=0, shrinkB=0))
def band(y, h, lab):
    ax.add_patch(Rectangle((0, y), 4, h, fc="#d9d9d9", ec="none"))
    ax.text(2, y + h / 2, lab, ha="center", va="center", rotation=90, fontsize=9, fontweight="bold")
ax.text(42, 117, "Identification of studies via databases", ha="center", fontsize=10, fontweight="bold")
ax.text(115, 117, "Identification of studies via other methods", ha="center", fontsize=10, fontweight="bold")
ax.plot([80, 80], [2, 115], color="#999", lw=0.6, ls=":")
band(94, 21, "Identification"); band(24, 66, "Screening"); band(2, 19, "Included")
box(6, 95, 34, 19, "ident"); box(44, 95, 34, 19, "removed"); arr((40, 104.5), (44, 104.5))
box(6, 80, 34, 7, "screened"); arr((23, 95), (23, 87))
box(44, 79, 34, 9, "excl_ta"); arr((40, 83.5), (44, 83.5))
box(6, 66, 34, 7, "sought"); arr((23, 80), (23, 73))
box(44, 66, 34, 7, "notret"); arr((40, 69.5), (44, 69.5))
box(6, 52, 34, 7, "assessed"); arr((23, 66), (23, 59))
box(44, 25, 34, 34, "excl_ft"); arr((40, 55.5), (44, 55.5))
box(83, 95, 30, 19, "o_ident")
box(83, 66, 30, 7, "o_sought"); arr((98, 95), (98, 73))
box(116, 65, 33, 9, "o_nr"); arr((113, 69.5), (116, 69.5))
box(83, 52, 30, 7, "o_assessed"); arr((98, 66), (98, 59))
box(116, 46, 33, 16, "o_excl"); arr((113, 55.5), (116, 55.5))
box(6, 3, 40, 16, "included", fc="#f2f2f2"); arr((23, 52), (23, 19)); arr((98, 52), (98, 11), (46, 11))
plt.savefig("figure1_prisma.png", dpi=220, bbox_inches="tight")
