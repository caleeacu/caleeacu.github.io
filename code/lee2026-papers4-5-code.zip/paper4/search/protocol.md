> **Note added 9 November 2026.** This protocol was written on 8 November 2026, after the preliminary analysis and before the logged search (apart from the one test search described in section 1). It was not registered on OSF or elsewhere, because a registration made after the preliminary analysis could not count as prospective. It is posted here unchanged below this note. Departures from it are reported in section 2.3 of paper 4 and in search_log.csv.

# Protocol: Agreement in Korean constitutional diagnosis by who classifies and when — an updated structured review and meta-analysis

**Registration type.** OSF Generalized Systematic Review Registration.
**Author.** Hoon Lee, L.Ac. (CALee Acupuncture, Buena Park, California). caleeacu@gmail.com
**Date of registration.** [fill in on OSF]

## 1. Status at registration (read first)

A first, unlogged search (October 2026) and a preliminary analysis were completed before this registration, and a working paper based on them exists (Lee 2026, *What Counts as Error?*, SSRN working paper). This registration fixes the methods for an **updated search** in which every record is logged, so that a PRISMA 2020 flow diagram can be reported. The eligibility criteria, design classes, effect measure and analysis below are those of the preliminary analysis and are not changed in the light of its results. Any study found by the updated search, and any change from this protocol, will be reported, including whether it changes the preliminary estimates.

**Work done before this registration.** Before registration, one search of the updated strategy was run as a test of the search syntax (KCI, "사상체질 일치도", 8 November 2026, 7 records), and the full texts of four of its records were read. That search showed that four eligible or possibly eligible reports had been missed by the preliminary search, and the full texts prompted three of the selection rules in section 3 (marked †). These records are counted in the flow diagram like all others, and the rules marked † are applied to every record. The extraction sheet and analysis code of the preliminary analysis are public (https://research.caleeacu.com/code/lee2026-papers4-5-code.zip).

## 2. Review questions

1. How well do different classifiers (practitioners, instruments, or a practitioner and an instrument) agree when they type the same persons into Sasang or Eight Constitution Medicine (ECM) types on one occasion?
2. How well does one classifier agree with itself across occasions, and does that agreement fall with the interval?
3. Has any study compared different classifiers across occasions?
4. What upper bound do the data place on the share of persons whose type changes?
5. Where complete cross-tabulations exist, at which level of the typology is disagreement concentrated, and are raters' errors independent?

## 3. Eligibility

**Included.** Reports of agreement between two classifications of the same persons into Sasang types (three or four categories) or ECM types (eight types or four organ groups), given as Cohen's kappa, as percentage agreement with sample size, or as a cross-tabulation from which either can be computed. Classifiers may be practitioners, instruments (questionnaire, image, voice, body measurement), or a reference type fixed by response to treatment. Journal articles, conference abstracts, and theses or dissertations whose full text can be obtained. Any language.

**Excluded.** Accuracy computed only in the sample used to build a discriminant function or model (in-sample), unless a held-out sample is reported; item-level reliability only; typologies other than Sasang or ECM; correlations between continuous constitution scores; reports whose participants entirely overlap with an included report (the report with more complete data is kept); a second classification made with knowledge of the first (†); ratings of how well a type already assigned fits a case, without an independent type assignment (†).

**Flagged, not excluded.** Classifications that drew on the same instrument results (shared inputs) (†); samples restricted to patients whose type was confirmed by treatment response or was determinate on both occasions. Reports giving percentage agreement but no kappa or table against a treatment-confirmed reference are tabulated and described but not pooled.

## 4. Information sources and search

Databases, each searched from inception to the date of search, with the date and the number of records recorded in the search log. KCI does not parse nested Boolean expressions (a test of the combined string returned 11,965 records, most of them law journals matching "constitution"), so the Korean databases are searched with the 36 two-term searches below, the space acting as AND; PubMed is searched with the combined string.

| Source | Query |
|---|---|
| KCI (kci.go.kr) | each of 사상체질, 8체질, 팔체질 combined with each of 일치도, 신뢰도, 신뢰성, 재검사, 재현성, 카파, 타당도, 타당성 (24 searches); 8체질 and 팔체질 each combined with 맥진 and 설문 (4 searches); each of Sasang, Eight Constitution combined with each of kappa, agreement, reliability, reproducibility (8 searches) |
| KoreaScience | the same 36 searches |
| ScienceON | the same 36 searches |
| RISS (theses) | the same 36 searches, limited to theses and dissertations |
| PubMed | ("Sasang"[tiab] OR "Eight Constitution"[tiab] OR "Eight-Constitution"[tiab] OR "constitutional medicine"[tiab]) AND (kappa[tiab] OR agreement[tiab] OR reliability[tiab] OR concordance[tiab] OR reproducibility[tiab] OR "test-retest"[tiab]) |

Each search is logged with its date and number of records, including searches that return none. Search sensitivity is checked against known items: the searches must retrieve the ECM pulse-reliability study of Lee HS 2005 and the ECM questionnaire study of Min 2007; the terms 신뢰성, 타당도, 타당성, 맥진 and 설문 were added before registration after the first 23 searches were found to miss items titled with these words. Reference lists of included reports and of the reviews by Han and Kwon (2018), O'Brien and Birch (2009), Ko et al. (2017) and Lee et al. (2012) are scanned, and the records found this way are logged as "other sources".

## 5. Selection

All records are exported, de-duplicated by title, year and first author, and given an ID. Titles and abstracts are screened, then full texts. Each exclusion at full text is given one reason from the list in section 3. Screening is done by the author. If a second reviewer is available, a random 20% of records at each stage is screened independently, and agreement (kappa) and the resolution of disagreements are reported; if not, this is reported as a limitation.

## 6. Data items

Study, year, system (Sasang or ECM), classifier A and B, design class, interval between occasions, sample size, number of categories, kappa, percentage agreement, source of the value (reported, computed from a table, derived, range midpoint), the full cross-tabulation where printed, and flags (in-sample, selected on agreed or stable diagnosis, determinate types only, overlap with another report).

## 7. Design classes

(a) Different classifiers, same occasion; (b) same classifier, across occasions; (c) against a treatment-confirmed reference; (d) different classifiers, across occasions.

## 8. Effect measure and synthesis

As in the preliminary analysis and its public code (analysis.py): Cohen's kappa at the finest level reported; SE = √[po(1−po)/n]/(1−pe), with pe = 0.37 where po is not reported; correlated estimates from one sample averaged with ρ = 0.5; REML random-effects pooling within design class with τ², I² and 95% prediction intervals; meta-regression on design class (b against a); sensitivity analyses restricted to Sasang and to exactly reported estimates; percentage agreement in questionnaire retests regressed on log interval on the logit scale; the KS-15 change bound πmax = (1 − κl/κs)(1 − pe); level-wise kappa and conditional-dependence tests in complete tables. Funnel-plot tests are not run with fewer than ten estimates per class.

## 9. Appraisal

Independence of the two classifications (blinding; recall of an earlier call), selection on agreed or stable diagnosis, definition of the reference, in-sample estimation.

## 10. Reporting

PRISMA 2020 with flow diagram; the search log, screening log and extraction sheet will be posted with the code.
